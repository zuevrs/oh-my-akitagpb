package ru.gazprombank.automation.akitagpb.modules.ccl.desktop.driver;

import FlaNium.WinAPI.property.PropertyList.Driver;
import FlaNium.WinAPI.webdriver.DesktopOptions;
import FlaNium.WinAPI.webdriver.FlaNiumDriver;
import FlaNium.WinAPI.webdriver.FlaNiumDriverService;
import FlaNium.WinAPI.webdriver.FlaNiumDriverService.Builder;
import java.io.File;
import java.time.Duration;
import java.util.Properties;
import ru.gazprombank.automation.akitagpb.modules.core.helpers.PropertyLoader;

public class DesktopDriverProvider {

  private static FlaNiumDriver driver;

  private DesktopDriverProvider() {}

  public static FlaNiumDriver getDriver() {
    if (driver == null) {
      driver = initDriver();
    }

    return driver;
  }

  public static FlaNiumDriver initDriver() {
    Properties fileProp = PropertyLoader.getPropertiesInstance("/flanium_driver.properties");
    fileProp.forEach(
        (k, v) -> {
          if (!System.getProperties().containsKey(k.toString())) {
            System.setProperty(k.toString(), v.toString());
          }
        });

    return new FlaNiumDriver(getService(), new DesktopOptions().setLaunchDelay(30000));
  }

  private static FlaNiumDriverService getService() {
    String exe = System.getProperty(Driver.DRIVER_EXE.getValue());
    String port = System.getProperty(Driver.DRIVER_PORT.getValue());
    String verbose = System.getProperty(Driver.DRIVER_VERBOSE.getValue());
    String silent = System.getProperty(Driver.DRIVER_SILENT.getValue());
    String timeout = System.getProperty(Driver.DRIVER_TIMEOUT.getValue());
    String logFile = System.getProperty(Driver.DRIVER_LOG_FILE.getValue());
    Builder builder = new Builder();
    if (notNullAndNotEmpty(exe)) {
      builder.usingDriverExecutable((new File(exe)).getAbsoluteFile());
    }

    if (notNullAndNotEmpty(port)) {
      builder.usingPort(Integer.parseInt(port));
    }

    if (notNullAndNotEmpty(verbose)) {
      builder.withVerbose(Boolean.parseBoolean(verbose));
    }

    if (notNullAndNotEmpty(silent)) {
      builder.withSilent(Boolean.parseBoolean(silent));
    }

    if (notNullAndNotEmpty(timeout)) {
      builder.withTimeout(Duration.ofSeconds(Integer.parseInt(timeout)));
    }

    if (notNullAndNotEmpty(logFile)) {
      builder.withLogFile((new File(logFile)).getAbsoluteFile());
    }

    return builder.build();
  }

  private static boolean notNullAndNotEmpty(String value) {
    return value != null && !value.isEmpty();
  }
}
