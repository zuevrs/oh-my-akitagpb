package ru.gazprombank.automation.akitagpb.modules.ccl.desktop.interfaces;

import java.util.Arrays;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ru.gazprombank.automation.akitagpb.modules.ccl.desktop.driver.DesktopDriverProvider;
import ru.gazprombank.automation.akitagpb.modules.core.steps.isteps.IBaseMethods;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;
import ru.gazprombank.automation.akitagpb.modules.ui.helpers.AnnotationHelper;

public interface IDesktopApp extends IBaseMethods {

  default WebElement getDesktopElement(String elementName, String... args) {
    FindBy findByAnnotation = AnnotationHelper.getFindBy(Pages.getCurrentPage(), elementName);
    String xpath = String.format(findByAnnotation.xpath(), Arrays.stream(args).toArray());
    return DesktopDriverProvider.getDriver().findElement(By.xpath(xpath));
  }

  default WebElement getDesktopElement(String elementName) {
    By elementBy = AnnotationHelper.getFindByElement(Pages.getCurrentPage(), elementName);
    return DesktopDriverProvider.getDriver().findElement(elementBy);
  }

  default String getAnyElementText(WebElement element) {
    List<String> typeElement = List.of("GridViewCellItem", "TextBlock");
    if (typeElement.contains(element.getDomAttribute("ClassName"))) {
      return element.getDomAttribute("Name");
    }
    return element.getText();
  }
}
