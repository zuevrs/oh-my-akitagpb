package ru.gazprombank.automation.akitagpb.modules.ccl.desktop.annotations;

import java.lang.annotation.Repeatable;

@Repeatable(ColumnArray.class)
public @interface Column {

  int index();

  String name();

  String xpath() default "";

  String regexp() default "";

  int regexpGroup() default 1;

  boolean isAbsolutePath() default false;
}
