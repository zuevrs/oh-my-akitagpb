package ru.gazprombank.automation.akitagpb.modules.ccl.desktop.interfaces;

import static org.assertj.core.api.Assertions.assertThat;

import com.google.common.collect.ArrayTable;
import com.google.common.collect.Table.Cell;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import lombok.Data;
import org.assertj.core.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ru.gazprombank.automation.akitagpb.modules.ccl.desktop.annotations.Column;
import ru.gazprombank.automation.akitagpb.modules.ccl.desktop.annotations.Rows;
import ru.gazprombank.automation.akitagpb.modules.ccl.desktop.driver.DesktopDriverProvider;
import ru.gazprombank.automation.akitagpb.modules.ccl.helpers.StringHelper;
import ru.gazprombank.automation.akitagpb.modules.core.steps.isteps.StepImplementedException;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;
import ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps.IElementsInteractionSteps;

public interface ITableDesktop extends IElementsInteractionSteps {

  /**
   * Метод для получения данных таблицы если у таблицы не указаны данные через аннотации @Column
   *
   * @param tableName имя таблицы в Page Object
   * @return данные таблицы ArrayTable<Индекс_строки, Имя_столбца, WebElement ячейки>
   */
  default ArrayTable<Integer, String, CellData> getDefaultTableData(String tableName) {

    WebElement table = getTable(tableName);
    List<String> columnsName = getColumnNames(tableName);
    int rowCount = getRows(tableName).size();
    List<Integer> rowsIndex =
        IntStream.rangeClosed(0, rowCount - 1).boxed().collect(Collectors.toList());

    ArrayTable<Integer, String, CellData> resultTableData =
        ArrayTable.create(rowsIndex, columnsName);
    for (int rowIndex : rowsIndex) {
      for (int columnIndex = 0; columnIndex < columnsName.size(); columnIndex++) {
        WebElement cellSelenideElement =
            table.findElements(By.xpath(String.format(".//td[%s]", columnIndex + 1))).get(rowIndex);
        CellData cellData =
            new CellData(rowIndex, columnIndex, columnsName.get(columnIndex), cellSelenideElement);
        resultTableData.put(rowIndex, columnsName.get(columnIndex), cellData);
      }
    }
    return resultTableData;
  }

  /**
   * Метод для получения данных таблицы
   *
   * @param tableName имя таблицы в Page Object
   * @return данные таблицы ArrayTable<Индекс_строки, Имя_столбца, WebElement ячейки> //
   */
  default ArrayTable<Integer, String, CellData> getTableData(String tableName) {

    // у элемента таблицы получаем все аннотации Column
    List<Column> columns = getColumns(tableName);

    // если не задачны столбцы через аннотации, то формируем по умолчанию
    if (columns.isEmpty()) {
      return getDefaultTableData(tableName);
    }

    List<WebElement> rows = getRows(tableName);
    // определяем количество строк в таблице
    int rowCount = rows.size();

    // формируем индексы для столбцов и строк (для столбоцов используем имена, для строк числовой
    // идентификатор)
    List<String> columnsName = getColumnNames(tableName);
    List<Integer> rowsIndex =
        IntStream.rangeClosed(0, rowCount - 1).boxed().collect(Collectors.toList());

    // создаём объект для хранения таблицы
    ArrayTable<Integer, String, CellData> resultTableData =
        ArrayTable.create(rowsIndex, columnsName);

    // заполняем таблицу
    try {
      for (int rowIndex : rowsIndex) {
        for (Column column : columns) {
          String columnXpath = column.xpath();
          if (!column.isAbsolutePath()) {
            columnXpath = getColumnLocator(tableName, column.xpath());
          }
          CellData cellData =
              new CellData(
                  rowIndex, column, rows.get(rowIndex).findElement(By.xpath(column.xpath())));
          resultTableData.put(rowIndex, column.name(), cellData);
        }
      }
    } catch (Exception e) {
      Assertions.fail("Ошибка при разборе таблицы '%s'", tableName);
    }

    return resultTableData;
  }

  /**
   * Метод возвращает список аннотаций Column из Page Object
   *
   * @param tableName имя таблицы(по аннотации @Name)
   * @return список аннотаций Column из Page Object
   */
  default List<Column> getColumns(String tableName) {
    Field tableField = Pages.getCurrentPage().getClassFieldByElementName(tableName);

    return Arrays.stream(tableField.getAnnotationsByType(Column.class))
        .collect(Collectors.toList());
  }

  /**
   * Метод получения списка имён столбцов таблицы
   *
   * @param tableName имя таблицы (имя элемента @Name)
   * @return список имён столбцов таблицы
   */
  default List<String> getColumnNames(String tableName) {

    // у элемента таблицы получаем все аннотации Column
    List<Column> columns = getColumns(tableName);

    // если не задачны столбцы через аннотации, то формируем по умолчанию
    if (columns.isEmpty()) {
      List<String> columnsName = new ArrayList<>();
      List<WebElement> columnsHead = getTable(tableName).findElements(By.xpath(".//thead//th"));
      for (int i = 0; i < columnsHead.size(); i++) {
        String columnName = columnsHead.get(i).getText();
        if (columnName.isEmpty()) {
          columnsName.add("Столбец" + i);
        } else {
          columnsName.add(columnsHead.get(i).getText());
        }
      }
      return columnsName;
    }

    return getColumns(tableName).stream().map(Column::name).collect(Collectors.toList());
  }

  /**
   * Метод получения элемента таблицы
   *
   * @param tableName имя таблицы (имя элемента @Name)
   * @return WebElement таблицы
   */
  default WebElement getTable(String tableName) {
    return ((IDesktopApp) Pages.getCurrentPage()).getDesktopElement(tableName);
  }

  /**
   * Метод получения мапы строки таблицы, соответствующей параметрам
   *
   * @param tableName имя таблицы (имя элемента @Name)
   * @param parameters параметры строки (key - имя столбца таблицы, value - ожидаемое значение
   *     столбца)
   * @return мапа строки таблицы
   */
  default Map.Entry<Integer, Map<String, CellData>> getRow(
      String tableName, Map<String, String> parameters) {
    return getRow(tableName, parameters, null, null);
  }

  /**
   * Метод получения мапы строки таблицы, соответствующей параметрам, с указанием диапазона строк
   * поиска ожидаемых строк (со строки A до строки B).
   *
   * @param tableName имя таблицы (имя элемента @Name)
   * @param parameters параметры строки (key - имя столбца таблицы, value - ожидаемое значение
   *     столбца)
   * @param fromRowIndex индекс строки таблицы (с 0), с которого начинается поиск ожидаемых строк
   *     (включительно). Опциональный параметр - если не задан, то поиск будет производиться с
   *     начала таблицы
   * @param toRowIndex индекс строки таблицы (с 0), до которого производится поиск ожидаемых строк
   *     (включительно) Опциональный параметр - если не задан, то поиск будет производиться до конца
   *     таблицы
   * @return мапа строки таблицы
   */
  default Map.Entry<Integer, Map<String, CellData>> getRow(
      String tableName, Map<String, String> parameters, Integer fromRowIndex, Integer toRowIndex) {
    ArrayTable<Integer, String, CellData> resultTableData = getTableData(tableName);
    checkParametersColumns(tableName, parameters);

    return resultTableData.rowMap().entrySet().stream()
        .filter(
            row -> {
              if (fromRowIndex != null && row.getKey() < fromRowIndex) {
                return false;
              }
              return toRowIndex == null || row.getKey() <= toRowIndex;
            })
        .filter(
            row -> {
              boolean isFound = true;
              for (Map.Entry<String, String> parameter : parameters.entrySet()) {
                String parameterColumnName = parameter.getKey();
                String parameterCellValue = parameter.getValue();
                CellData cellData = row.getValue().get(parameterColumnName);
                if (!checkCellValue(cellData, parameterCellValue)) {
                  isFound = false;
                  break;
                }
              }
              return isFound;
            })
        .findFirst()
        .orElse(null);
  }

  /**
   * Метод для проверки совпадения значения ячейки с ожидаемым результатом
   *
   * @param cellData данные ячейки
   * @param expectedValue ожидаемое значение
   * @return признак совпадения значения ячейки с ожидаемым результатом
   */
  default boolean checkCellValue(CellData cellData, String expectedValue) {
    String cellValue = getTextCellValue(cellData);
    return expectedValue.equals(cellValue);
  }

  /**
   * Проверить, что переданные параметры не содержат имён столбцов, которых нет в самой таблице
   *
   * @param tableName имя таблицы (имя элемента @Name)
   * @param parameters параметры строки (key - имя столбца таблицы, value - ожидаемое значение
   *     столбца)
   */
  default void checkParametersColumns(String tableName, Map<String, String> parameters) {
    var columnNames = getColumnNames(tableName);
    assertThat(columnNames)
        .as(
            String.format(
                "В параметрах указаны столбцы, которых нет в таблице.%nВ параметрах:%s%nВ таблице:%s",
                parameters.keySet(), columnNames))
        .containsAll(parameters.keySet());
  }

  /**
   * Получить список текстовых значений, содержащихся в текстовых ячейках строки таблицы (в input'ах
   * или текстовых div'ах)
   *
   * @param tableName имя таблицы (имя элемента @Name)
   * @param index индекс строки в таблице (0 - первая, null - последняя).
   * @return список текстовых значений, содержащихся в текстовых ячейках строки таблицы (в input'ах
   *     или текстовых div'ах)
   */
  default Map<String, String> getTextValuesFromElements(String tableName, Integer index) {
    ArrayTable<Integer, String, CellData> tableData = getTableData(tableName);
    if (index == null) {
      index = tableData.rowKeySet().stream().max(Comparator.naturalOrder()).orElse(0);
    }

    int indexValue = index;
    return tableData.cellSet().stream()
        .filter(cell -> cell.getRowKey().equals(indexValue))
        .collect(Collectors.toMap(Cell::getColumnKey, cell -> getTextCellValue(cell.getValue())));
  }

  /**
   * Метод проверки, что строка таблицы по переданному индексу соответствует параметрам
   *
   * @param tableName имя таблицы (имя элемента @Name)
   * @param index индекс строки в таблице (0 - первая, null - последняя)
   * @param parameters параметры строки (key - имя столбца таблицы, value - ожидаемое значение
   *     столбца).
   */
  default void assertRowMatchParams(
      String tableName, Integer index, Map<String, String> parameters) {
    var actualTextValues = getTextValuesFromElements(tableName, index);
    parameters.forEach(
        (name, value) -> {
          var actualValue = actualTextValues.get(name);
          assertThat(actualValue)
              .as(
                  String.format(
                      "%s - %s: ожидаемое значение '%s' не равно фактическому '%s'",
                      tableName, name, value, actualValue))
              .isEqualTo(value);
        });
  }

  /**
   * Метод заполнения строки таблицы переданными значениями
   *
   * @param tableName имя таблицы (имя элемента @Name)
   * @param index индекс строки в таблице (0 - первая, null - последняя)
   * @param parameters параметры строки (key - имя столбца таблицы, value - значение столбца для
   *     заполнения).
   */
  default void insertValuesIntoTableRow(
      String tableName, Integer index, Map<String, String> parameters) {
    throw new StepImplementedException(StepImplementedException.ERROR_MESSAGE);
  }

  /**
   * Метод получения WebElement'а строки таблицы по индексу
   *
   * @param tableName имя таблицы (имя элемента @Name)
   * @param index индекс строки в таблице (0 - первая, null - последняя)
   * @return WebElement строки таблицы
   */
  default WebElement getRow(String tableName, Integer index) {
    var rows = getRows(tableName);
    return index == null ? rows.get(rows.size() - 1) : rows.get(index);
  }

  /**
   * Метод получения коллекции элементов ElementsCollection, содержащихся в строке таблицы и имеющих
   * изменяемое текстовое значение (поля ввода (input) и выбранные значения раскрывающихся списков
   * (div[@class='text' or @class='default text']))
   *
   * @param tableName имя таблицы (имя элемента @Name)
   * @param index индекс строки в таблице (0 - первая, null - последняя)
   * @return коллекции элементов ElementsCollection, содержащихся в строке таблицы и имеющих
   *     изменяемое текстовое значение
   */
  default List<WebElement> getRowElementsContainingTextValue(String tableName, Integer index) {
    return getRow(tableName, index)
        .findElements(By.xpath("./td//div[@class='text' or @class='default text'] | ./td//input"));
  }

  /**
   * Получить индекс столбца таблицы по имени столбца
   *
   * @param tableName имя таблицы (имя элемента @Name)
   * @param columnName имя столбца
   * @return индекс столбца
   */
  default Integer getIndexColumnByName(String tableName, String columnName) {
    List<Column> columns = getColumns(tableName);
    if (columns.isEmpty()) {
      return getColumnNames(tableName).indexOf(columnName);
    }

    return columns.stream()
        .filter(column -> column.name().equals(columnName))
        .map(Column::index)
        .findFirst()
        .orElseThrow(
            () ->
                new RuntimeException(
                    String.format("Столбца с именем '%s' не сущуствует", columnName)));
  }

  /**
   * Получить индексы столбцов таблицы
   *
   * @param tableName имя таблицы (имя элемента @Name)
   * @return список индексов столбцов
   */
  default List<Integer> getListIndexColumns(String tableName) {
    return getColumns(tableName).stream().map(Column::index).collect(Collectors.toList());
  }

  /**
   * Получить коллекцию элементов ElementsCollection всех строк таблицы (на одной странице)
   *
   * @param tableName имя таблицы (имя элемента @Name)
   * @return коллекции элементов ElementsCollection всех строк таблицы (на одной странице)
   */
  default List<WebElement> getRows(String tableName) {
    return DesktopDriverProvider.getDriver().findElements(By.xpath(getRowsLocator(tableName)));
  }

  /**
   * Получить xpath локатор столбца
   *
   * @param tableName имя таблицы
   * @param relativeXpath относительный xpath столбца
   * @return xpath локатор столбца
   */
  default String getColumnLocator(String tableName, String relativeXpath) {
    return getRowsLocator(tableName) + "/" + relativeXpath;
  }

  /**
   * Получить xpath локатор строк
   *
   * @param tableName имя таблицы
   * @return xpath локатор строк
   */
  default String getRowsLocator(String tableName) {
    Rows rowsAnnotation =
        Pages.getCurrentPage().getClassFieldByElementName(tableName).getAnnotation(Rows.class);

    if (rowsAnnotation == null) {
      return getTableLocator(tableName) + "/.//tbody//tr";
    }

    String rowsLocator = rowsAnnotation.xpath();
    if (!rowsAnnotation.isAbsolutePath()) {
      return getTableLocator(tableName) + "/" + rowsLocator;
    }

    return rowsLocator;
  }

  /**
   * Получить xpath локатор таблицы
   *
   * @param tableName имя таблицы
   * @return xpath локатор таблицы
   */
  default String getTableLocator(String tableName) {
    Field tableField = Pages.getCurrentPage().getClassFieldByElementName(tableName);

    return Arrays.stream(tableField.getAnnotationsByType(FindBy.class))
        .map(FindBy::xpath)
        .findFirst()
        .orElse(null);
  }

  /**
   * Получить количество строк в таблице (на одной странице)
   *
   * @param tableName имя таблицы (имя элемента @Name)
   * @return количество строк в таблице (на одной странице)
   */
  default Integer getRowsNumber(String tableName) {
    return getRows(tableName).size();
  }

  /**
   * Проверить, что данные во всех ячейках таблицы соответствуют данным из json'а, полученного с
   * бэка
   *
   * @param tableName имя таблицы (имя элемента @Name)
   * @param json данные с бэка, по которым фронт должен отрисовать таблицу
   */
  default void compareTableWithJson(String tableName, String json) {
    throw new StepImplementedException(StepImplementedException.ERROR_MESSAGE);
  }

  /**
   * Проверить кликабельность всех ячеек таблицы на соответствие таковым параметрам из json'а,
   * полученного с бэка
   *
   * @param tableName имя таблицы (имя элемента @Name)
   * @param json данные с бэка, по которым фронт должен отрисовать таблицу
   */
  default void compareTableCellsClickabilityWithJson(String tableName, String json) {
    throw new StepImplementedException(StepImplementedException.ERROR_MESSAGE);
  }

  /**
   * Метод для получения текстового значения в ячейке
   *
   * @param cellData объект с информацией о ячейке
   * @return текстовое значение ячейки (если указан regexp в параметрах ячейки, то применяем его)
   */
  default String getTextCellValue(CellData cellData) {
    String value =
        ((IDesktopApp) Pages.getCurrentPage()).getAnyElementText(cellData.getWebElement());
    if (cellData.getRegexp() == null || cellData.getRegexp().isEmpty()) {
      return value;
    }

    return StringHelper.getRegexpGroupValue(value, cellData.getRegexp(), cellData.getRegexpGroup());
  }

  /** Класс для описания ячейки таблицы */
  @Data
  public class CellData {

    int indexRow;
    int indexColumn;
    String xpathRows = ".//tbody//tr";
    String columnName;
    String xpathColumn;
    String regexp;
    int regexpGroup = 1;
    WebElement webElement;

    CellData(int indexRow, int indexColumn, WebElement webElement) {
      this.indexRow = indexRow;
      this.indexColumn = indexColumn;
      this.columnName = "Столбец" + indexColumn;
      this.xpathColumn = String.format(".//td[%s]", indexColumn + 1);
      this.webElement = webElement;
    }

    CellData(int indexRow, int indexColumn, String columnName, WebElement webElement) {
      this(indexRow, indexColumn, webElement);
      if (!columnName.isEmpty()) {
        this.columnName = columnName;
      }
    }

    public CellData(int indexRow, Column columnData, WebElement webElement) {
      this.indexRow = indexRow;
      this.indexColumn = columnData.index();
      this.columnName = columnData.name();
      this.xpathColumn = columnData.xpath();
      this.regexp = columnData.regexp();
      this.regexpGroup = columnData.regexpGroup();
      this.webElement = webElement;
    }

    CellData(int indexRow, Column columnData, Rows rowsData, WebElement webElement) {
      this(indexRow, columnData, webElement);
      xpathRows = rowsData.xpath();
    }
  }
}
