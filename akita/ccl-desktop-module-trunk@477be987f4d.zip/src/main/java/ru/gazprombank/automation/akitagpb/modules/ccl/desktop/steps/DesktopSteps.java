package ru.gazprombank.automation.akitagpb.modules.ccl.desktop.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static ru.gazprombank.automation.akitagpb.modules.ccl.helpers.StringHelper.processValue;

import FlaNium.WinAPI.DesktopElement;
import FlaNium.WinAPI.enums.BasePoint;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.ru.И;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.openqa.selenium.WebElement;
import ru.gazprombank.automation.akitagpb.modules.ccl.desktop.interfaces.IDesktopApp;
import ru.gazprombank.automation.akitagpb.modules.ccl.desktop.interfaces.ITableDesktop;
import ru.gazprombank.automation.akitagpb.modules.ccl.desktop.interfaces.ITableDesktop.CellData;
import ru.gazprombank.automation.akitagpb.modules.core.steps.isteps.IBaseMethods;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.AkitaPage;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;

public class DesktopSteps implements IBaseMethods {

  @И("^в десктоп-приложении выполнено закрытие модального окна с именем \"(.*)\"$")
  public void closeModalWindow(String elementName) {
    WebElement element = ((IDesktopApp) Pages.getCurrentPage()).getDesktopElement(elementName);
    new DesktopElement(element).castTo().toWindow().close();
  }

  @И("^в десктоп-приложении выполнено наведение на (?:элемент|кнопку|поле|блок) \"(.*)\"$")
  public void hoverElement(String elementName) {
    WebElement element = ((IDesktopApp) Pages.getCurrentPage()).getDesktopElement(elementName);
    new DesktopElement(element).mouseActions().mouseMove(BasePoint.CENTER, 0, 0);
  }

  @И(
      "^в десктоп-приложении выполнено нажатие на (?:элемент|кнопку|поле|блок) \"(.*)\" с параметрами xpath-(?:локатора|селектора):?$")
  public void clickWithXpathLocator(String elementName, List<String> args) {
    WebElement element =
        ((IDesktopApp) Pages.getCurrentPage())
            .getDesktopElement(elementName, args.toArray(String[]::new));
    element.click();
  }

  @И("^в десктоп-приложении выполнено нажатие правой кнопкой мыши на элементе \"(.*)\"$")
  public void mouseRightClick(String elementName) {
    WebElement element = ((IDesktopApp) Pages.getCurrentPage()).getDesktopElement(elementName);
    new DesktopElement(element).mouseActions().mouseRightClick(BasePoint.CENTER, 0, 0);
  }

  @И("^в десктоп-приложении в таблице( \"(.+)\")? есть строка, соответствующая параметрам:?$")
  public void assertTableContainsRowWithParams(String elementName, DataTable dataTable) {
    ITableDesktop currentPage = getCurrentPageAndCheckInstance();
    var parameters = getMapFromDataTable(dataTable);
    Map.Entry<Integer, Map<String, CellData>> row = currentPage.getRow(elementName, parameters);
    assertThat(row).as("Не удалось найти строку, соответствующую параметрам.").isNotNull();
  }

  @И(
      "^в десктоп-приложении в таблице( \"(.+)\")? выполнено( двойное)? нажатие по (?:(первой|последней) строке|строке с порядковым номером (\\d+))$")
  public void clickOnRowByIndex(
      String tableName, String isDoubleClick, String firstOrLastRow, Integer index) {
    ITableDesktop currentPage = getCurrentPageAndCheckInstance();
    index = getRowIndex(firstOrLastRow, index);
    WebElement row = currentPage.getRow(tableName, index);

    assertThat(row).as("Не удалось найти строку по номеру '" + index + "'").isNotNull();
    if (isDoubleClick != null) {
      new DesktopElement(row).mouseActions().mouseDoubleClick(BasePoint.CENTER, 0, 0);
    } else {
      row.click();
    }
  }

  @И("^в десктоп-приложении таблица \"(.+)\" содержит \"(.+)\" строк(?:у|и)?$")
  public void assertRowsNumberInTable(String elementName, String number) {
    ITableDesktop currentPage = getCurrentPageAndCheckInstance();
    var count = Integer.parseInt(processValue(number));
    var actualCount = currentPage.getRowsNumber(elementName);
    assertThat(actualCount)
        .as(
            String.format(
                "Число строк в таблице (%d) не равно ожидаемому (%d)", actualCount, count))
        .isEqualTo(count);
  }

  /**
   * Метод для получения индекса
   *
   * @param firstOrLastRow значение - первая или последня строка
   * @param index индекс
   * @return значение индекса
   */
  private Integer getRowIndex(String firstOrLastRow, Integer index) {
    return firstOrLastRow != null
        ? firstOrLastRow.startsWith("последн") ? null : 0
        : (Integer) (index - 1);
  }

  /**
   * Получить текущую страницу и проверить, что она является инстансом ITable.class
   *
   * @return текущую страницу
   */
  private ITableDesktop getCurrentPageAndCheckInstance() {
    AkitaPage currentPage = Pages.getCurrentPage();
    assertThat(currentPage)
        .as("Текущий блок не является таблицей!")
        .isInstanceOf(ITableDesktop.class);
    currentPage.isAppeared();
    return (ITableDesktop) currentPage;
  }

  /**
   * Преобразовать кукубмер-параметры шага из DataTable в Map. При этом пустые значения из DataTable
   * из null преобразуются в пустую строку "", и все значения параметризуются через processValue(v).
   *
   * @param dataTable кукубмер-параметры шага
   * @return параметры в виде Map
   */
  private Map<String, String> getMapFromDataTable(DataTable dataTable) {
    Map<String, String> result =
        new LinkedHashMap<>(); // новая мапа - для сохранения порядка параметров в изначальной
    // таблице
    dataTable
        .transpose()
        .asMap(String.class, String.class)
        .forEach(
            (k, v) -> {
              v = v == null ? "" : v;
              result.put(k, processValue(v));
            });
    return result;
  }
}
