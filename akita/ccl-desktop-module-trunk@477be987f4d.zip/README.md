# ccl-desktop-module
## Назначение сервиса
Сервис ccl-desktop-module предназначен для UI-тестирования Desktop-приложений на Windows, используя подход аналогичный веб-тестированию с Page Object Model. Требуется локальный запуск или агент для удаленного доступа. Сервис относится к домену автоматизации тестирования Desktop-приложений.
## Описание процесса
В сервисе реализован следующий бизнес-процесс: Автоматизация UI-тестов Desktop:
1. Создание PageObject для каждой формы Desktop-приложения, наследуемого от AkitaPage и реализующего IDesktopApp.
2. Подключение к приложению и его закрытие через кастомные шаги.
3. Управление элементами (наведение, нажатия, работа с таблицами) с использованием FlaNium.Driver.
4. Настройка драйвера через файл flanium_driver.properties.

<img src="https://bitbucket.dev.gazprombank.ru/projects/QA/repos/akita-gpb-core-module/raw/techdocs/docs/uml/scheme.png?at=refs%2Fheads%2Ftrunk" alt="Схема зависимостей" width="800" height="776">

## Конфигурация
Подход в написании тестов для Desktop-приложений аналогичен подходу при UI-тестировании Web-приложений:<br>
для каждой формы Desktop-приложения описывается PageObject, наследуемый от стандартной AkitaPage, а также имплементирующий IDesktopApp
```
@Name("Тесса")
public class TessaDesktopPage extends AkitaPage implements IDesktopApp
```
Для подключения к приложению и отключения от него требуются дополнительные методы, уникальные для каждого конкретного приложения (поэтому в данном
модуле их нет, необходимо писать самостоятельно в своём проекте).<br>
В нашем случае это реализовано отдельными шагами:
```
public class DesktopSteps implements IBaseMethods {

    @И("^выполнено подключение к приложению Тесса$")
    @SneakyThrows
    public static void desk() {
        FlaNiumDriver driver = DesktopDriverProvider.initDriver();
        try {
            driver.findElement(By.xpath("//Button[contains(@Name, 'GPBTessaAppManager') and @ControlType='Button']")).click();
        } catch (Exception e) {
            akitaScenario.log("Не выполнено подтверждение диалогового окна ТЕССА");
        } finally {
            driver.changeProcess("TessaClient", 30000);
        }
    }

    @И("^закрыть десктоп приложение Тесса$")
    @SneakyThrows
    public static void killProcess() {
        DesktopDriverProvider.getDriver().killAllProcessesByName("TessaClient");
    }
}
```
<br>
Также для управления Desktop-приложением из автотеста необходим драйвер - **_FlaNium.Driver_** (версия драйвера зависит от версии Windows, у нас 
сейчас - 2.2.1).<br>
Путь к драйверу указывается в файле **_flanium_driver.properties_**, который должен быть добавлен в ресурсах вашего проекта.<br>
Сам flanium_driver.properties выглядит так:

```
flanium.driver.remote=false
flanium.driver.remoteUrl=
flanium.driver.exe=src/main/resources/driver/FlaNium.Driver.exe
flanium.driver.port=0
flanium.driver.verbose=true
flanium.driver.silent=false
flanium.driver.timeout=20
#flanium.driver.logFile=
```

## Список шагов модуля
```
@И("^в десктоп-приложении выполнено закрытие модального окна с именем \"(.*)\"$")
@И("^в десктоп-приложении выполнено наведение на (?:элемент|кнопку|поле|блок) \"(.*)\"$")
@И("^в десктоп-приложении выполнено нажатие на (?:элемент|кнопку|поле|блок) \"(.*)\" с параметрами xpath-(?:локатора|селектора):?$")
@И("^в десктоп-приложении выполнено нажатие правой кнопкой мыши на элементе \"(.*)\"$")
@И("^в десктоп-приложении в таблице( \"(.+)\")? есть строка, соответствующая параметрам:?$")
@И("^в десктоп-приложении в таблице( \"(.+)\")? выполнено( двойное)? нажатие по (?:(первой|последней) строке|строке с порядковым номером (\\d+))$")
@И("^в десктоп-приложении таблица \"(.+)\" содержит \"(.+)\" строк(?:у|и)?$")
```

## Требования
Данный модуль зависит от модулей ccl-helpers-module и akita-gpb-api-module этого же проекта. <br>
Но эти зависимости добавляются посредством собранных jar-файлов, а не ссылкой на исходники модулей.<br>
Соответственно, для успешной сборки данного модуля jar-архивы зависимых модулей должен быть предварительно опубликованы в репозитории (локальном или
публичном).<br>
Также для взаимодействия с Desktop-приложением необходимо добавить в ресурсах файл **_flanium_driver.properties_**, драйвер **_FlaNium.Driver_**
(по тому пути, что будет указан в .properties-файле), кастомные методы в коде для подключения к вашему приложению, и PageObject-ы форм приложения
(см. Описание).

## Зависимости
```
ru.gazprombank.automation:ccl-helpers-module
ru.gazprombank.automation:akita-gpb-ui-module
com.github.lanit-exp:FlaNium.WinAPI
```

## Code style
В ccl-модулях НЕ используются плагины spotless и google-java-format
Формат кода осуществляется с помощью стилевой схемы Idea - описание [здесь](https://xxx.xxx.gazprombank.ru/display/GPBID/Code+style).

## Maintainers
Кайдаш Илья Васильевич - `ilya.kaydash@gazprombank.ru`<br>
Кислый Роман Александрович - `roman.kisly@gazprombank.ru`<br>
Мишечкин Павел Владимирович - `pavel.mishechkin@gazprombank.ru`<br>
