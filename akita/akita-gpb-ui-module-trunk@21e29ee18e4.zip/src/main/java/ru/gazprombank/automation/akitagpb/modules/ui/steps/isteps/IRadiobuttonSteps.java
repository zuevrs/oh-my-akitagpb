package ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps;

import ru.gazprombank.automation.akitagpb.modules.core.steps.isteps.StepImplementedException;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;

public interface IRadiobuttonSteps {

  default void clickRadiobutton(String elementName) {
    Pages.getCurrentPage().getElement(elementName).click();
  }

  default void checkRadiobuttonIsActive(String elementName) {
    throw new StepImplementedException(StepImplementedException.ERROR_MESSAGE);
  }

  default void checkRadiobuttonIsNotActive(String elementName) {
    throw new StepImplementedException(StepImplementedException.ERROR_MESSAGE);
  }

  default void actionForRadiobutton(Boolean action, String elementName) {

    Boolean selectedRadiobutton = Pages.getCurrentPage().getElement(elementName).isSelected();

    if (action && !selectedRadiobutton) {
      Pages.getCurrentPage().clickRadiobutton(elementName);
    }
    if (!action && selectedRadiobutton) {
      Pages.getCurrentPage().clickRadiobutton(elementName);
    }
  }
}
