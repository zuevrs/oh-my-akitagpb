package ru.gazprombank.automation.akitagpb.modules.ui.steps;

import static ru.gazprombank.automation.akitagpb.modules.core.cucumber.ScopedVariables.resolveVars;
import static ru.gazprombank.automation.akitagpb.modules.core.steps.isteps.IBaseMethods.baseMethod;

import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.ru.И;
import io.cucumber.java.ru.Тогда;
import java.util.List;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;

/** Шаги для взаимодействия с выпадающими списками, доступные по умолчанию в каждом новом проекте */
@Slf4j
public class DropDownListVerificationSteps extends UiBaseMethods {

  @Тогда("^выпадающий список \"(.*)\" содержит элементы$")
  public void dropDownContainsElements(String selectName, List<String> expectedValues) {
    expectedValues = resolveVarsInList(expectedValues);
    Pages.getCurrentPage().dropDownContainsElements(selectName, expectedValues);
  }

  @Тогда("^выпадающий список \"(.*)\" не содержит элементы$")
  public void dropDownNotContainsElements(String selectName, List<String> unexpectedValues) {
    unexpectedValues = resolveVarsInList(unexpectedValues);
    Pages.getCurrentPage().dropDownNotContainsElements(selectName, unexpectedValues);
  }

  @И("^в выпадающем списке \"(.*)\" выбранное значение равно \"(.*)\"$")
  public void dropDownSelectedText(String dropDownName, String expectedValue) {
    expectedValue = baseMethod.getPropertyOrStringVariableOrValue(resolveVars(expectedValue));
    Pages.getCurrentPage().dropDownSelectedText(dropDownName, expectedValue);
  }

  @И(
      "^в выпадающем списке \"(.*)\" с параметрами xpath-(?:локатора|селектора) выбранное значение равно \"(.*)\"$")
  public void dropDownWithXpathArgsSelectedText(
      String dropDownName, String expectedValue, List<String> args) {
    expectedValue = baseMethod.getPropertyOrStringVariableOrValue(resolveVars(expectedValue));
    SelenideElement dropDownElement =
        Pages.getCurrentPage().getElement(dropDownName, args.toArray(String[]::new));
    Pages.getCurrentPage().dropDownSelectedText(dropDownElement, expectedValue);
  }

  /**
   * Шаг для проверки, что в раскрывающемся списке со множественным выбором выбраны заданные
   * элементы
   *
   * @param selectName имя элемента (из аннотации Name) на page-object'е страницы
   * @param expectedValues список ожидаемых выбранных в списке элементов
   */
  @Тогда("^поле выпадающего списка \"(.*)\" содержит выбранные элементы:?$")
  public void dropDownContainsSelectedElements(String selectName, List<String> expectedValues) {
    expectedValues = resolveVarsInList(expectedValues);
    Pages.getCurrentPage().dropDownContainsSelectedElements(selectName, expectedValues);
  }

  private List<String> resolveVarsInList(List<String> varsList) {
    return varsList.stream()
        .map(e -> getPropertyOrStringVariableOrValue(resolveVars(e)))
        .collect(Collectors.toList());
  }
}
