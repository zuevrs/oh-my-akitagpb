package ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasSize;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import ru.gazprombank.automation.akitagpb.modules.core.helpers.PropertyLoader;
import ru.gazprombank.automation.akitagpb.modules.core.steps.BaseMethods;
import ru.gazprombank.automation.akitagpb.modules.core.steps.isteps.IBaseMethods;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;

/**
 * Шаги для взаимодействия с коллекциями элементов, доступные по умолчанию в каждом новом проекте
 */
public interface IListVerificationSteps extends IBaseMethods {

  default void listIsPresentedOnPage(String elementName) {
    ElementsCollection elements = Pages.getCurrentPage().getElementsList(elementName);
    Pages.getCurrentPage()
        .waitElementsUntil(Condition.appear, BaseMethods.DEFAULT_TIMEOUT, elements);
  }

  default void checkIfListContainsValueFromField(String variableListName, String elementName) {
    String actualValue = Pages.getCurrentPage().getAnyElementText(elementName);
    List<String> listFromVariable = ((List<String>) akitaScenario.getVar(variableListName));
    assertTrue(
        listFromVariable.contains(actualValue),
        String.format(
            "Список из переменной [%s] не содержит значение поля [%s]",
            variableListName, elementName));
  }

  default void checkIfListInnerTextConsistsOfTableElements(
      String listName, List<String> textTable) {
    List<String> actualValues = Pages.getCurrentPage().getAnyElementsListInnerTexts(listName);
    int numberOfTypes = actualValues.size();
    assertThat(
        String.format("Количество элементов в списке [%s] не соответсвует ожиданию", listName),
        textTable,
        hasSize(numberOfTypes));
    assertTrue(
        actualValues.containsAll(textTable),
        String.format(
            "Значения элементов в списке %s: %s не совпадают с ожидаемыми значениями из таблицы %s",
            listName, actualValues, textTable));
  }

  default void compareListFromUIAndFromVariable(String listName, String listVariable) {
    HashSet<String> expectedList = new HashSet<>((List<String>) akitaScenario.getVar(listVariable));
    HashSet<String> actualList =
        new HashSet<>(Pages.getCurrentPage().getAnyElementsListTexts(listName));
    assertThat(
        String.format(
            "Список со страницы [%s] не совпадает с ожидаемым списком из переменной [%s]",
            listName, listVariable),
        actualList,
        equalTo(expectedList));
  }

  default void checkListElementsContainsText(String listName, String expectedValue) {
    final String value = PropertyLoader.getPropertyOrValue(expectedValue);
    ElementsCollection listOfElementsFromPage = Pages.getCurrentPage().getElementsList(listName);
    List<String> elementsListText = listOfElementsFromPage.texts();
    assertTrue(
        elementsListText.stream()
            .allMatch(item -> item.trim().toLowerCase().contains(value.toLowerCase())),
        String.format(
            "Элемены списка %s: [%s] не содержат текст [%s] ", listName, elementsListText, value));
  }

  default void checkListElementsNotContainsText(String listName, String expectedValue) {
    final String value = PropertyLoader.getPropertyOrValue(expectedValue);
    ElementsCollection listOfElementsFromPage = Pages.getCurrentPage().getElementsList(listName);
    List<String> elementsListText = listOfElementsFromPage.texts();
    assertFalse(
        elementsListText.stream()
            .allMatch(item -> item.trim().toLowerCase().contains(value.toLowerCase())),
        String.format(
            "Элемены списка %s: [%s] содержат текст [%s] ", listName, elementsListText, value));
  }

  default void checkListTextsByRegExp(String listName, String pattern) {
    Pages.getCurrentPage()
        .getElementsList(listName)
        .forEach(
            element -> {
              String str = Pages.getCurrentPage().getAnyElementText(element);
              Assertions.assertTrue(
                  baseMethod.isTextMatches(str, pattern),
                  String.format(
                      "Текст '%s' из списка '%s' не соответствует формату регулярного выражения",
                      str, listName));
            });
  }

  default void listContainsNumberOfElements(String listName, int quantity) {
    ElementsCollection listOfElementsFromPage = Pages.getCurrentPage().getElementsList(listName);
    assertEquals(
        listOfElementsFromPage.size(),
        quantity,
        String.format(
            "Число элементов в списке отличается от ожидаемого: %s",
            listOfElementsFromPage.size()));
  }

  default void listContainsNumberFromVariable(String listName, String quantity) {
    int numberOfElements =
        baseMethod.getCounterFromString(baseMethod.getPropertyOrStringVariableOrValue(quantity));
    listContainsNumberOfElements(listName, numberOfElements);
  }

  default void listContainsMoreOrLessElements(String listName, String moreOrLess, int quantity) {
    ElementsCollection listOfElementsFromPage = Pages.getCurrentPage().getElementsList(listName);
    if ("более".equals(moreOrLess)) {
      assertTrue(
          listOfElementsFromPage.size() > quantity,
          String.format(
              "Число элементов списка меньше ожидаемого: %s", listOfElementsFromPage.size()));
    } else {
      assertTrue(
          listOfElementsFromPage.size() < quantity,
          String.format(
              "Число элементов списка превышает ожидаемое: %s", listOfElementsFromPage.size()));
    }
  }

  default void checkListInnerTextCorrespondsToListFromVariable(
      String listName, String listVariable) {
    List<String> expectedList = new ArrayList<>((List<String>) akitaScenario.getVar(listVariable));
    List<String> actualList =
        new ArrayList<>(Pages.getCurrentPage().getAnyElementsListInnerTexts(listName));
    assertThat(
        String.format(
            "Количество элементов списка %s = %s, ожидаемое значение = %s",
            listName, actualList.size(), expectedList.size()),
        actualList,
        hasSize(expectedList.size()));
    assertThat(
        String.format(
            "Список со страницы %s: %s не совпадает с ожидаемым списком из переменной %s:%s",
            listName, actualList, listVariable, expectedList),
        actualList,
        containsInAnyOrder(expectedList.toArray()));
  }
}
