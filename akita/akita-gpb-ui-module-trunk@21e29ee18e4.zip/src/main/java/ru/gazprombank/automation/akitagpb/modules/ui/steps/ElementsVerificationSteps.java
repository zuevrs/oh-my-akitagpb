package ru.gazprombank.automation.akitagpb.modules.ui.steps;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalToIgnoringCase;
import static org.hamcrest.Matchers.is;
import static ru.gazprombank.automation.akitagpb.modules.core.cucumber.ScopedVariables.resolveVars;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.ru.Тогда;
import java.time.Duration;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.hamcrest.Matchers;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;

/** Шаги, содержащие проверки элементов страницы, доступные по умолчанию в каждом новом проекте */
@Slf4j
public class ElementsVerificationSteps extends UiBaseMethods {

  @Тогда(
      "^(?:элемент|кнопка|поле|чекбокс|радиобаттон|текст|выпадающий список) \"(.*)\" отображается на странице")
  public void checkElementIsDisplayed(String elementName) {
    Pages.getCurrentPage().checkElementIsDisplayed(elementName);
  }

  @Тогда(
      "^(?:элемент|кнопка|поле|чекбокс|радиобаттон|текст|выпадающий список) \"(.*)\" с параметрами xpath-(?:локатора|селектора) отображается на странице")
  public void checkElementWithXpathArgsIsDisplayed(String elementName, List<String> args) {
    SelenideElement element =
        Pages.getCurrentPage().getElement(elementName, args.toArray(String[]::new));
    Pages.getCurrentPage().checkElementIsDisplayed(element);
  }

  @Тогда(
      "^(?:элемент|кнопка|поле|чекбокс|радиобаттон|текст|выпадающий список) \"(.*)\" не отображается на странице")
  public void checkElementIsNotDisplayed(String elementName) {
    Pages.getCurrentPage().checkElementIsNotDisplayed(elementName);
  }

  @Тогда(
      "^(?:элемент|кнопка|поле|чекбокс|радиобаттон|текст|выпадающий список) \"(.*)\" с параметрами xpath-(?:локатора|селектора) не отображается на странице")
  public void checkElementWithXpathArgsIsNotDisplayed(String elementName, List<String> args) {
    SelenideElement element =
        Pages.getCurrentPage().getElement(elementName, args.toArray(String[]::new));
    Pages.getCurrentPage().checkElementIsNotDisplayed(element);
  }

  /** Проверка появления элемента(не списка) на странице в течение заданного количества секунд */
  @Тогда("^элемент \"(.*)\" отобразился на странице в течение (\\d+) (?:секунд|секунды)")
  public void testElementAppeared(String elementName, int seconds) {
    Pages.getCurrentPage()
        .waitElementsUntil(
            Condition.appear, seconds * 1000, Pages.getCurrentPage().getElement(elementName));
  }

  @Тогда("^элемент с текстом \"(.+)\" (не отображается|отображается)? на странице$")
  public void isElementWithTextDisplayed(String text, String displayFlag) {
    String resolveText = getPropertyOrStringVariableOrValue(resolveVars(text));
    boolean elementIsDisplayed = Pages.getCurrentPage().isElementWithTextDisplayed(resolveText);

    assertThat(
        String.format(
            "Элемент с текстом \"%s\" не выполняет условие отображение на странице:\n"
                + "Текущие состояние: %s\n"
                + "Ожидаемое сотояние: %s",
            resolveText, elementIsDisplayed, "отображается".equals(displayFlag)),
        elementIsDisplayed,
        is("отображается".equals(displayFlag)));
  }

  /**
   * Проверка того, что элемент исчезнет со страницы (станет невидимым) в течение DEFAULT_TIMEOUT. В
   * случае, если свойство "waitingCustomElementsTimeout" в application.properties не задано,
   * таймаут равен 15 секундам
   */
  @Тогда("^ожидается исчезновение элемента \"(.*)\"")
  public void elemDisappeared(String elementName) {
    Pages.getCurrentPage()
        .waitElementsUntil(
            Condition.disappear, DEFAULT_TIMEOUT, Pages.getCurrentPage().getElement(elementName));
  }

  /**
   * Проверка того, что элемент исчезнет со страницы (станет невидимым) в течение указанного в шаге
   * таймаута (в секундах)
   */
  @Тогда("^ожидается исчезновение элемента \"(.*)\" в течение (\\d+) (?:секунд|секунды)")
  public void elemDisappeared(String elementName, int timeoutSeconds) {
    Pages.getCurrentPage()
        .getElement(elementName)
        .should(Condition.disappear, Duration.ofSeconds(timeoutSeconds));
  }

  /** Проверка того, что значение из поля совпадает со значением заданной переменной из хранилища */
  @Тогда("^значение (?:поля|элемента) \"(.*)\" совпадает со значением из переменной \"(.*)\"$")
  public void compareFieldAndVariable(String elementName, String variableName) {
    Pages.getCurrentPage().compareFieldAndVariable(elementName, variableName);
  }

  /** Проверка, что элемент на странице кликабелен */
  @Тогда("^(?:поле|элемент) \"(.*)\" кликабельно$")
  public void clickableField(String elementName) {
    Pages.getCurrentPage().clickableField(elementName);
  }

  /**
   * Проверка, что у элемента есть атрибут с ожидаемым значением (в приоритете: из property, из
   * переменной сценария, значение аргумента)
   */
  @Тогда("^элемент \"(.*)\" содержит атрибут \"(.*)\" со значением \"(.*)\"$")
  public void checkElemContainsAtrWithValue(
      String elementName, String attribute, String expectedAttributeValue) {
    expectedAttributeValue = getPropertyOrStringVariableOrValue(expectedAttributeValue);
    SelenideElement currentElement = Pages.getCurrentPage().getElement(elementName);
    String currentAtrValue = currentElement.attr(attribute);
    assertThat(
        String.format(
            "Элемент [%s] не содержит атрибут [%s] со значением [%s]",
            elementName, attribute, expectedAttributeValue),
        currentAtrValue,
        equalToIgnoringCase(expectedAttributeValue));
  }

  /**
   * Проверка, что элемент содержит указанный класс (в приоритете: из property, из переменной
   * сценария, значение аргумента) Например: если нужно проверить что элемент не отображается на
   * странице, но проверки Selenium отрабатывают неверно, можно использовать данный метод и
   * проверить, что среди его классов есть disabled
   */
  @Тогда("^элемент \"(.*)\" содержит класс со значением \"(.*)\"$")
  public void checkElemClassContainsExpectedValue(String elementName, String expectedClassValue) {
    SelenideElement currentElement = Pages.getCurrentPage().getElement(elementName);
    expectedClassValue = getPropertyOrStringVariableOrValue(expectedClassValue);
    String currentClassValue = currentElement.getAttribute("class");
    assertThat(
        String.format(
            "Элемент [%s] не содержит класс со значением [%s]", elementName, expectedClassValue),
        currentClassValue.toLowerCase(),
        containsString(expectedClassValue.toLowerCase()));
  }

  /** Проверка, что элемент не содержит указанный класс */
  @Тогда("^элемент \"(.*)\" не содержит класс со значением \"(.*)\"$")
  public void checkElemClassNotContainsExpectedValue(
      String elementName, String expectedClassValue) {
    SelenideElement currentElement = Pages.getCurrentPage().getElement(elementName);
    assertThat(
        String.format(
            "Элемент [%s] содержит класс со значением [%s]", elementName, expectedClassValue),
        currentElement.getAttribute("class").toLowerCase(),
        Matchers.not(
            containsString(getPropertyOrStringVariableOrValue(expectedClassValue).toLowerCase())));
  }

  /**
   * Проверка, что значение в поле содержит значение (в приоритете: из property, из переменной
   * сценария, значение аргумента), указанное в шаге
   */
  @Тогда("^(?:поле|элемент) \"(.*)\" содержит значение \"(.*)\"$")
  public void testActualValueContainsSubstring(String elementName, String expectedValue) {
    Pages.getCurrentPage().testActualValueContainsSubstring(elementName, expectedValue);
  }

  /** Проверка, что значение в поле не содержит значение */
  @Тогда("^(?:поле|элемент) \"(.*)\" не содержит значение \"(.*)\"$")
  public void testActualValueNotContainsSubstring(String elementName, String expectedValue) {
    Pages.getCurrentPage().testActualValueNotContainsSubstring(elementName, expectedValue);
  }

  /**
   * Проверка, что значение в поле(с параметрами xpath) содержит значение (в приоритете: из
   * property, из переменной сценария, значение аргумента), указанное в шаге
   */
  @Тогда(
      "^(?:поле|элемент) \"(.*)\" с параметрами xpath-(?:локатора|селектора) содержит значение \"(.*)\"$")
  public void elementWithXpathArgsContainsText(
      String elementName, String expectedValue, List<String> args) {
    Pages.getCurrentPage().elementWithXpathArgsContainsText(elementName, expectedValue, args);
  }

  /**
   * Проверка, что значение в поле содержит текст, указанный в шаге (в приоритете: из property, из
   * переменной сценария, значение аргумента). Используется метод innerText(), который получает как
   * видимый, так и скрытый текст из элемента, обрезая перенос строк и пробелы в конце и начале
   * строчки. Не чувствителен к регистру
   */
  @Тогда("^(?:поле|элемент) \"(.*)\" содержит внутренний текст \"(.*)\"$")
  public void testFieldContainsInnerText(String fieldName, String expectedText) {
    Pages.getCurrentPage().testFieldContainsInnerText(fieldName, expectedText);
  }

  /**
   * Проверка, что значение в поле не содержит текст, указанный в шаге. Используется метод
   * innerText(), который получает как видимый, так и скрытый текст из элемента, обрезая перенос
   * строк и пробелы в конце и начале строчки. Не чувствителен к регистру
   */
  @Тогда("^(?:поле|элемент) \"(.*)\" не содержит внутренний текст \"(.*)\"$")
  public void testFieldNotContainsInnerText(String fieldName, String expectedText) {
    Pages.getCurrentPage().testFieldNotContainsInnerText(fieldName, expectedText);
  }

  /**
   * Проверка, что значение в поле равно значению, указанному в шаге (в приоритете: из property, из
   * переменной сценария, значение аргумента)
   */
  @Тогда("^значение (?:поля|элемента) \"(.*)\" равно \"(.*)\"$")
  public void compareValInFieldAndFromStep(String elementName, String expectedValue) {
    Pages.getCurrentPage().compareValInFieldAndFromStep(elementName, expectedValue);
  }

  /**
   * Проверка, что кнопка/ссылка недоступна для нажатия, поле или элемент не доступен для
   * редактирования
   */
  @Тогда(
      "^(?:ссылка|элемент|кнопка|поле|чекбокс|радиобаттон|выпадающий список) \"(.*)\" (?:недоступно|недоступен|недоступна)$")
  public void fieldIsDisable(String elementName) {
    Pages.getCurrentPage().fieldIsDisable(elementName);
  }

  /**
   * Проверка, что кнопка/ссылка доступна для нажатия, поле или элемент не доступен для
   * редактирования
   */
  @Тогда(
      "^(?:ссылка|элемент|кнопка|поле|чекбокс|радиобаттон|выпадающий список) \"(.*)\" (?:доступно|доступен|доступна)$")
  public void fieldIsNotDisable(String elementName) {
    Pages.getCurrentPage().fieldIsNotDisable(elementName);
  }

  /** Производится проверка количества символов в поле со значением, указанным в шаге */
  @Тогда("^в поле \"(.*)\" содержится (\\d+) символов$")
  public void checkFieldSymbolsCount(String element, int num) {
    Pages.getCurrentPage().checkFieldSymbolsCount(element, num);
  }

  /** Проверка, что поле для ввода пусто */
  @Тогда("^поле \"(.*)\" пусто$")
  public void fieldInputIsEmpty(String fieldName) {
    Pages.getCurrentPage().fieldInputIsEmpty(fieldName);
  }
}
