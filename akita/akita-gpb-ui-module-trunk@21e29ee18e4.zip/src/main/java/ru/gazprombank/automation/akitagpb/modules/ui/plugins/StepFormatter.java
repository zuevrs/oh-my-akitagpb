package ru.gazprombank.automation.akitagpb.modules.ui.plugins;

import static com.codeborne.selenide.WebDriverRunner.getWebDriver;
import static com.codeborne.selenide.WebDriverRunner.hasWebDriverStarted;

import io.cucumber.plugin.EventListener;
import io.cucumber.plugin.event.EventHandler;
import io.cucumber.plugin.event.EventPublisher;
import io.cucumber.plugin.event.TestStep;
import io.cucumber.plugin.event.TestStepFinished;
import java.lang.reflect.Method;
import java.util.List;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import ru.gazprombank.automation.akitagpb.modules.core.cucumber.api.AkitaScenario;
import ru.gazprombank.automation.akitagpb.modules.core.cucumber.api.AnnotationScanner;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.annotations.Screenshot;

/**
 * При подключении StepFormatter к проеку с тестами, становится достуна опция снятия скриншотов
 * после каждого шага. Для этого необходимо задать системную переменную
 * takeScreenshotAfterSteps=true Скриншот так же будет сниматься после каждого метода, помеченного
 * аннотацией @Screenshot
 */
@Slf4j
public class StepFormatter implements EventListener {

  private static final String SCREENSHOT_AFTER_STEPS = "takeScreenshotAfterSteps";
  private static final boolean MAKE_SCREENSHOT = getScreenshotProperty();

  private static boolean getScreenshotProperty() {
    String propertyValue = System.getProperty(SCREENSHOT_AFTER_STEPS);
    return propertyValue != null && Boolean.parseBoolean(propertyValue);
  }

  @Override
  public void setEventPublisher(EventPublisher publisher) {
    publisher.registerHandlerFor(TestStepFinished.class, getTestStepFinishedHandler());
  }

  private EventHandler<TestStepFinished> getTestStepFinishedHandler() {
    return this::handleTestStepFinished;
  }

  private void handleTestStepFinished(TestStepFinished event) {
    // TODO: Возможно, тут стоит придумать другое условие (прежнее не работало)
    if (hasWebDriverStarted()) {
      afterStep(event.getTestStep());
    }
  }

  /**
   * Метод осуществляет снятие скришота и прикрепление его к cucumber отчету. Скриншот снимается
   * после шагов, помеченных аннотацией @Screenshot, либо после каждого шага, если задана системная
   * переменная takeScreenshotAfterSteps=true
   *
   * @param testStep - текущий шаг
   */
  private void afterStep(TestStep testStep) {
    String fullMethodLocation = testStep.getCodeLocation();
    String currentMethodName =
        fullMethodLocation.substring(
            fullMethodLocation.indexOf('.') + 1, fullMethodLocation.indexOf('('));

    List<Method> methodsWithScreenshotAnnotation =
        new AnnotationScanner()
            .getMethodsAnnotatedWith(Screenshot.class).stream()
                .filter(m -> m.getName().contains(currentMethodName))
                .collect(Collectors.toList());

    boolean isScreenshotAnnotationPresent = methodsWithScreenshotAnnotation.size() > 0;

    if (isScreenshotAnnotationPresent || MAKE_SCREENSHOT) {
      final byte[] screenshot =
          ((TakesScreenshot) getWebDriver()).getScreenshotAs(OutputType.BYTES);
      // TODO: В настоящий момент скриншоты не крепятся, надо как-то это исправить
      AkitaScenario.getInstance().getScenario().attach(screenshot, "image/png", "StepScreenshot");
      //            Allure.getLifecycle().addAttachment("StepScreenshot", "image/png", "png",
      // screenshot);
      //            Allure.addByteAttachmentAsync("StepScreenshot", "image/png", ()-> screenshot);

    }
  }
}
