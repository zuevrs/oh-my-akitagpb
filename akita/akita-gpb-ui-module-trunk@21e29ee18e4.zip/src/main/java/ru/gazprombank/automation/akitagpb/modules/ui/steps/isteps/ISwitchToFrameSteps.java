package ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps;

import static com.codeborne.selenide.Selenide.$x;

import com.codeborne.selenide.Selenide;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;

public interface ISwitchToFrameSteps {

  default void switchToFrame(String frameName) {
    Selenide.switchTo().frame(Pages.getCurrentPage().getElement(frameName));
  }

  default void switchToFrame() {
    Selenide.switchTo().frame($x("//iframe"));
  }

  default void switchToDefaultContent() {
    Selenide.switchTo().defaultContent();
  }
}
