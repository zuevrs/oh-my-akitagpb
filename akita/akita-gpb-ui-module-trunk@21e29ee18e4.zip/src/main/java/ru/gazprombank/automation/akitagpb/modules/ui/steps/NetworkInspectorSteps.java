package ru.gazprombank.automation.akitagpb.modules.ui.steps;

import static ru.gazprombank.automation.akitagpb.modules.ui.hooks.devtools.DevToolsManager.*;

import com.codeborne.selenide.Selenide;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.JsonPath;
import io.cucumber.java.ru.И;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Comparator;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.devtools.Command;
import org.openqa.selenium.devtools.v142.fetch.Fetch;
import org.openqa.selenium.devtools.v142.fetch.model.RequestPaused;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import ru.gazprombank.automation.akitagpb.modules.core.steps.BaseMethods;
import ru.gazprombank.automation.akitagpb.modules.ui.hooks.devtools.DevToolsManager;
import ru.gazprombank.automation.akitagpb.modules.ui.hooks.devtools.RequestNode;
import ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps.IWebPageVerificationSteps;

public class NetworkInspectorSteps implements IWebPageVerificationSteps {
  public static final DevToolsManager devToolsManager = new DevToolsManager();

  @И("^запустить инспектор сети$")
  public void startNetworkListener() {
    devToolsManager.initAndStartListener();
  }

  @И(
      "^из тела ответа по url \"(.*)\" получим значение по json выборке \"(.*)\" и запишем в переменную \"(.*)\"")
  public void getValueFromResponseBodyByUrlAndJsonPathAndWriteToVar(
      String url, String path, String variableName) throws InterruptedException {
    System.out.println("=== Поиск тела ответа | url: " + url + " | path: " + path + " ===");
    String body = null;
    RequestNode node = null;
    for (int i = 1; i < 6; i++) {
      node = findLatestNodeWithResponseBody(url).orElse(null);
      if (node == null) {
        System.out.println("попытка " + i + " — нода с responseBody не найдена, ждём 3s...");
      } else {
        System.out.println(
            "попытка "
                + i
                + " — нода найдена ["
                + node.getMethod()
                + "] "
                + node.getUrl()
                + " | statusCode: "
                + node.getStatusCode()
                + " | responseBody: есть");
        body = node.getResponseBody();
      }
      if (body != null) {
        System.out.println("responseBody найден на попытке " + i);
        System.out.println("=== НАЙДЕННАЯ НОДА ===");
        System.out.println("[" + node.getMethod() + "] " + node.getUrl());
        System.out.println("statusCode:   " + node.getStatusCode());
        System.out.println("requestBody:  " + node.getRequestBody());
        System.out.println("responseBody: " + node.getResponseBody());
        System.out.println("=====================");
        break;
      }
      Thread.sleep(3000);
    }
    SoftAssertions soft = new SoftAssertions();
    soft.assertThat(body)
        .withFailMessage("responseBody не найден после всех попыток для url: " + url)
        .isNotNull()
        .isNotBlank();
    soft.assertAll();
    Object rawValue = JsonPath.read(body, path);
    String value;
    try {
      value =
          rawValue instanceof String
              ? (String) rawValue
              : new ObjectMapper().writeValueAsString(rawValue);
    } catch (Exception e) {
      throw new RuntimeException(
          "не удалось сериализовать значение по jsonPath [" + path + "]: " + e.getMessage());
    }
    soft.assertThat(value)
        .withFailMessage("значение по jsonPath [" + path + "] равно null для url: " + url)
        .isNotNull();
    soft.assertAll();
    System.out.println("jsonPath [" + path + "] = " + value);
    akitaScenario.log(variableName + ": " + value);
    this.akitaScenario.setVar(variableName, value);
  }

  @И(
      "^из тела запроса по url \"(.*)\" получим значение по json выборке \"(.*)\" и запишем в переменную \"(.*)\"")
  public void getValueFromRequestBodyByUrlAndJsonPathAndWriteToVar(
      String url, String path, String variableName) throws InterruptedException {
    System.out.println("=== Поиск тела запроса | url: " + url + " | path: " + path + " ===");
    String body = null;
    RequestNode node = null;
    for (int i = 1; i < 6; i++) {
      node = findLatestNodeWithRequestBody(url).orElse(null);
      if (node == null) {
        System.out.println("попытка " + i + " — нода с requestBody не найдена, ждём 3s...");
      } else {
        System.out.println(
            "попытка "
                + i
                + " — нода найдена ["
                + node.getMethod()
                + "] "
                + node.getUrl()
                + " | requestBody: есть");
        body = node.getRequestBody();
      }
      if (body != null) {
        System.out.println("requestBody найден на попытке " + i);
        System.out.println("=== НАЙДЕННАЯ НОДА ===");
        System.out.println("[" + node.getMethod() + "] " + node.getUrl());
        System.out.println("statusCode:   " + node.getStatusCode());
        System.out.println("requestBody:  " + node.getRequestBody());
        System.out.println("responseBody: " + node.getResponseBody());
        System.out.println("=====================");
        break;
      }
      Thread.sleep(3000);
    }
    SoftAssertions soft = new SoftAssertions();
    soft.assertThat(body)
        .withFailMessage("requestBody не найден после всех попыток для url: " + url)
        .isNotNull()
        .isNotBlank();
    soft.assertAll();
    Object rawValue = JsonPath.read(body, path);
    String value;
    try {
      value =
          rawValue instanceof String
              ? (String) rawValue
              : new ObjectMapper().writeValueAsString(rawValue);
    } catch (Exception e) {
      throw new RuntimeException(
          "не удалось сериализовать значение по jsonPath [" + path + "]: " + e.getMessage());
    }
    soft.assertThat(value)
        .withFailMessage("значение по jsonPath [" + path + "] равно null для url: " + url)
        .isNotNull();
    soft.assertAll();
    System.out.println("jsonPath [" + path + "] = " + value);
    akitaScenario.log(variableName + ": " + value);
    this.akitaScenario.setVar(variableName, value);
  }

  private Optional<RequestNode> findLatestNode(String url) {
    return devToolsManager.getRequestNodes().stream()
        .filter(n -> n.getUrl() != null && n.getUrl().contains(url))
        .max(Comparator.comparingLong(RequestNode::getTime));
  }

  private Optional<RequestNode> findLatestNodeWithResponseBody(String url) {
    return devToolsManager.getRequestNodes().stream()
        .filter(n -> n.getUrl() != null && n.getUrl().contains(url))
        .filter(n -> n.getResponseBody() != null && !n.getResponseBody().isBlank())
        .max(Comparator.comparingLong(RequestNode::getTime));
  }

  private Optional<RequestNode> findLatestNodeWithRequestBody(String url) {
    return devToolsManager.getRequestNodes().stream()
        .filter(n -> n.getUrl() != null && n.getUrl().contains(url))
        .filter(n -> n.getRequestBody() != null && !n.getRequestBody().isBlank())
        .max(Comparator.comparingLong(RequestNode::getTime));
  }

  @И("^получим тело ответа по url \"(.*)\"$")
  public String getResponseBodyByUrl(String url) {
    return findLatestNode(url)
        .map(RequestNode::getResponseBody)
        .filter(b -> b != null && !b.isBlank())
        .orElse(null);
  }

  @И("^получим тело запроса по url \"(.*)\"$")
  public String getRequestBodyByUrl(String url) {
    return findLatestNode(url)
        .map(RequestNode::getRequestBody)
        .filter(b -> b != null && !b.isBlank())
        .orElse(null);
  }

  @И("создали фронтовый мок с кодом ответа {int} на запрос {string}")
  public void makeSimpleUiMock(int code, String endpoint) {
    String endpointValue = BaseMethods.getPropertyOrStringVariableOrValueAndReplace(endpoint);
    Function<RequestPaused, Command<Void>> function =
        request ->
            Fetch.fulfillRequest(
                request.getRequestId(),
                code,
                Optional.of(getCorsHeaders(request)),
                Optional.empty(),
                Optional.empty(),
                Optional.of(getRespPhrase(code)));
    Function<RequestPaused, Boolean> condition =
        request -> {
          String url = request.getRequest().getUrl();
          String method = request.getRequest().getMethod();
          if ("OPTIONS".equals(method)) return false;
          if ("POST".equals(method) || "GET".equals(method)) {
            return url.equals(endpointValue)
                || url.startsWith(endpointValue + "?")
                || url.startsWith(endpointValue + "/");
          }
          return false;
        };
    devToolsManager.registerMock(endpointValue, null, function, condition);
  }

  @И("создали фронтовый мок на запрос {string} с кодом ответа {int} и телом ответа {string}")
  public void makeUiMockWithResp133(String endpoint, int code, String path) {
    String endpointValue = BaseMethods.getPropertyOrStringVariableOrValueAndReplace(endpoint);
    akitaScenario.log(String.format("endpoint: %s", endpointValue));
    String body = getFrontMockSample(path);
    Function<RequestPaused, Command<Void>> requestCommand =
        request ->
            Fetch.fulfillRequest(
                request.getRequestId(),
                code,
                Optional.of(getCorsHeaders(request)),
                Optional.empty(),
                Optional.of(Base64.getEncoder().encodeToString(body.getBytes())),
                Optional.of(getRespPhrase(code)));
    Function<RequestPaused, Boolean> requestEntryCondition =
        request -> {
          String url = request.getRequest().getUrl();
          String method = request.getRequest().getMethod();
          if ("OPTIONS".equals(method)) return false;
          if ("POST".equals(method) || "GET".equals(method)) {
            return url.equals(endpointValue)
                || url.startsWith(endpointValue + "?")
                || url.startsWith(endpointValue + "/");
          }
          return false;
        };
    devToolsManager.registerMock(endpointValue, body, requestCommand, requestEntryCondition);
  }

  @И(
      "создали фронтовый мок на запрос {string} с кодом ответа {int} и телом ответа {string} с параметрами")
  public void makeUiMockWithParameterisedResp(
      String endpoint, int code, String path, Map<String, String> params) {
    String endpointValue = BaseMethods.getPropertyOrStringVariableOrValueAndReplace(endpoint);
    String frontMockSample = getFrontMockSample(path);
    String body = BaseMethods.replaceVarsInStringByParams(frontMockSample, params);
    Function<RequestPaused, Command<Void>> function =
        request ->
            Fetch.fulfillRequest(
                request.getRequestId(),
                code,
                Optional.of(getCorsHeaders(request)),
                Optional.empty(),
                Optional.of(
                    Base64.getEncoder().encodeToString(body.getBytes(StandardCharsets.UTF_8))),
                Optional.of(getRespPhrase(code)));
    Function<RequestPaused, Boolean> condition =
        request -> {
          String url = request.getRequest().getUrl();
          String method = request.getRequest().getMethod();
          if ("OPTIONS".equals(method)) return false;
          if ("POST".equals(method) || "GET".equals(method)) {
            return url.equals(endpointValue)
                || url.startsWith(endpointValue + "?")
                || url.startsWith(endpointValue + "/");
          }
          return false;
        };
    devToolsManager.registerMock(endpointValue, body, function, condition);
  }

  @И("создали фронтовый мок с кодом ответа {int} на запрос по регулярке {string}")
  public void makeSimpleUiMockRegex(int code, String regex) {
    Function<RequestPaused, Command<Void>> function =
        request ->
            Fetch.fulfillRequest(
                request.getRequestId(),
                code,
                Optional.of(getCorsHeaders(request)),
                Optional.empty(),
                Optional.empty(),
                Optional.of(getRespPhrase(code)));
    Function<RequestPaused, Boolean> condition =
        request -> {
          String url = request.getRequest().getUrl();
          if ("OPTIONS".equals(request.getRequest().getMethod())) return false;
          return url.matches(".*" + regex + ".*") && getQueryFromURL(url) == null;
        };
    devToolsManager.registerMock(regex, null, function, condition);
  }

  @И("^очистим листенеры и историю запросов$")
  public void clearListeners() {
    devToolsManager.clearListeners();
    devToolsManager.clearRequestNodes();
    devToolsManager.clearMocks();
  }

  @И("^закроем DevTools$")
  public void closeDevTools() {
    devToolsManager.closeDevTools();
  }

  @И("^очистим список запросов$")
  public void clearRequestNodes() {
    devToolsManager.clearRequestNodes();
  }

  @И("сбросили фронтовый мок на запрос {string}")
  public void removeMock(String endpoint) {
    String endpointValue = BaseMethods.getPropertyOrStringVariableOrValueAndReplace(endpoint);
    devToolsManager.removeMock(endpointValue);
  }

  @И("выполнен запрос к {string} методом {string}. Ответ от мока равен {string}")
  public void executeRequestAndCheckMockResponse(String url, String method, String expectedFilePath)
      throws Exception {
    String fullUrl = BaseMethods.getPropertyOrStringVariableOrValueAndReplace(url);
    akitaScenario.log("Выполняем тестовый запрос к: " + fullUrl);
    akitaScenario.log("Метод: " + method);
    String jsCode =
        String.format(
            """
                return (async () => {
                    try {
                        const response = await fetch('%s', {
                            method: '%s',
                            headers: {
                                'Content-Type': 'application/json'
                            }
                        });
                        const text = await response.text();
                        return {
                            status: response.status,
                            body: text,
                            ok: response.ok
                        };
                    } catch (e) {
                        return { error: e.message };
                    }
                })();
                """,
            fullUrl.replace("'", "\\'"), method);
    Map<String, Object> result = Selenide.executeJavaScript(jsCode);
    int status = ((Number) result.get("status")).intValue();
    String body = (String) result.get("body");
    akitaScenario.log("Получен ответ от мока со статусом: " + status);
    akitaScenario.log("Тело ответа от мока:\n" + body);
    String expectedJson = getFrontMockSample(expectedFilePath);
    JSONAssert.assertEquals(expectedJson, body, JSONCompareMode.LENIENT);
  }
}
