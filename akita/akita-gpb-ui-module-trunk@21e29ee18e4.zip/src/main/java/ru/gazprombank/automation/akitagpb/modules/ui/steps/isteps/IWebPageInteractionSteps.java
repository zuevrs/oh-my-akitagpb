package ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.atBottom;
import static com.codeborne.selenide.Selenide.executeJavaScript;
import static com.codeborne.selenide.Selenide.open;
import static com.codeborne.selenide.Selenide.sleep;
import static com.codeborne.selenide.WebDriverRunner.getWebDriver;
import static com.codeborne.selenide.WebDriverRunner.url;
import static org.hamcrest.MatcherAssert.assertThat;
import static ru.gazprombank.automation.akitagpb.modules.core.cucumber.ScopedVariables.resolveVars;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import ru.gazprombank.automation.akitagpb.modules.core.helpers.ConfigLoader;
import ru.gazprombank.automation.akitagpb.modules.core.hooks.statistics.StatisticsHooks;
import ru.gazprombank.automation.akitagpb.modules.core.steps.BaseMethods;
import ru.gazprombank.automation.akitagpb.modules.core.steps.isteps.IBaseMethods;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;
import ru.gazprombank.automation.akitagpb.modules.ui.steps.UiBaseMethods;

/** Шаги для взаимодействия с вэб-страницей, доступные по умолчанию в каждом новом проекте */
public interface IWebPageInteractionSteps extends IBaseMethods {

  default void goToSelectedPageByLink(String pageName, String urlOrName) {
    String address =
        BaseMethods.getInstance().getPropertyOrStringVariableOrValue(resolveVars(urlOrName));
    akitaScenario.log(" url = " + address);
    StatisticsHooks.getInstance().addEndpoint(address);
    open(address);
    UiBaseMethods.loadPage(pageName);
  }

  default void urlClickAndCheckRedirection(String pageName, String elementName) {
    Pages.getCurrentPage().getElement(elementName).click();
    UiBaseMethods.loadPage(pageName);
    akitaScenario.log(" url = " + url());
  }

  default void loginByUserData(String userCode) {
    String login = ConfigLoader.getConfigValue(userCode + ".login");
    String password = ConfigLoader.getConfigValue(userCode + ".password");
    UiBaseMethods.cleanField("Логин");
    Pages.getCurrentPage().getElement("Логин").sendKeys(login);
    UiBaseMethods.cleanField("Пароль");
    Pages.getCurrentPage().getElement("Пароль").sendKeys(password);
    Pages.getCurrentPage().getElement("Войти").click();
  }

  default void scrollWhileElemNotFoundOnPage(String elementName) {
    SelenideElement el = null;
    do {
      el = Pages.getCurrentPage().getElement(elementName);
      if (el.exists()) {
        break;
      }
      executeJavaScript("return window.scrollBy(0, 250);");
      sleep(1000);
    } while (!atBottom());
    assertThat("Элемент " + elementName + " не найден", el.isDisplayed());
  }

  default void scrollWhileElemWithTextNotFoundOnPage(String expectedValue) {
    SelenideElement el = null;
    do {
      el =
          $(
              By.xpath(
                  UiBaseMethods.getTranslateNormalizeSpaceText(
                      baseMethod.getPropertyOrStringVariableOrValue(expectedValue))));
      if (el.exists()) {
        break;
      }
      executeJavaScript("return window.scrollBy(0, 250);");
      sleep(1000);
    } while (!atBottom());
    assertThat("Элемент с текстом " + expectedValue + " не найден", el.isDisplayed());
  }

  default void scrollToEndPage() {
    Actions actions = new Actions(getWebDriver());
    actions.keyDown(Keys.CONTROL).sendKeys(Keys.END).build().perform();
    actions.keyUp(Keys.CONTROL).perform();
  }
}
