package ru.gazprombank.automation.akitagpb.modules.ui.steps;

import com.codeborne.selenide.WebDriverRunner;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import java.time.Duration;
import java.util.ArrayList;
import lombok.SneakyThrows;
import lombok.extern.apachecommons.CommonsLog;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.remote.RemoteWebDriver;
import ru.gazprombank.automation.akitagpb.modules.api.steps.ApiBaseMethods;

/** Шаги для взаимодействия с Selenoid */
@CommonsLog
public class SelenoidRemoteSteps {

  private static final String REMOTE_URL = System.getenv().get("GGR_URL");
  private static final String REMOTE_LOGIN = System.getenv().get("GGR_LOGIN");
  private static final String REMOTE_PASSWORD = System.getenv().get("GGR_PASSWORD");
  private static final String REMOTE_PORT = System.getenv().get("GGR_PORT");
  private static final String REMOTE_FULL_ADDRESS = "%s:%s";

  private SelenoidRemoteSteps() {}

  /**
   * Выполняется загрузка файла из Selenoid контейнера. Необходимо указать зачения для переменных
   * REMOTE_URL, REMOTE_LOGIN, REMOTE_PASSWORD, REMOTE_PORT
   */
  @SneakyThrows
  public static Response downloadFileFromSelenoidContainer(String fileName) {
    final String[] sessionId = {null};
    Assertions.assertTimeout(
        Duration.ofSeconds(10),
        () -> {
          while (sessionId[0] == null) {
            sessionId[0] = getSessionIdFromSelenoidContainer();
          }
        },
        "Не удалось получить sessionId");
    log.info("SessionId : " + sessionId[0]);
    var address =
        "http://"
            + String.format(REMOTE_FULL_ADDRESS, REMOTE_URL, REMOTE_PORT)
            + "/download/"
            + sessionId[0]
            + "/"
            + fileName;
    RequestSpecification request =
        RestAssured.given().auth().preemptive().basic(REMOTE_LOGIN, REMOTE_PASSWORD);
    return request.when().header("Content-Type", "application/pdf").get(address);
  }

  @SneakyThrows
  public static Response deleteDownloadFileFromSelenoidContainer(String fileName) {
    var address =
        "http://"
            + String.format(REMOTE_FULL_ADDRESS, REMOTE_URL, REMOTE_PORT)
            + "/download/"
            + getSessionIdFromSelenoidContainer()
            + "/"
            + fileName;
    return ApiBaseMethods.sendRequest("DELETE", address, new ArrayList<>());
  }

  private static String getSessionIdFromSelenoidContainer() {
    return ((RemoteWebDriver) WebDriverRunner.getWebDriver()).getSessionId().toString();
  }
}
