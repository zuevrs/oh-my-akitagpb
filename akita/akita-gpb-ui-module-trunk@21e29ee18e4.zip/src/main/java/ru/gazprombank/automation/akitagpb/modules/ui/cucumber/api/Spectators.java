package ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api;

import com.codeborne.selenide.CollectionCondition;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.WebElementCondition;
import com.codeborne.selenide.WebElementsCondition;
import java.time.Duration;
import java.util.Arrays;
import java.util.Collection;

public final class Spectators {

  private Spectators() {}

  /**
   * Обертка над Selenide waitUntil для произвольного числа элементов
   *
   * @param selenideCondition Selenide.Condition
   * @param timeout максимальное время ожидания в миллисекундах для перехода элементов в заданное
   *     состояние
   * @param selenideElements произвольное количество selenide-элементов
   * @see SelenideElement#shouldHave(WebElementCondition, Duration)
   */
  public static void waitElementsUntil(
      WebElementCondition selenideCondition, int timeout, SelenideElement... selenideElements) {
    Arrays.stream(selenideElements)
        .forEach(e -> e.shouldHave(selenideCondition, Duration.ofMillis(timeout)));
  }

  /**
   * Перегрузка метода для работы с ElementsCollection и использования стандартных методов обработки
   * списков
   *
   * @param selenideCondition Selenide.Condition
   * @param timeout максимальное время ожидания в миллисекундах для перехода элементов в заданное
   *     состояние
   * @param selenideElements ElementsCollection
   */
  public static void waitElementsUntil(
      WebElementCondition selenideCondition, int timeout, ElementsCollection selenideElements) {
    selenideElements.shouldBe(
        conditionToConditionCollection(selenideCondition), Duration.ofMillis(timeout));
  }

  /**
   * Обертка над Selenide waitUntil для работы с колекцией элементов
   *
   * @param selenideCondition Selenide.Condition
   * @param timeout максимальное время ожидания в миллисекундах для перехода элементов в заданное
   *     состояние
   * @param selenideElements коллекция selenide-элементов
   * @see SelenideElement#shouldHave(WebElementCondition, Duration)
   */
  public static void waitElementsUntil(
      WebElementCondition selenideCondition,
      int timeout,
      Collection<SelenideElement> selenideElements) {
    selenideElements.forEach(e -> e.shouldHave(selenideCondition, Duration.ofMillis(timeout)));
  }

  private static WebElementsCondition conditionToConditionCollection(
      WebElementCondition selenideCondition) {
    if (selenideCondition.equals(Condition.visible)) {
      return CollectionCondition.sizeGreaterThan(0);
    }
    return null;
  }
}
