package ru.gazprombank.automation.akitagpb.modules.ui.steps;

import static com.codeborne.selenide.Selenide.switchTo;
import static com.codeborne.selenide.WebDriverRunner.getWebDriver;
import static org.junit.jupiter.api.Assertions.*;

import com.codeborne.selenide.Selenide;
import io.cucumber.java.ru.И;
import io.cucumber.java.ru.Когда;
import java.io.File;
import java.util.List;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import ru.gazprombank.automation.akitagpb.modules.core.cucumber.api.AkitaScenario;
import ru.gazprombank.automation.akitagpb.modules.core.helpers.PropertyLoader;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;

/**
 * Шаги для тестирования взаимодействия с внешним окружением (устройствами, файлами, переменными
 * окружения, property и т.д.)
 */
@Slf4j
public class RoundUpSteps extends UiBaseMethods {

  /**
   * Загружается файл, затем выполняется поиск нужного файла в папке test/resources, проверяется что
   * файл доступен для чтения. Поиск осуществляется по содержанию ожидаемого текста в названии
   * файла. Можно передавать регулярное выражение. После выполнения проверки файл удаляется
   */
  @И(
      "^файл \"(.*)\" загружен в директорию \"(.*)\" и доступен для чтения. Сохранен в переменную \"(.*)\"$")
  public void downloadFile(String fileName, String path, String varName) {
    Pages.getCurrentPage().getElement(fileName).click();
    var downloads = getFileFromSelenoid(fileName, path);
    var directory = new File(path);
    var expectedFiles = directory.listFiles((files, file) -> file.contains(fileName));
    assertNotNull(expectedFiles, "Ошибка поиска файла");
    assertFalse(expectedFiles.length == 0, "Файл не загрузился");
    assertTrue(downloads.canRead(), "Файл не читается");
    assertTrue(
        expectedFiles.length == 1,
        String.format(
            "В папке присутствуют более одного файла с одинаковым названием, содержащим текст [%s]",
            fileName));
    akitaScenario.setVar(varName, downloads);
  }

  /** Эмулирует нажатие клавиш на клавиатуре */
  @И("^выполнено нажатие на клавиатуре \"(.*)\"$")
  public void pushButtonOnKeyboard(String buttonName) {
    Keys key = Keys.valueOf(buttonName.toUpperCase());
    switchTo().activeElement().sendKeys(key);
  }

  /**
   * Эмулирует нажатие сочетания клавиш на клавиатуре. Допустим, чтобы эмулировать нажатие на
   * Ctrl+A, в таблице должны быть следующие значения | CONTROL | | a |
   *
   * @param keyNames название клавиши
   */
  @И("^выполнено нажатие на сочетание клавиш из таблицы$")
  public void pressKeyCombination(List<String> keyNames) {
    Iterable<CharSequence> listKeys =
        keyNames.stream().map(this::getKeyOrCharacter).collect(Collectors.toList());
    String combination = Keys.chord(listKeys);
    switchTo().activeElement().sendKeys(combination);
  }

  private CharSequence getKeyOrCharacter(String key) {
    try {
      return Keys.valueOf(key.toUpperCase());
    } catch (IllegalArgumentException ex) {
      return key;
    }
  }

  /**
   * Выполняется запуск js-скрипта с указанием в js.executeScript его логики Скрипт можно передать
   * как аргумент метода или значение из application.properties
   */
  @Когда("^выполнен js-скрипт \"(.*)\"")
  public void executeJsScript(String scriptName) {
    String content = PropertyLoader.loadValueFromFileOrPropertyOrVariableOrDefault(scriptName);
    Selenide.executeJavaScript(content);
  }

  /** Метод осуществляет снятие скриншота и прикрепление его к cucumber отчету. */
  @И("^снят скриншот текущей страницы$")
  public void takeScreenshot() {
    final byte[] screenshot = ((TakesScreenshot) getWebDriver()).getScreenshotAs(OutputType.BYTES);
    AkitaScenario.getInstance().getScenario().attach(screenshot, "image/png", "Screenshot");
  }
}
