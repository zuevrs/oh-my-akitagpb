package ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps;

import static com.codeborne.selenide.Selenide.$;
import static ru.gazprombank.automation.akitagpb.modules.core.cucumber.ScopedVariables.resolveVars;

import com.codeborne.selenide.ClickOptions;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.io.FilenameUtils;
import org.openqa.selenium.By;
import ru.gazprombank.automation.akitagpb.modules.core.steps.isteps.IBaseMethods;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;
import ru.gazprombank.automation.akitagpb.modules.ui.steps.UiBaseMethods;

/** Шаги для взаимодействия с элементами страницы, доступные по умолчанию в каждом новом проекте */
public interface IElementsInteractionSteps extends IBaseMethods {

  default void clickOnElement(String elementName) {
    Pages.getCurrentPage().getElement(elementName).click();
  }

  default void storeElementValueInVariable(String elementName, String variableName) {
    akitaScenario.setVar(variableName, Pages.getCurrentPage().getAnyElementText(elementName));
    akitaScenario.log(
        "Значение ["
            + Pages.getCurrentPage().getAnyElementText(elementName)
            + "] сохранено в переменную ["
            + variableName
            + "]");
  }

  default void elementHover(String elementName) {
    SelenideElement field = Pages.getCurrentPage().getElement(elementName);
    field.hover();
  }

  default void findElement(String text) {
    $(By.xpath(
            UiBaseMethods.getTranslateNormalizeSpaceText(
                baseMethod.getPropertyOrStringVariableOrValue(text))))
        .click();
  }

  default void clickOnButtonAndUploadFile(String buttonName, String fileOrFileName) {
    File attachmentFile;
    Object value = akitaScenario.tryGetVar(fileOrFileName.replace("${", "").replace("}", ""));
    if (value != null && value.getClass().equals(File.class)) {
      attachmentFile = (File) value;
    } else {
      String filePath = baseMethod.getPropertyOrStringVariableOrValue(resolveVars(fileOrFileName));
      attachmentFile = new File(FilenameUtils.normalize(filePath));
    }
    Pages.getCurrentPage().getElement(buttonName).uploadFile(attachmentFile);
  }

  default void clickOnButtonAndUploadFile(String buttonName, List<String> listFile) {
    List<File> attachmentFiles = new ArrayList<>();
    listFile.forEach(
        file -> {
          Object value = akitaScenario.tryGetVar(file.replace("${", "").replace("}", ""));
          if (value != null && value.getClass().equals(File.class)) {
            attachmentFiles.add((File) value);
          } else {
            String filePath = baseMethod.getPropertyOrStringVariableOrValue(resolveVars(file));
            attachmentFiles.add(new File(FilenameUtils.normalize(filePath)));
          }
        });

    Pages.getCurrentPage().getElement(buttonName).uploadFile(attachmentFiles.toArray(File[]::new));
  }

  default String getCssValue(SelenideElement element, String propertyName) {
    return element.getCssValue(propertyName);
  }

  default String getCssValue(String elementName, String propertyName) {
    return getCssValue(Pages.getCurrentPage().getElement(elementName), propertyName);
  }

  /**
   * Метод для клика вне границ элемента.
   *
   * @param elementName имя элемента
   * @param xAxis смещение по горизонтали относительно края элемента, отрицательное число - от
   *     левого, положительное - от правого
   * @param yAxis смещение по вертикали относительно края элемента, отрицательное число - от
   *     нижнего, положительное - от верхнего
   */
  default void clickOutsideElement(String elementName, int xAxis, int yAxis) {
    SelenideElement element = Pages.getCurrentPage().getElement(elementName);
    var width = element.getSize().getWidth();
    var height = element.getSize().getHeight();

    int offsetX = ((width / 2) + Math.abs(xAxis)) * Integer.signum(xAxis);
    int offsetY = ((height / 2) + Math.abs(yAxis)) * Integer.signum(yAxis);

    element.click(ClickOptions.withOffset(offsetX, offsetY));
  }

  /**
   * Метод для прокрути кастомного скрола внутри элемента
   *
   * @param elementName имя элемента
   */
  default void scrollToBottom(String elementName) {
    SelenideElement element = Pages.getCurrentPage().getElement(elementName);
    int scrollHeight =
        ((Number) Selenide.executeJavaScript("return arguments[0].scrollHeight;", element))
            .intValue();
    Selenide.executeJavaScript(
        "return arguments[0].scrollBy(0,arguments[1]);", element, scrollHeight);
  }
}
