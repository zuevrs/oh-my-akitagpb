package ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps;

import com.codeborne.selenide.SelenideElement;
import java.util.List;
import org.openqa.selenium.support.ui.Select;
import ru.gazprombank.automation.akitagpb.modules.core.steps.isteps.IBaseMethods;
import ru.gazprombank.automation.akitagpb.modules.core.steps.isteps.StepImplementedException;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;

/** Шаги для взаимодействия с выпадающими списками, доступные по умолчанию в каждом новом проекте */
public interface IDropDownListInteractionSteps extends IBaseMethods {

  default void selectElementFromDropDownListWithText(String listName, String expectedText) {
    final String text = baseMethod.getPropertyOrStringVariableOrValue(expectedText);
    SelenideElement list = Pages.getCurrentPage().getElement(listName);
    list.selectOption(text);
  }

  /**
   * Метод для выбора из выпадающего списка
   *
   * @param dropDownElement элемент выпадающего списка
   * @param text текст который выбираем
   */
  default void selectElementWithXpathArgsFromDropDownWithText(
      SelenideElement dropDownElement, String text) {
    dropDownElement.selectOption(text);
  }

  /** Выбор из выпадающего списка со множественным выбором элементов с заданным текстом */
  default void selectElementsFromDropDownListWithText(String listName, List<String> textValues) {
    throw new StepImplementedException(StepImplementedException.ERROR_MESSAGE);
  }

  default void selectElementFromDropDownListWithValue(String listName, String expectedValue) {
    final String value = baseMethod.getPropertyOrStringVariableOrValue(expectedValue);
    SelenideElement list = Pages.getCurrentPage().getElement(listName);
    list.selectOptionByValue(value);
  }

  default void selectElementNumberFromDropDownList(int elementNumber, String listName) {
    Select list = new Select(Pages.getCurrentPage().getElement(listName));
    Integer selectedElementNumber = elementNumber - 1;
    if (selectedElementNumber < 0 || selectedElementNumber >= list.getOptions().size()) {
      throw new IndexOutOfBoundsException(
          String.format(
              "В списке %s нет элемента с номером %s. Количество элементов списка = %s",
              listName, elementNumber, list.getOptions().size()));
    }
    list.selectByIndex(selectedElementNumber);
  }

  default void selectElementFromDropDownListContainingText(String listName, String expectedText) {
    final String text = baseMethod.getPropertyOrStringVariableOrValue(expectedText);
    SelenideElement list = Pages.getCurrentPage().getElement(listName);
    list.selectOptionContainingText(text);
  }

  /** Выбрать случайный элемент из выпадающего списка и получить его текстовое значение */
  default String selectRandomElementFromDropDownListAndGetTextValue(String listName) {
    throw new StepImplementedException(StepImplementedException.ERROR_MESSAGE);
  }

  /** Выбрать n случайных элементов из выпадающего списка со множественным выбором */
  default void selectRandomElementsFromDropDownList(String listName, int elementsNumber) {
    throw new StepImplementedException(StepImplementedException.ERROR_MESSAGE);
  }

  /**
   * Получить список текстовых значений элементов, выбранных в выпадающем списке со множественным
   * выбором
   */
  default List<String> getDropDownListSelectedElementsTextValues(String listName) {
    SelenideElement element = Pages.getCurrentPage().getElement(listName);
    return element.$$x("./preceding-sibling::a").texts();
  }
}
