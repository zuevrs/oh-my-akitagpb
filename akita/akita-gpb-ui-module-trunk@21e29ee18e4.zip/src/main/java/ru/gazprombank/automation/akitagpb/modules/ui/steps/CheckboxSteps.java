package ru.gazprombank.automation.akitagpb.modules.ui.steps;

import io.cucumber.java.ru.И;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;

/** Шаги для взаимодействиями с чекбоксами */
public class CheckboxSteps extends UiBaseMethods {

  @И("^выполнено нажатие на чекбокс \"(.*)\"$")
  public void clickCheckbox(String elementName) {
    Pages.getCurrentPage().clickCheckbox(elementName);
  }

  @И("^чекбокс \"(.*)\" выбран$")
  public void checkCheckboxIsActive(String elementName) {
    Pages.getCurrentPage().checkCheckboxIsActive(elementName);
  }

  @И("^чекбокс \"(.*)\" не выбран$")
  public void checkCheckboxIsNotActive(String elementName) {
    Pages.getCurrentPage().checkCheckboxIsNotActive(elementName);
  }

  /**
   * Шаг переключает Checkbox в определенное состояние (включение|выключение) внезависимости в каком
   * состоянии было первоначально
   */
  @И("^выполнено (включение|выключение) чекбокса \"(.*)\"$")
  public void actionForCheckbox(String action, String elementName) {
    Pages.getCurrentPage().actionForCheckbox(action.equals("включение"), elementName);
  }
}
