package ru.gazprombank.automation.akitagpb.modules.ui.hooks.devtools;

import com.codeborne.selenide.WebDriverRunner;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.devtools.*;
import org.openqa.selenium.devtools.noop.NoOpCdpInfo;
import org.openqa.selenium.devtools.v142.fetch.Fetch;
import org.openqa.selenium.devtools.v142.fetch.model.*;
import org.openqa.selenium.devtools.v142.network.Network;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.http.ClientConfig;
import org.openqa.selenium.remote.http.HttpClient;
import ru.gazprombank.automation.akitagpb.modules.core.steps.BaseMethods;

public class DevToolsManager {
  DevTools devTools;
  private List<RequestNode> requestNodes = new CopyOnWriteArrayList<>();
  private List<MockEntry> mocks = new CopyOnWriteArrayList<>();

  public static DevTools getDevTools() {
    DevTools devTools;
    if (System.getProperty("remoteUrl") == null) {
      devTools = ((HasDevTools) WebDriverRunner.getWebDriver()).getDevTools();
    } else {
      RemoteWebDriver webDriver = ((RemoteWebDriver) WebDriverRunner.getWebDriver());
      Capabilities capabilities = webDriver.getCapabilities();
      CdpInfo cdpInfo =
          new CdpVersionFinder()
              .match(capabilities.getBrowserVersion())
              .orElseGet(NoOpCdpInfo::new);
      HttpClient.Factory factory = HttpClient.Factory.createDefault();
      URI uri;
      try {
        uri = new URI(getSelenoidURL("devtools").replaceAll("https?://", "ws://"));
      } catch (URISyntaxException e) {
        throw new RuntimeException(e);
      }
      Connection connection =
          new Connection(
              factory.createClient(ClientConfig.defaultConfig().baseUri(uri)), uri.toString());
      devTools = new DevTools(cdpInfo::getDomains, connection);
    }
    return devTools;
  }

  private static String getRemote() {
    return BaseMethods.getInstance().getPropertyOrStringVariableOrValue("remoteUrl");
  }

  public static String getSelenoidURL(String suffix) {
    String selenoid = getRemote().replace("wd/hub", "");
    String sessionId = ((RemoteWebDriver) WebDriverRunner.getWebDriver()).getSessionId().toString();
    String urlWithSuffix = selenoid + suffix + "/" + sessionId;
    System.out.println("url for selenoid interaction " + urlWithSuffix);
    return urlWithSuffix;
  }

  public static List<HeaderEntry> getCorsHeaders(RequestPaused request) {
    List<HeaderEntry> corsHeaders = new ArrayList<>();
    String origin =
        Objects.requireNonNull(request.getRequest().getHeaders().get("Origin")).toString();
    corsHeaders.add(new HeaderEntry("Access-Control-Allow-Credentials", "true"));
    corsHeaders.add(new HeaderEntry("Access-Control-Expose-Headers", "end-time"));
    corsHeaders.add(new HeaderEntry("Access-Control-Allow-Origin", origin));
    corsHeaders.add(
        new HeaderEntry("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS"));
    corsHeaders.add(new HeaderEntry("Content-Type", "application/json;charset=utf-8"));
    corsHeaders.add(new HeaderEntry("Connection", "keep-alive"));
    return corsHeaders;
  }

  public static String getRespPhrase(int code) {
    return code == 200
        ? "OK"
        : code == 500 ? "Internal Server Error" : code == 404 ? "Not Found" : "";
  }

  public static String getQueryFromURL(String url) {
    try {
      return new URL(url).getQuery();
    } catch (MalformedURLException e) {
      throw new RuntimeException(e);
    }
  }

  public static String getFrontMockSample(String path) {
    String body;
    try (Stream<String> stream =
        Files.lines(
            Paths.get(System.getProperty("user.dir") + "/src/test/resources/front_mock/" + path),
            StandardCharsets.UTF_8)) {
      body = stream.collect(Collectors.joining());
    } catch (InvalidPathException | IOException e) {
      body = path;
    }
    return body;
  }

  public void registerMock(
      String url,
      String responseBody,
      Function<RequestPaused, Command<Void>> requestCommand,
      Function<RequestPaused, Boolean> requestEntryCondition) {
    mocks.add(new MockEntry(url, responseBody, requestCommand, requestEntryCondition));
  }

  public void removeMock(String url) {
    mocks.removeIf(m -> m.getUrl() != null && m.getUrl().equals(url));
  }

  public void initAndStartListener() {
    devTools = getDevTools();
    devTools.createSessionIfThereIsNotOne();
    devTools.send(
        Network.enable(
            Optional.of(104857600),
            Optional.of(104857600),
            Optional.of(104857600),
            Optional.empty(),
            Optional.empty()));
    devTools.send(
        Fetch.enable(
            Optional.of(
                List.of(
                    new RequestPattern(
                        Optional.empty(), Optional.empty(), Optional.of(RequestStage.RESPONSE)))),
            Optional.empty()));
    devTools.addListener(
        Network.requestWillBeSent(),
        request -> {
          String url = request.getRequest().getUrl();
          String method = request.getRequest().getMethod();
          if (url.matches(".*\\.(js|css|png|jpg|jpeg|gif|svg|ico|woff|woff2|ttf|map|webp).*")
              || url.startsWith("data:")
              || url.contains("mon-test")) {
            return;
          }
          if ("OPTIONS".equals(method)) {
            return;
          }
          RequestNode requestNode = new RequestNode(request.getRequestId().toString());
          requestNode.setUrl(url);
          requestNode.setTime(new Date().getTime());
          requestNode.setMethod(method);
          request.getRequest().getPostData().ifPresent(requestNode::setRequestBody);
          requestNodes.add(requestNode);
        });
    devTools.addListener(
        Fetch.requestPaused(),
        request -> {
          String url = request.getRequest().getUrl();
          String method = request.getRequest().getMethod();
          if (url.matches(".*\\.(js|css|png|jpg|jpeg|gif|svg|ico|woff|woff2|ttf|map|webp).*")
              || url.startsWith("data:")
              || url.contains("mon-test")) {
            devToolsSendContinueRequest(
                devTools,
                request.getRequestId(),
                url,
                method,
                request.getRequest().getPostData(),
                request.getResponseHeaders());
            return;
          }
          Optional<MockEntry> mock =
              mocks.stream().filter(m -> m.getCondition().apply(request)).findFirst();
          //                    System.out.println("mocks total: " + mocks.size() + " | mock found:
          // " + mock.isPresent() + " | url: " + url);
          if (mock.isPresent()) {
            System.out.println(
                "Перехвачен запрос. Paused request: Method=" + method + ", URL=" + url);
            System.out.println("→ Мок применён!");
            devTools.send(mock.get().getCommand().apply(request));
            String networkId =
                request
                    .getNetworkId()
                    .map(Object::toString)
                    .orElse(request.getRequestId().toString());
            requestNodes.stream()
                .filter(
                    n ->
                        n.getRequestId().equals(networkId)
                            || (n.getUrl() != null
                                && n.getUrl().equals(url)
                                && n.getStatusCode() == null))
                .findFirst()
                .ifPresentOrElse(
                    node -> {
                      node.setStatusCode(request.getResponseStatusCode().orElse(null));
                      node.setResponseBody(mock.get().getResponseBody());
                      System.out.println("mock responseBody saved: " + node.getUrl());
                    },
                    () -> System.out.println("node not found for mock: " + networkId));
          } else {
            if (request.getResponseStatusCode().isPresent()) {
              String networkId =
                  request
                      .getNetworkId()
                      .map(Object::toString)
                      .orElse(request.getRequestId().toString());
              requestNodes.stream()
                  .filter(
                      n ->
                          n.getRequestId().equals(networkId)
                              || (n.getUrl() != null
                                  && n.getUrl().equals(url)
                                  && n.getStatusCode() == null))
                  .findFirst()
                  .ifPresent(
                      node -> {
                        node.setStatusCode(request.getResponseStatusCode().orElse(null));
                        try {
                          var responseBody =
                              devTools.send(Fetch.getResponseBody(request.getRequestId()));
                          String body =
                              Boolean.TRUE.equals(responseBody.getBase64Encoded())
                                  ? new String(
                                      Base64.getDecoder().decode(responseBody.getBody()),
                                      StandardCharsets.UTF_8)
                                  : responseBody.getBody();
                          node.setResponseBody(body);
                          System.out.println(
                              "responseBody saved: ["
                                  + node.getStatusCode()
                                  + "] "
                                  + node.getMethod()
                                  + " "
                                  + node.getUrl()
                                  + " → "
                                  + body);
                        } catch (DevToolsException e) {
                          System.out.println(
                              "Fetch responseBody failed: " + url + " → " + e.getMessage());
                        }
                      });
            }
            devToolsSendContinueRequest(
                devTools,
                request.getRequestId(),
                url,
                method,
                request.getRequest().getPostData(),
                request.getResponseHeaders());
          }
        });
  }

  public void devToolsSendContinueRequest(
      DevTools devTools,
      RequestId requestId,
      String url,
      String method,
      Optional<String> postData,
      Optional<List<HeaderEntry>> headers) {
    try {
      devTools.send(
          Fetch.continueRequest(
              requestId,
              Optional.of(url),
              Optional.of(method),
              Optional.empty(),
              Optional.empty(),
              Optional.of(true)));
    } catch (DevToolsException e) {
      if (e.getMessage().contains("Invalid InterceptionId")) {
        System.out.println(e.getMessage());
        return;
      }
    }
  }

  public List<RequestNode> getRequestNodes() {
    return requestNodes;
  }

  public void clearListeners() {
    try {
      devTools.send(Fetch.disable());
    } catch (Exception ignored) {
    }
    devTools.clearListeners();
  }

  public void clearRequestNodes() {
    requestNodes.clear();
  }

  public void clearMocks() {
    mocks.clear();
  }

  public void closeDevTools() {
    try {
      devTools.close();
    } catch (Exception ignored) {
    }
  }

  public boolean isInitialized() {
    return devTools != null;
  }
}
