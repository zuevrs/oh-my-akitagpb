package ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps;

import static com.codeborne.selenide.Selenide.$;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.emptyOrNullString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static ru.gazprombank.automation.akitagpb.modules.core.cucumber.ScopedVariables.resolveVars;
import static ru.gazprombank.automation.akitagpb.modules.core.steps.BaseMethods.DEFAULT_TIMEOUT;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import java.util.List;
import org.assertj.core.api.Assertions;
import org.openqa.selenium.By;
import ru.gazprombank.automation.akitagpb.modules.core.steps.isteps.IBaseMethods;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;
import ru.gazprombank.automation.akitagpb.modules.ui.steps.UiBaseMethods;

/** Шаги, содержащие проверки элементов страницы, доступные по умолчанию в каждом новом проекте */
public interface IElementsVerificationSteps extends IBaseMethods {

  default void compareFieldAndVariable(String elementName, String variableName) {
    String actualValue = Pages.getCurrentPage().getAnyElementText(elementName);
    String expectedValue = akitaScenario.getVar(variableName).toString();

    assertThat(
        String.format(
            "Значение поля [%s] не совпадает со значением из переменной [%s]",
            elementName, variableName),
        actualValue,
        equalTo(expectedValue));
  }

  default void checkElementIsDisplayed(String elementName) {
    Pages.getCurrentPage()
        .waitElementsUntil(
            Condition.appear, DEFAULT_TIMEOUT, Pages.getCurrentPage().getElement(elementName));
  }

  default void checkElementIsDisplayed(SelenideElement element) {
    Pages.getCurrentPage().waitElementsUntil(Condition.appear, DEFAULT_TIMEOUT, element);
  }

  default void checkElementIsNotDisplayed(String elementName) {
    Pages.getCurrentPage()
        .waitElementsUntil(
            Condition.disappear, DEFAULT_TIMEOUT, Pages.getCurrentPage().getElement(elementName));
  }

  default void checkElementIsNotDisplayed(SelenideElement element) {
    Pages.getCurrentPage().waitElementsUntil(Condition.disappear, DEFAULT_TIMEOUT, element);
  }

  default boolean isElementWithTextDisplayed(String text) {
    return $(By.xpath(UiBaseMethods.getTranslateNormalizeSpaceText(text))).isDisplayed();
  }

  default void clickableField(String elementName) {
    SelenideElement element = Pages.getCurrentPage().getElement(elementName);
    assertTrue(element.isEnabled(), String.format("Элемент [%s] не кликабелен", elementName));
  }

  default void testActualValueContainsSubstring(String elementName, String expectedValue) {
    expectedValue = baseMethod.getPropertyOrStringVariableOrValue(resolveVars(expectedValue));
    String actualValue = Pages.getCurrentPage().getAnyElementText(elementName);
    assertThat(
        String.format("Поле [%s] не содержит значение [%s]", elementName, expectedValue),
        actualValue,
        containsString(expectedValue));
  }

  /**
   * Метод для проверки что в поле не содержится указанное значение
   *
   * @param elementName имя элемента в описании страницы
   * @param expectedValue ожидаемое значение
   */
  default void testActualValueNotContainsSubstring(String elementName, String expectedValue) {
    expectedValue = baseMethod.getPropertyOrStringVariableOrValue(resolveVars(expectedValue));
    String actualValue = Pages.getCurrentPage().getAnyElementText(elementName);
    Assertions.assertThat(actualValue)
        .withFailMessage("Поле [%s] содержит значение [%s]", elementName, expectedValue)
        .doesNotContain(expectedValue);
  }

  /**
   * Метод для проверки что в элементе содержится значение
   *
   * @param elementName имя элемента
   * @param expectedValue ожидаемое значение
   * @param args параметры из xpath-локатора
   */
  default void elementWithXpathArgsContainsText(
      String elementName, String expectedValue, List<String> args) {
    expectedValue = baseMethod.getPropertyOrStringVariableOrValue(resolveVars(expectedValue));
    SelenideElement element =
        Pages.getCurrentPage().getElement(elementName, args.toArray(String[]::new));
    String actualValue = Pages.getCurrentPage().getAnyElementText(element);
    assertThat(
        String.format("Поле [%s] не содержит значение [%s]", elementName, expectedValue),
        actualValue,
        containsString(expectedValue));
  }

  default void testFieldContainsInnerText(String fieldName, String expectedText) {
    expectedText = baseMethod.getPropertyOrStringVariableOrValue(resolveVars(expectedText));
    String field = Pages.getCurrentPage().getElement(fieldName).innerText().trim().toLowerCase();
    assertThat(
        String.format("Поле [%s] не содержит текст [%s]", fieldName, expectedText),
        field,
        containsString(expectedText.toLowerCase()));
  }

  /**
   * Метод для проверки что внутренний тескс в поле не содержит значение
   *
   * @param elementName имя элемента в описании страницы
   * @param expectedValue ожидаемое значение
   */
  default void testFieldNotContainsInnerText(String elementName, String expectedValue) {
    expectedValue = baseMethod.getPropertyOrStringVariableOrValue(resolveVars(expectedValue));
    String actualValue =
        Pages.getCurrentPage().getElement(elementName).innerText().trim().toLowerCase();
    Assertions.assertThat(actualValue)
        .withFailMessage("Поле [%s] содержит текст [%s]", elementName, expectedValue)
        .doesNotContain(expectedValue.toLowerCase());
  }

  default void compareValInFieldAndFromStep(String elementName, String expectedValue) {
    expectedValue = baseMethod.getPropertyOrStringVariableOrValue(expectedValue);
    String actualValue = Pages.getCurrentPage().getAnyElementText(elementName);
    assertThat(
        String.format("Значение поля [%s] не равно ожидаемому [%s]", elementName, expectedValue),
        actualValue,
        equalTo(expectedValue));
  }

  default void checkFieldSymbolsCount(String element, int num) {
    int length = Pages.getCurrentPage().getAnyElementText(element).length();
    assertEquals(
        num,
        length,
        String.format(
            "Неверное количество символов. Ожидаемый результат: %s, текущий результат: %s",
            num, length));
  }

  default void fieldInputIsEmpty(String fieldName) {
    assertThat(
        String.format("Поле [%s] не пусто", fieldName),
        Pages.getCurrentPage().getAnyElementText(fieldName),
        is(emptyOrNullString()));
  }

  default void fieldIsDisable(String elementName) {
    SelenideElement element = Pages.getCurrentPage().getElement(elementName);
    assertTrue(element.is(Condition.disabled), String.format("Элемент [%s] доступен", elementName));
  }

  default void fieldIsNotDisable(String elementName) {
    SelenideElement element = Pages.getCurrentPage().getElement(elementName);
    assertTrue(
        element.is(Condition.appear), String.format("Элемент [%s] не доступен", elementName));
  }
}
