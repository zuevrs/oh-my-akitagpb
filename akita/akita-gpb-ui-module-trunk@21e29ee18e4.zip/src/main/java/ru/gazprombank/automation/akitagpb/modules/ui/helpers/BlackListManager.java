package ru.gazprombank.automation.akitagpb.modules.ui.helpers;

import com.browserup.bup.proxy.BlacklistEntry;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class BlackListManager {

  /**
   * Производится парсинг строки из файла blacklist на наличие ссылок типа:
   * .*ru.fp.kaspersky-labs.com.* http://google.com/ 200 При необходимости можно указывать статус
   * код, по умолчанию будет присвоен 404
   *
   * @param blacklistEntries - список ссылок и статус кодов
   */
  private String fileName;

  public BlackListManager(String blacklist) {
    this.fileName = blacklist;
  }

  public void fillBlackList(List<BlacklistEntry> blacklistEntries) {
    String file = getResource();
    Pattern pattern =
        Pattern.compile(
            "((https?:\\/\\/)?([\\da-z\\.\\*-]+)\\.([a-z\\.]{2,6})([\\/\\w\\.\\*-]*)*\\/?)\\s?(\\d{3})*");
    Matcher matcher = pattern.matcher(file);
    while (matcher.find()) {
      if (matcher.group(6) == null) {
        blacklistEntries.add(new BlacklistEntry(matcher.group(1), 404));
      } else {
        blacklistEntries.add(
            new BlacklistEntry(matcher.group(1), Integer.parseInt(matcher.group(6))));
      }
    }
  }

  private String getResource() {
    ClassLoader classLoader = getClass().getClassLoader();
    byte[] file = new byte[0];
    try {
      Path path = Paths.get(classLoader.getResource(fileName).toURI());
      if (Files.exists(path)) {
        return Files.readString(path, StandardCharsets.UTF_8);
      } else {
        log.warn("Файла '" + fileName + "' - не существует\n");
      }
    } catch (NullPointerException | IOException | URISyntaxException ne) {
      log.warn("Файла '" + fileName + "' - не существует\n");
    }
    return new String(file);
  }
}
