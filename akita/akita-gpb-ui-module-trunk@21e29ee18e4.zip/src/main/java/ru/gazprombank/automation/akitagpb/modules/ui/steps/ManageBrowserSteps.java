package ru.gazprombank.automation.akitagpb.modules.ui.steps;

import static com.codeborne.selenide.Selenide.clearBrowserCookies;
import static com.codeborne.selenide.WebDriverRunner.getWebDriver;

import com.codeborne.selenide.Selenide;
import io.cucumber.java.ru.Если;
import io.cucumber.java.ru.И;
import io.cucumber.java.ru.Когда;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.Dimension;
import ru.gazprombank.automation.akitagpb.modules.core.cucumber.ScopedVariables;

/** Шаги для управления браузером и работы с cookies */
@Slf4j
public class ManageBrowserSteps extends UiBaseMethods {

  /** Удаляем все cookies */
  @Когда("^cookies приложения очищены$")
  public void deleteCookies() {
    clearBrowserCookies();
  }

  /** Ищем cookie по имени. Сохраняем cookie в переменную для дальнейшего использования */
  @Когда("^cookie с именем \"(.*)\" сохранена в переменную \"(.*)\"$")
  public void saveCookieToVar(String nameCookie, String cookieVar) {
    String cookieName = ScopedVariables.resolveVars(nameCookie);
    Cookie var = getWebDriver().manage().getCookieNamed(cookieName);
    akitaScenario.setVar(cookieVar, var);
  }

  /** Сохраняем все cookies в переменную для дальнейшего использования */
  @Когда("^cookies сохранены в переменную \"(.*)\"$")
  public void saveAllCookies(String variableName) {
    Set cookies = getWebDriver().manage().getCookies();
    akitaScenario.setVar(variableName, cookies);
  }

  /** Находим cookie по имени и подменяем ее значение. Имя cookie и домен не меняются */
  @Когда("^добавлена cookie с именем \"(.*)\" и значением \"(.*)\"$")
  public void replaceCookie(String cookieName, String cookieValue) {
    String nameCookie = ScopedVariables.resolveVars(cookieName);
    String valueCookie = ScopedVariables.resolveVars(cookieValue);
    getWebDriver().manage().addCookie(new Cookie(nameCookie, valueCookie));
  }

  /** Переключение на следующую вкладку браузера */
  @Когда("выполнено переключение на следующую вкладку")
  public void switchToTheNextTab() {
    String nextWindowHandle = nextWindowHandle();
    getWebDriver().switchTo().window(nextWindowHandle);
    akitaScenario.log("Текущая вкладка " + nextWindowHandle);
  }

  /** Производится закрытие текущей вкладки */
  @И("выполнено закрытие текущей вкладки")
  public void closeCurrentTab() {
    getWebDriver().close();
  }

  /** Устанавливает размеры окна браузера */
  @И("^установлено разрешение экрана (\\d+) х (\\d+)$")
  public void setBrowserWindowSize(int width, int height) {
    getWebDriver().manage().window().setSize(new Dimension(width, height));
    akitaScenario.log("Установлены размеры окна браузера: ширина " + width + " высота" + height);
  }

  /** Разворачивает окно с браузером на весь экран */
  @Если("^окно развернуто на весь экран$")
  public void expandWindowToFullScreen() {
    getWebDriver().manage().window().maximize();
  }

  /**
   * Шаг для сохранения переменной в localStorage
   *
   * @param name имя переменной
   * @param value значение переменной
   */
  @И("^в localStorage добавлена переменная с именем \"(.*)\" и значением \"(.*)\"$")
  public void addPropertyInLocalStorage(String name, String value) {
    name = ScopedVariables.resolveVars(name);
    value = ScopedVariables.resolveVars(value);

    akitaScenario.log(
        String.format(
            "Сохраняем переменную с именем %s и значением %s в localStorage", name, value));
    Selenide.localStorage().setItem(name, value);
  }
}
