package ru.gazprombank.automation.akitagpb.modules.ui.drivers;

import static com.codeborne.selenide.Browsers.*;
import static org.openqa.selenium.remote.CapabilityType.*;

import com.browserup.bup.BrowserUpProxy;
import com.browserup.bup.BrowserUpProxyServer;
import com.browserup.bup.client.ClientUtil;
import com.browserup.bup.proxy.BlacklistEntry;
import com.browserup.bup.proxy.CaptureType;
import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.WebDriverProvider;
import java.net.MalformedURLException;
import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Nonnull;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariOptions;
import ru.gazprombank.automation.akitagpb.modules.core.cucumber.api.AkitaScenario;
import ru.gazprombank.automation.akitagpb.modules.core.helpers.PropertyLoader;
import ru.gazprombank.automation.akitagpb.modules.ui.helpers.BlackList;

/**
 * Провайдер драйверов, который позволяет запускать тесты локально или удаленно, используя Selenoid
 * Параметры запуска можно задавать, как системные переменные.
 *
 * <p>Например, можно указать браузер, версию браузера, remote Url(где будут запущены тесты), ширину
 * и высоту окна браузера, при удаленном запуске имя сессии в Selenoid UI: -Dbrowser=chrome
 * -DbrowserVersion=63.0 -DremoteUrl=http://some/url -Dwidth=1200 -Dheight=800
 * -DselenoidSessionName=MyProjectName -Doptions=--load-extension=my-custom-extension Если параметр
 * remoteUrl не указан - тесты будут запущены локально в заданном браузере последней версии. Все
 * необходимые опции можно прописывать в переменную options, разделяя их пробелом. Если указан
 * параметр remoteUrl и browser, но версия браузера не указана, по умолчанию будет установлена
 * версия latest Если браузер не указан - по умолчанию будет запущен chrome По умолчанию размер окна
 * браузера при remote запуске равен 1920x1080 Предусмотрена возможность запуска в режиме мобильного
 * браузера (-Dbrowser=mobile) Если selenoidSessionName не указан - имя сессии в Selenoid UI
 * отображаться не будет С указанием устройства, на котором будем эмулироваться запуск мобильного
 * chrome браузера (-Ddevice=iPhone 6) Если указан параметр headless, то браузеры firefox и chrome
 * будут запускаться без GUI (-Dheadless=true)
 */
@Slf4j
public class CustomDriverProvider implements WebDriverProvider {

  private static final String SELENOID_SESSION_NAME = "selenoidSessionName";
  public static final String MOBILE_DRIVER = "mobile";
  public static final String BROWSER = "browser";
  public static final String REMOTE_URL = "remoteUrl";
  public static final String HEADLESS = "headless";
  public static final String WINDOW_WIDTH = "width";
  public static final String WINDOW_HEIGHT = "height";
  public static final String VERSION_LATEST = "latest";
  public static final String LOCAL = "local";
  public static final String TRUST_ALL_SERVERS = "trustAllServers";
  public static final String NEW_HAR = "har";
  public static final String SELENOID = "selenoid";
  public static final int DEFAULT_WIDTH = 1920;
  public static final int DEFAULT_HEIGHT = 1080;
  public static final String PROXY_HOST = "proxyHost";
  public static final String PROXY_PORT = "proxyPort";

  private static BrowserUpProxy proxy = new BrowserUpProxyServer();
  private String[] options = PropertyLoader.loadSystemPropertyOrDefault("options", "").split(" ");

  public static BrowserUpProxy getProxy() {
    return proxy;
  }

  /**
   * если установлен -Dproxy=true стартует прокси har для прослушки указывается в
   * application.properties
   *
   * @param capabilities
   */
  private void enableProxy(DesiredCapabilities capabilities) {
    proxy.setTrustAllServers(
        Boolean.parseBoolean(PropertyLoader.loadProperty(TRUST_ALL_SERVERS, "true")));
    proxy.start();

    Proxy seleniumProxy = ClientUtil.createSeleniumProxy(proxy);

    capabilities.setCapability(PROXY, seleniumProxy);
    capabilities.setCapability(
        ACCEPT_INSECURE_CERTS,
        Boolean.valueOf(PropertyLoader.loadProperty(ACCEPT_INSECURE_CERTS, "true")));

    proxy.enableHarCaptureTypes(
        CaptureType.REQUEST_CONTENT,
        CaptureType.REQUEST_HEADERS,
        CaptureType.RESPONSE_CONTENT,
        CaptureType.RESPONSE_HEADERS);
    proxy.newHar(PropertyLoader.loadProperty(NEW_HAR));
  }

  public WebDriver createDriver(DesiredCapabilities capabilities) {
    Configuration.browserSize =
        String.format(
            "%sx%s",
            PropertyLoader.loadSystemPropertyOrDefault(WINDOW_WIDTH, DEFAULT_WIDTH),
            PropertyLoader.loadSystemPropertyOrDefault(WINDOW_HEIGHT, DEFAULT_HEIGHT));
    String expectedBrowser = PropertyLoader.loadSystemPropertyOrDefault(BROWSER, CHROME);
    String remoteUrl = PropertyLoader.loadSystemPropertyOrDefault(REMOTE_URL, LOCAL);
    boolean isProxyMode = PropertyLoader.loadSystemPropertyOrDefault(PROXY, false);
    boolean localEqualsRemoteUrl = LOCAL.equalsIgnoreCase(remoteUrl);
    List<BlacklistEntry> blacklistEntryList = new BlackList().getBlacklistEntries();

    if (isProxyMode) {
      enableProxy(capabilities);
    }

    log.info(
        "remoteUrl="
            + remoteUrl
            + " expectedBrowser= "
            + expectedBrowser
            + " BROWSER_VERSION="
            + System.getProperty(CapabilityType.BROWSER_VERSION));

    switch (expectedBrowser.toLowerCase()) {
      case (FIREFOX):
        return localEqualsRemoteUrl
            ? createFirefoxDriver(capabilities)
            : getRemoteDriver(getFirefoxDriverOptions(capabilities), remoteUrl, blacklistEntryList);
      case (MOBILE_DRIVER):
        return localEqualsRemoteUrl
            ? new ChromeDriver(getMobileChromeOptions(capabilities))
            : getRemoteDriver(getMobileChromeOptions(capabilities), remoteUrl, blacklistEntryList);
      case (SAFARI):
        return localEqualsRemoteUrl
            ? createSafariDriver(capabilities)
            : getRemoteDriver(getSafariDriverOptions(capabilities), remoteUrl, blacklistEntryList);
      case (INTERNET_EXPLORER):
        capabilities.setAcceptInsecureCerts(false);
        return localEqualsRemoteUrl
            ? createIEDriver(capabilities)
            : getRemoteDriver(getIEDriverOptions(capabilities), remoteUrl, blacklistEntryList);
      case (IE):
        capabilities.setCapability(ACCEPT_INSECURE_CERTS, false);
        return localEqualsRemoteUrl
            ? createIEDriver(capabilities)
            : getRemoteDriver(getIEDriverOptions(capabilities), remoteUrl, blacklistEntryList);
      case (EDGE):
        return localEqualsRemoteUrl
            ? createEdgeDriver(capabilities)
            : getRemoteDriver(getEdgeDriverOptions(capabilities), remoteUrl, blacklistEntryList);
      default:
        return localEqualsRemoteUrl
            ? createChromeDriver(capabilities)
            : getRemoteDriver(getChromeDriverOptions(capabilities), remoteUrl, blacklistEntryList);
    }
  }

  /**
   * Задает capabilities для запуска Remote драйвера для Selenoid
   *
   * @param capabilities - capabilities для установленного браузера
   * @param remoteUrl - url для запуска тестов, например http://remoteIP:4444/wd/hub
   * @return WebDriver
   */
  private WebDriver getRemoteDriver(MutableCapabilities capabilities, String remoteUrl) {
    log.info("---------------run Remote Driver---------------------");
    Boolean isSelenoidRun = PropertyLoader.loadSystemPropertyOrDefault(SELENOID, true);

    if (isSelenoidRun) {
      Map<String, Object> capabilitiesMap = new HashMap<>();
      capabilitiesMap.put("enableVNC", true);
      capabilitiesMap.put(
          "screenResolution",
          String.format(
              "%sx%s",
              PropertyLoader.loadSystemPropertyOrDefault(WINDOW_WIDTH, DEFAULT_WIDTH),
              PropertyLoader.loadSystemPropertyOrDefault(WINDOW_HEIGHT, DEFAULT_HEIGHT)));
      String sessionName = PropertyLoader.loadSystemPropertyOrDefault(SELENOID_SESSION_NAME, "");

      if (!sessionName.isEmpty()) {
        capabilitiesMap.put(
            "name",
            String.format(
                "%s %s", sessionName, AkitaScenario.getInstance().getScenario().getName()));
      }
      capabilities.setCapability("selenoid:options", capabilitiesMap);
    }
    try {
      RemoteWebDriver remoteWebDriver =
          new RemoteWebDriver(URI.create(remoteUrl).toURL(), capabilities);
      remoteWebDriver.setFileDetector(new LocalFileDetector());
      return remoteWebDriver;

    } catch (MalformedURLException e) {
      throw new RuntimeException(e);
    }
  }

  /**
   * Задает capabilities для запуска Remote драйвера для Selenoid со списком соответствующих URL,
   * которые добавляются в Blacklist URL для добавления в Blacklist могут быть указаны в формате
   * регулярных выражений
   *
   * @param capabilities
   * @param remoteUrl
   * @param blacklistEntries - список url для добавления в Blacklist
   * @return WebDriver
   */
  private WebDriver getRemoteDriver(
      MutableCapabilities capabilities, String remoteUrl, List<BlacklistEntry> blacklistEntries) {
    proxy.setBlacklist(blacklistEntries);
    return getRemoteDriver(capabilities, remoteUrl);
  }

  /**
   * Устанавливает ChromeOptions для запуска google chrome эмулирующего работу мобильного устройства
   * (по умолчанию nexus 5) Название мобильного устройства (device) может быть задано через
   * системные переменные
   *
   * @return ChromeOptions
   */
  private ChromeOptions getMobileChromeOptions(DesiredCapabilities capabilities) {
    log.info("---------------run CustomMobileDriver---------------------");
    String mobileDeviceName = PropertyLoader.loadSystemPropertyOrDefault("device", "Nexus 5");
    ChromeOptions chromeOptions =
        new ChromeOptions()
            .addArguments(
                "disable-extensions",
                "test-type",
                "no-default-browser-check",
                "ignore-certificate-errors");

    Map<String, String> mobileEmulation = new HashMap<>();
    if (getHeadless()) chromeOptions.addArguments("--headless=new");
    mobileEmulation.put("deviceName", mobileDeviceName);
    chromeOptions.setExperimentalOption("mobileEmulation", mobileEmulation);
    chromeOptions.merge(capabilities);
    return chromeOptions;
  }

  /**
   * Задает options для запуска Chrome драйвера options можно передавать, как системную переменную,
   * например -Doptions=--load-extension=my-custom-extension
   *
   * @return ChromeOptions
   */
  protected ChromeOptions getChromeDriverOptions(DesiredCapabilities capabilities) {
    log.info("---------------Chrome Driver---------------------");
    ChromeOptions chromeOptions =
        !options[0].equals("") ? new ChromeOptions().addArguments(options) : new ChromeOptions();

    chromeOptions.setCapability(
        CapabilityType.BROWSER_VERSION,
        PropertyLoader.loadSystemPropertyOrDefault(CapabilityType.BROWSER_VERSION, VERSION_LATEST));
    if (getHeadless()) chromeOptions.addArguments("--headless=new");
    chromeOptions.merge(capabilities);
    return chromeOptions;
  }

  protected ChromeOptions getChromeDriverOptionsLocal(DesiredCapabilities capabilities) {
    log.info("---------------Chrome Driver---------------------");
    ChromeOptions chromeOptions =
        !options[0].equals("") ? new ChromeOptions().addArguments(options) : new ChromeOptions();

    // Добавляем кастомный путь к Chrome
    String customChromePath =
        PropertyLoader.loadSystemPropertyOrDefault("webdriver.chrome.bin", "");
    if (!customChromePath.isEmpty()) {
      chromeOptions.setBinary(customChromePath);
    }

    chromeOptions.setCapability(
        CapabilityType.BROWSER_VERSION,
        PropertyLoader.loadSystemPropertyOrDefault(CapabilityType.BROWSER_VERSION, VERSION_LATEST));
    if (getHeadless()) chromeOptions.addArguments("--headless=new");
    chromeOptions.merge(capabilities);
    return chromeOptions;
  }

  /**
   * Задает options для запуска Firefox драйвера options можно передавать, как системную переменную,
   * например -Doptions=--load-extension=my-custom-extension
   *
   * @return FirefoxOptions
   */
  private FirefoxOptions getFirefoxDriverOptions(DesiredCapabilities capabilities) {
    log.info("---------------Firefox Driver---------------------");
    FirefoxOptions firefoxOptions =
        !options[0].equals("") ? new FirefoxOptions().addArguments(options) : new FirefoxOptions();
    capabilities.setVersion(
        PropertyLoader.loadSystemPropertyOrDefault(CapabilityType.BROWSER_VERSION, VERSION_LATEST));
    if (getHeadless()) firefoxOptions.addArguments("--headless=new");
    firefoxOptions.merge(capabilities);
    return firefoxOptions;
  }

  /**
   * Задает options для запуска IE драйвера options можно передавать, как системную переменную,
   * например -Doptions=--load-extension=my-custom-extension
   *
   * @return internetExplorerOptions
   */
  private InternetExplorerOptions getIEDriverOptions(DesiredCapabilities capabilities) {
    log.info("---------------IE Driver---------------------");
    InternetExplorerOptions internetExplorerOptions =
        !options[0].equals("")
            ? new InternetExplorerOptions().addCommandSwitches(options)
            : new InternetExplorerOptions();
    internetExplorerOptions.setCapability(
        CapabilityType.BROWSER_VERSION,
        PropertyLoader.loadSystemPropertyOrDefault(CapabilityType.BROWSER_VERSION, VERSION_LATEST));
    internetExplorerOptions.setCapability("ie.usePerProcessProxy", "true");
    internetExplorerOptions.setCapability("requireWindowFocus", "false");
    internetExplorerOptions.setCapability("ie.browserCommandLineSwitches", "-private");
    internetExplorerOptions.setCapability("ie.ensureCleanSession", "true");
    internetExplorerOptions.merge(capabilities);
    return internetExplorerOptions;
  }

  /**
   * Задает options для запуска Edge драйвера options можно передавать, как системную переменную,
   * например -Doptions=--load-extension=my-custom-extension
   *
   * @return edgeOptions
   */
  private EdgeOptions getEdgeDriverOptions(DesiredCapabilities capabilities) {
    log.info("---------------Edge Driver---------------------");
    EdgeOptions edgeOptions = new EdgeOptions();
    edgeOptions.setCapability(
        CapabilityType.BROWSER_VERSION,
        PropertyLoader.loadSystemPropertyOrDefault(CapabilityType.BROWSER_VERSION, VERSION_LATEST));
    edgeOptions.merge(capabilities);
    return edgeOptions;
  }

  /**
   * Задает options для запуска Safari драйвера options можно передавать, как системную переменную,
   * например -Doptions=--load-extension=my-custom-extension
   *
   * @return SafariOptions
   */
  private SafariOptions getSafariDriverOptions(DesiredCapabilities capabilities) {
    log.info("---------------Safari Driver---------------------");
    SafariOptions safariOptions = new SafariOptions();
    safariOptions.setCapability(
        CapabilityType.BROWSER_VERSION,
        PropertyLoader.loadSystemPropertyOrDefault(CapabilityType.BROWSER_VERSION, VERSION_LATEST));
    safariOptions.merge(capabilities);
    return safariOptions;
  }

  /**
   * Создает экземпляр ChromeDriver с переданными capabilities и window dimensions
   *
   * @return WebDriver
   */
  private WebDriver createChromeDriver(DesiredCapabilities capabilities) {
    ChromeDriver chromeDriver = new ChromeDriver(getChromeDriverOptionsLocal(capabilities));
    return chromeDriver;
  }

  /**
   * Создает экземпляр FirefoxDriver с переданными capabilities и window dimensions
   *
   * @return WebDriver
   */
  private WebDriver createFirefoxDriver(DesiredCapabilities capabilities) {
    FirefoxDriver firefoxDriver = new FirefoxDriver(getFirefoxDriverOptions(capabilities));
    return firefoxDriver;
  }

  /**
   * Создает экземпляр InternetExplorerDriver с переданными capabilities и window dimensions
   *
   * @return WebDriver
   */
  private WebDriver createIEDriver(DesiredCapabilities capabilities) {
    InternetExplorerDriver internetExplorerDriver =
        new InternetExplorerDriver(getIEDriverOptions(capabilities));
    return internetExplorerDriver;
  }

  /**
   * Создает экземпляр EdgeDriver с переданными capabilities и window dimensions
   *
   * @return WebDriver
   */
  private WebDriver createEdgeDriver(DesiredCapabilities capabilities) {
    EdgeDriver edgeDriver = new EdgeDriver(getEdgeDriverOptions(capabilities));
    return edgeDriver;
  }

  /**
   * Создает экземпляр SafariDriver с переданными capabilities и window dimensions
   *
   * @return WebDriver
   */
  private WebDriver createSafariDriver(DesiredCapabilities capabilities) {
    SafariDriver safariDriver = new SafariDriver(getSafariDriverOptions(capabilities));
    return safariDriver;
  }

  /**
   * Читает значение параметра headless из application.properties и selenide.headless из системных
   * пропертей
   *
   * @return значение параметра headless или false, если он отсутствует
   */
  private Boolean getHeadless() {
    Boolean isHeadlessApp = PropertyLoader.loadSystemPropertyOrDefault(HEADLESS, false);
    Boolean isHeadlessSys =
        Boolean.parseBoolean(System.getProperty("selenide." + HEADLESS, "false"));
    return isHeadlessApp || isHeadlessSys;
  }

  @Nonnull
  @Override
  public WebDriver createDriver(@Nonnull Capabilities capabilities) {
    return createDriver(new DesiredCapabilities(capabilities));
  }
}
