package ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps;

import static ru.gazprombank.automation.akitagpb.modules.core.cucumber.ScopedVariables.resolveVars;

import com.codeborne.selenide.SelenideElement;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.StringSelection;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.concurrent.ThreadLocalRandom;
import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.Keys;
import ru.gazprombank.automation.akitagpb.modules.core.steps.BaseMethods;
import ru.gazprombank.automation.akitagpb.modules.core.steps.isteps.IBaseMethods;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;
import ru.gazprombank.automation.akitagpb.modules.ui.steps.UiBaseMethods;

/** Шаги для взаимодействия с полями ввода, доступные по умолчанию в каждом новом проекте */
public interface IInputInteractionSteps extends IBaseMethods {

  default void setFieldValue(String elementName, String value) {
    SelenideElement valueInput = Pages.getCurrentPage().getElement(elementName);
    setFieldValue(valueInput, value);
  }

  default void setFieldValue(SelenideElement element, String value) {
    value = BaseMethods.getInstance().getPropertyOrStringVariableOrValue(resolveVars(value));
    UiBaseMethods.cleanField(element);
    element.setValue(value);
  }

  default void cleaningField(String nameOfField) {
    UiBaseMethods.cleanField(nameOfField);
  }

  default void addValue(String elementName, String value) {
    value = BaseMethods.getInstance().getPropertyOrStringVariableOrValue(value);
    SelenideElement field = Pages.getCurrentPage().getElement(elementName);
    String oldValue = field.getValue();
    if (oldValue.isEmpty()) {
      oldValue = field.getText();
    }
    field.setValue("");
    field.setValue(oldValue + value);
  }

  default void currentDate(String fieldName, String dateFormat) {
    long date = System.currentTimeMillis();
    String currentStringDate;
    try {
      currentStringDate = new SimpleDateFormat(dateFormat).format(date);
    } catch (IllegalArgumentException ex) {
      currentStringDate = new SimpleDateFormat("dd.MM.yyyy").format(date);
      //            log.error("Неверный формат даты. Будет использоваться значание по умолчанию в
      // формате dd.MM.yyyy");
    }
    SelenideElement valueInput = Pages.getCurrentPage().getElement(fieldName);
    valueInput.setValue("");
    valueInput.setValue(currentStringDate);
    akitaScenario.log("Текущая дата " + currentStringDate);
  }

  default void pasteValueToTextField(String value, String fieldName) {
    value = BaseMethods.getInstance().getPropertyOrStringVariableOrValue(value);
    ClipboardOwner clipboardOwner = (clipboard, contents) -> {};
    Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
    StringSelection stringSelection = new StringSelection(value);
    clipboard.setContents(stringSelection, clipboardOwner);
    Pages.getCurrentPage().getElement(fieldName).sendKeys(Keys.chord(Keys.SHIFT, Keys.INSERT));
  }

  default void setRandomCharSequence(String elementName, int seqLength, String lang) {
    SelenideElement valueInput = Pages.getCurrentPage().getElement(elementName);
    UiBaseMethods.cleanField(elementName);

    if (lang.equals("кириллице")) {
      lang = "ru";
    } else {
      lang = "en";
    }
    String charSeq = BaseMethods.getInstance().getRandCharSequence(seqLength, lang);
    valueInput.setValue(charSeq);
    akitaScenario.log("Строка случайных символов равна :" + charSeq);
  }

  default void setRandomCharSequenceAndSaveToVar(
      String elementName, int seqLength, String lang, String varName) {
    SelenideElement valueInput = Pages.getCurrentPage().getElement(elementName);
    UiBaseMethods.cleanField(elementName);

    if (lang.equals("кириллице")) {
      lang = "ru";
    } else {
      lang = "en";
    }
    String charSeq = BaseMethods.getInstance().getRandCharSequence(seqLength, lang);
    valueInput.setValue(charSeq);
    akitaScenario.setVar(varName, charSeq);
    akitaScenario.log("Строка случайных символов равна :" + charSeq);
  }

  default void inputRandomNumSequence(String elementName, int seqLength) {
    SelenideElement valueInput = Pages.getCurrentPage().getElement(elementName);
    UiBaseMethods.cleanField(elementName);
    String numSeq = RandomStringUtils.randomNumeric(seqLength);
    valueInput.setValue(numSeq);
    akitaScenario.log(String.format("В поле [%s] введено значение [%s]", elementName, numSeq));
  }

  default void inputAndSetRandomNumSequence(String elementName, int seqLength, String varName) {
    SelenideElement valueInput = Pages.getCurrentPage().getElement(elementName);
    UiBaseMethods.cleanField(elementName);
    String numSeq = RandomStringUtils.randomNumeric(seqLength);
    valueInput.setValue(numSeq);
    akitaScenario.setVar(varName, numSeq);
    akitaScenario.log(
        String.format(
            "В поле [%s] введено значение [%s] и сохранено в переменную [%s]",
            elementName, numSeq, varName));
  }

  default void setRandomNumSequenceWithIntAndFract(
      String fieldName,
      double valueFrom,
      double valueTo,
      String outputFormat,
      String saveToVariableName) {
    outputFormat = outputFormat.replaceAll("#", "0");
    double finalValue = ThreadLocalRandom.current().nextDouble(valueFrom, valueTo);
    setFieldValue(fieldName, new DecimalFormat(outputFormat).format(finalValue));
    akitaScenario.setVar(saveToVariableName, new DecimalFormat(outputFormat).format(finalValue));
    akitaScenario.log(
        String.format(
            "В поле [%s] введено значение [%s] и сохранено в переменную [%s]",
            fieldName, new DecimalFormat(outputFormat).format(finalValue), saveToVariableName));
  }

  default void inputRandomNumSequenceWithIntAndFract(
      String fieldName, double valueFrom, double valueTo, String outputFormat) {
    double finalValue = ThreadLocalRandom.current().nextDouble(valueFrom, valueTo);
    outputFormat = outputFormat.replaceAll("#", "0");
    setFieldValue(fieldName, new DecimalFormat(outputFormat).format(finalValue));
    akitaScenario.log(
        String.format(
            "В поле [%s] введено значение [%s]",
            fieldName, new DecimalFormat(outputFormat).format(finalValue)));
  }
}
