package ru.gazprombank.automation.akitagpb.modules.ui.hooks;

import io.cucumber.java.Before;
import java.net.URL;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import ru.gazprombank.automation.akitagpb.modules.core.helpers.PropertyLoader;

@Slf4j
public class SelenidePropertiesHooks {
  public static final String SETTINGS_FILE = "/selenide.properties";

  @Before(order = 1)
  public void setSystemProperties() {
    URL resource = SelenidePropertiesHooks.class.getResource(SETTINGS_FILE);
    if (resource == null) {
      String message =
          "\n"
              + "Файл настроек не найден по пути:                            \n"
              + "src/main/resources"
              + SETTINGS_FILE
              + "                     \n"
              + "Пожалуйста, создайте файл selenide.properties в директории: \n"
              + "src/main/resources/                                         \n";
      System.err.println(message);
      throw new IllegalStateException(
          "Файл конфигурации Selenide не найден: "
              + ". Создайте файл src/main/resources/selenide.properties");
    }
    Set<String> properties = PropertyLoader.getAllPropertyNameInFile(SETTINGS_FILE);
    for (String propertyName : properties) {
      String value = PropertyLoader.getPropertiesInstance(SETTINGS_FILE).getProperty(propertyName);
      if (value != null && !value.isEmpty()) {
        System.setProperty(propertyName, value);
        System.out.println(
            String.format("Установлено системное свойство: %s = %s", propertyName, value));
      }
    }
    System.out.println(String.format("Selenide properties успешно загружены из %s", SETTINGS_FILE));
  }
}
