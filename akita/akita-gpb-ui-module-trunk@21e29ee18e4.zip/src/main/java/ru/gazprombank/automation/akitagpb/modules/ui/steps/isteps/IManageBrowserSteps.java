package ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps;

import ru.gazprombank.automation.akitagpb.modules.core.steps.isteps.IBaseMethods;

/** Шаги для управления браузером и работы с cookies */
public interface IManageBrowserSteps extends IBaseMethods {}
