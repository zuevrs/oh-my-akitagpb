package ru.gazprombank.automation.akitagpb.modules.ui.steps;

import io.cucumber.java.ru.И;
import io.cucumber.java.ru.Когда;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;

/** Шаги для взаимодействия с элементами страницы, доступные по умолчанию в каждом новом проекте */
@Slf4j
public class ElementsInteractionSteps extends UiBaseMethods {

  /** На странице происходит клик по заданному элементу */
  @И("^выполнено нажатие на (?:кнопку|поле|блок) \"(.*)\"$")
  public void clickOnElement(String elementName) {
    Pages.getCurrentPage().clickOnElement(elementName);
  }

  /** Сохранение значения элемента в переменную */
  @Когда("^значение (?:элемента|поля) \"(.*)\" сохранено в переменную \"(.*)\"$")
  public void storeElementValueInVariable(String elementName, String variableName) {
    akitaScenario.setVar(variableName, Pages.getCurrentPage().getAnyElementText(elementName));
    akitaScenario.log(
        "Значение ["
            + Pages.getCurrentPage().getAnyElementText(elementName)
            + "] сохранено в переменную ["
            + variableName
            + "]");
  }

  /** Выполняется наведение курсора на элемент */
  @Когда("^выполнен ховер на (?:поле|элемент) \"(.*)\"$")
  public void elementHover(String elementName) {
    Pages.getCurrentPage().getElement(elementName).hover();
  }

  /**
   * Нажатие на элемент по его тексту (в приоритете: из property, из переменной сценария, значение
   * аргумента)
   */
  @И("^выполнено нажатие на элемент с текстом \"(.*)\"$")
  public void findElement(String text) {
    Pages.getCurrentPage().findElement(text);
  }

  /**
   * Выполняется нажатие на кнопку и подгружается указанный файл Селектор кнопки должны быть строго
   * на input элемента Можно указать путь до файла (например, src/test/resources/example.pdf) или
   * переменную, в которой сохранён сам файл.
   */
  @Когда("^выполнить нажатие на кнопку \"(.*)\" и загрузить файл \"(.*)\"$")
  public void clickOnButtonAndUploadFile(String buttonName, String fileOrFileName) {
    Pages.getCurrentPage().clickOnButtonAndUploadFile(buttonName, fileOrFileName);
  }

  /** Выполняется нажатие на кнопку и подгружается указанные файлы */
  @Когда("^выполнить нажатие на кнопку \"(.*)\" и загрузить файлы$")
  public void clickOnButtonAndUploadFile(String buttonName, List<String> listFile) {
    Pages.getCurrentPage().clickOnButtonAndUploadFile(buttonName, listFile);
  }

  /**
   * На странице происходит клик по заданному элементу. При этом первоначальный xpath-локатор,
   * заданный в аннотации @FindBy элемента, имеет параметры вида "%s", которые заменяются в шаге с
   * помощью String.format.
   *
   * <p>Пример: на странице есть элемент @Optional @Name("Карта") @FindBy(xpath =
   * "//div[contains(text(), '%s')]/ancestor::div[contains(@class, 'card')]//*[contains(text(),
   * '%s')]") public SelenideElement card;
   *
   * <p>Данный шаг заменит параметры в строке xpath на переданные аргументы и кликнет по найденному
   * элементу
   *
   * @param elementName имя элемента страницы (из аннотации @Name)
   * @param args аргументы для заменты параметров %s через String.format
   */
  @И(
      "^выполнено нажатие на (?:элемент|кнопку|поле|блок) \"(.*)\" с параметрами xpath-(?:локатора|селектора):?$")
  public void clickOnElement(String elementName, List<String> args) {
    Pages.getCurrentPage().getElement(elementName, args.toArray(String[]::new)).click();
  }

  /**
   * Шаг для клика вне границ элемента.
   *
   * @param elementName имя элемента в описании страницы
   * @param xAxis смещение по горизонтали относительно края элемента, отрицательное число - от
   *     левого, положительное - от правого
   * @param yAxis смещение по вертикали относительно края элемента, отрицательное число - от
   *     нижнего, положительное - от верхнего
   */
  @И("^выполнено нажатие вне границ элемента \"(.*)\" с отступом в (-?\\d+) и (-?\\d+) пикселей$")
  public void clickOutsideElement(String elementName, int xAxis, int yAxis) {
    Pages.getCurrentPage().clickOutsideElement(elementName, xAxis, yAxis);
  }

  /**
   * Шаг для прокрути кастомного скрола внутри элемента
   *
   * @param elementName имя элемента
   */
  @И("^выполнен скролл внутри элемента \"(.*)\" до конца")
  public void scrollToBottom(String elementName) {
    Pages.getCurrentPage().scrollToBottom(elementName);
  }
}
