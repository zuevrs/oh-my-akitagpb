package ru.gazprombank.automation.akitagpb.modules.ui.helpers;

import com.browserup.bup.proxy.BlacklistEntry;
import java.util.ArrayList;
import java.util.List;

public class BlackList {

  private List<BlacklistEntry> blacklistEntries = new ArrayList<>();

  private BlackListManager blackListManager = new BlackListManager("blacklist");

  public BlackList() {
    setDefaultBlacklistEntries();
  }

  public BlackList(List<BlacklistEntry> newEntries) {
    setNewBlacklistEntries(newEntries);
  }

  /**
   * Список регулярных выражений соответствующих URL, которые добавляются в Blacklist по умолчанию
   */
  private void setDefaultBlacklistEntries() {
    blackListManager.fillBlackList(blacklistEntries);
  }

  /**
   * очищает дефолтный сисок URL из Blacklist и задает новый Blacklist
   *
   * @param newEntries - новый список URL для доавления в Blacklist
   */
  private void setNewBlacklistEntries(List<BlacklistEntry> newEntries) {
    blacklistEntries.clear();
    blacklistEntries.addAll(newEntries);
  }

  /**
   * @return - спискок URL, которые находятся в Blacklist
   */
  public List<BlacklistEntry> getBlacklistEntries() {
    return blacklistEntries;
  }

  /**
   * добавляет новые URL к дефолтному Blacklist
   *
   * @param newEntries - новые URL, которые будут добавлены в Blacklist
   */
  public void addToDefaultBlacklistEntries(List<BlacklistEntry> newEntries) {
    blacklistEntries.addAll(newEntries);
  }
}
