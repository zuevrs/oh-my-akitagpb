package ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps;

import ru.gazprombank.automation.akitagpb.modules.core.steps.isteps.IBaseMethods;

/**
 * Шаги для тестирования взаимодействия с внешним окружением (устройствами, файлами, переменными
 * окружения, property и т.д.)
 */
public interface IRoundUpSteps extends IBaseMethods {}
