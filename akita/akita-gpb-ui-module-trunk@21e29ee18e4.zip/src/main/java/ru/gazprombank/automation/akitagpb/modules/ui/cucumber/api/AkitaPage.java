package ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api;

import static com.codeborne.selenide.Selenide.$$;
import static com.codeborne.selenide.Selenide.$$x;
import static com.codeborne.selenide.Selenide.$x;
import static java.lang.String.format;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.Container;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.WebElementCondition;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.support.FindBy;
import ru.gazprombank.automation.akitagpb.modules.core.cucumber.ScopedVariables;
import ru.gazprombank.automation.akitagpb.modules.core.cucumber.utils.Reflection;
import ru.gazprombank.automation.akitagpb.modules.core.helpers.PropertyLoader;
import ru.gazprombank.automation.akitagpb.modules.core.steps.isteps.IBaseMethods;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.annotations.Hidden;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.annotations.Name;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.annotations.PageUrl;
import ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps.ICheckboxSteps;
import ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps.IDropDownListInteractionSteps;
import ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps.IDropDownVerificationSteps;
import ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps.IElementsInteractionSteps;
import ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps.IElementsVerificationSteps;
import ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps.IInputInteractionSteps;
import ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps.ILayoutSteps;
import ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps.IListInteractionSteps;
import ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps.IListVerificationSteps;
import ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps.IManageBrowserSteps;
import ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps.IRadiobuttonSteps;
import ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps.IRoundUpSteps;
import ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps.ISwitchToFrameSteps;
import ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps.IWebPageInteractionSteps;
import ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps.IWebPageVerificationSteps;

/** Класс для реализации паттерна PageObject */
@Slf4j
public class AkitaPage
    implements Container,
        IBaseMethods,
        IDropDownListInteractionSteps,
        IDropDownVerificationSteps,
        IElementsInteractionSteps,
        IElementsVerificationSteps,
        IInputInteractionSteps,
        ILayoutSteps,
        IListInteractionSteps,
        IListVerificationSteps,
        IManageBrowserSteps,
        IRoundUpSteps,
        ISwitchToFrameSteps,
        IWebPageInteractionSteps,
        IWebPageVerificationSteps,
        IRadiobuttonSteps,
        ICheckboxSteps {

  /** "Правильная" альтернатива для "//" при составлении локаторов */
  public static final String DESCENDANT = "/descendant::";

  /** Стандартный таймаут ожидания элементов в миллисекундах */
  private static final String WAITING_APPEAR_TIMEOUT_IN_MILLISECONDS = "10000";

  /** Список всех элементов страницы */
  private Map<String, Object> namedElements;

  /** Список элементов страницы, не помеченных аннотацией "Optional" или "Hidden" */
  private List<SelenideElement> primaryElements;

  /** Список элементов страницы, помеченных аннотацией "Hidden" */
  private List<SelenideElement> hiddenElements;

  public AkitaPage() {
    super();
  }

  /** Поиск элемента по имени внутри списка элементов */
  public static SelenideElement getButtonFromListByName(
      List<SelenideElement> listButtons, String nameOfButton) {
    List<String> names = new ArrayList<>();
    for (SelenideElement button : listButtons) {
      names.add(button.getText());
    }
    return listButtons.get(names.indexOf(nameOfButton));
  }

  /** Приведение объекта к типу SelenideElement */
  private static SelenideElement castToSelenideElement(Object object) {
    if (object instanceof SelenideElement) {
      return (SelenideElement) object;
    }
    return null;
  }

  private static AkitaPage castToAkitaPage(Object object) {
    if (object instanceof AkitaPage) {
      return (AkitaPage) object;
    }
    return null;
  }

  public String getUrl() {
    PageUrl url = getClass().getAnnotation(PageUrl.class);

    if (url != null) {
      return url.value();
    }
    return null;
  }

  /** Получение блока со страницы по имени (аннотированного "Name") */
  public AkitaPage getBlock(String blockName) {
    return (AkitaPage)
        java.util.Optional.ofNullable(namedElements.get(blockName))
            .orElseThrow(
                () ->
                    new IllegalArgumentException(
                        "Блок "
                            + blockName
                            + " не описан на странице "
                            + this.getClass().getName()));
  }

  /** Получение списка блоков со страницы по имени (аннотированного "Name") */
  public List<AkitaPage> getBlocksList(String listName) {
    Object value = namedElements.get(listName);
    if (!(value instanceof List)) {
      throw new IllegalArgumentException(
          "Список " + listName + " не описан на странице " + this.getClass().getName());
    }
    Stream<Object> s = ((List) value).stream();
    return s.map(AkitaPage::castToAkitaPage).collect(toList());
  }

  /** Получение списка из элементов блока со страницы по имени (аннотированного "Name") */
  public List<SelenideElement> getBlockElements(String blockName) {
    return getBlock(blockName).namedElements.entrySet().stream()
        .map(x -> ((SelenideElement) x.getValue()))
        .collect(toList());
  }

  /** Получение элемента блока со страницы по имени (аннотированного "Name") */
  public SelenideElement getBlockElement(String blockName, String elementName) {
    return ((SelenideElement) getBlock(blockName).namedElements.get(elementName));
  }

  /**
   * Получение элемента со страницы по имени (аннотированного "Name") или из сохранённых переменных
   * сценария
   */
  public SelenideElement getElement(String elementNameOrElementVar) {
    var element =
        akitaScenario.tryGetVar(elementNameOrElementVar.replace("${", "").replace("}", ""));
    return element instanceof SelenideElement
        ? (SelenideElement) element
        : (SelenideElement)
            java.util.Optional.ofNullable(namedElements.get(elementNameOrElementVar))
                .orElseThrow(
                    () ->
                        new IllegalArgumentException(
                            "Элемент "
                                + elementNameOrElementVar
                                + " не описан на странице "
                                + this.getClass().getName()));
  }

  /**
   * Получение элемента со страницы по имени (аннотированного "Name") и параметрам xpath-селектора.
   * Пример: на странице есть элемент @Optional @Name("Карта") @FindBy(xpath =
   * "//div[contains(text(), '%s')]/ancestor::div[contains(@class, 'card')]//*[contains(text(),
   * '%s')]") public SelenideElement card;
   *
   * <p>Данный метод заменит параметры в строке xpath на переданные аргументы и вернёт найденный
   * элемент
   *
   * @param elementName имя элемента страницы (из аннотации @Name)
   * @param args аргументы для заменты параметров %s через String.format return найденный элемент
   */
  public SelenideElement getElement(String elementName, String... args) {
    String xpath = getClassFieldByElementName(elementName).getAnnotation(FindBy.class).xpath();
    Object[] xpathArgs = Arrays.stream(args).map(ScopedVariables::resolveVars).toArray();
    return $x(String.format(xpath, xpathArgs));
  }

  /** Получение поля Field, помеченного аннотацией @Name, по значению этой аннотации */
  public Field getClassFieldByElementName(String elementName) {
    return Stream.concat(
            Arrays.stream(getClass().getDeclaredFields()), Arrays.stream(getClass().getFields()))
        .distinct()
        .filter(
            f ->
                f.getDeclaredAnnotation(Name.class) != null
                    && f.getDeclaredAnnotation(Name.class).value().equals(elementName))
        .findFirst()
        .orElseThrow(
            () ->
                new IllegalArgumentException(
                    String.format(
                        "Элемент %s не описан на странице %s", elementName, getClass().getName())));
  }

  /** Получение элемента-списка со страницы по имени */
  public ElementsCollection getElementsList(String listName) {
    Object value = namedElements.get(listName);
    if (!(value instanceof List || value instanceof ElementsCollection)) {
      throw new IllegalArgumentException(
          "Список " + listName + " не описан на странице " + this.getClass().getName());
    }
    FindBy listSelector =
        Stream.concat(
                Arrays.stream(this.getClass().getDeclaredFields()),
                Arrays.stream(this.getClass().getFields()))
            .distinct()
            .filter(
                f ->
                    f.getDeclaredAnnotation(Name.class) != null
                        && f.getDeclaredAnnotation(Name.class).value().equals(listName))
            .map(f -> f.getDeclaredAnnotation(FindBy.class))
            .findFirst()
            .get();
    FindBy.FindByBuilder findByBuilder = new FindBy.FindByBuilder();
    return $$(findByBuilder.buildIt(listSelector, null));
  }

  /**
   * Получение элемента-списка со страницы по имени (аннотированного "Name") и параметрам
   * xpath-селектора. Пример: на странице есть элемент @Optional @Name("Карты") @FindBy(xpath =
   * "//div[contains(text(), '%s')]/ancestor::div[contains(@class, 'card')]//*[contains(text(),
   * '%s')]") public List<SelenideElement> cards;
   *
   * <p>Данный метод заменит параметры в строке xpath на переданные аргументы и вернёт найденный
   * список элементов
   *
   * @param listName имя элемента-списка страницы (из аннотации @Name)
   * @param args аргументы для заменты параметров %s через String.format return найденный список
   *     элементов
   */
  public ElementsCollection getElementsList(String listName, String... args) {
    Field field = getClassFieldByElementName(listName);
    if (!field.getType().equals(ElementsCollection.class)) {
      throw new IllegalArgumentException(
          "Список " + listName + " не описан на странице " + this.getClass().getName());
    }
    String xpath = field.getAnnotation(FindBy.class).xpath();
    return $$x(String.format(xpath, Arrays.stream(args).toArray()));
  }

  /**
   * Получение текстов всех элементов, содержащихся в элементе-списке, состоящего как из
   * редактируемых полей, так и статичных элементов по имени Используется метод innerText(), который
   * получает как видимый, так и скрытый текст из элемента, обрезая перенос строк и пробелы в конце
   * и начале строчки.
   */
  public List<String> getAnyElementsListInnerTexts(String listName) {
    List<String> result = new ArrayList<>();
    getElementsList(listName)
        .forEach(
            element -> {
              String value =
                  element.getTagName().equals("input") ? element.getValue() : element.innerText();
              result.add(value == null ? null : value.trim());
            });
    return result;
  }

  /** Получение текста элемента, как редактируемого поля, так и статичного элемента по имени */
  public String getAnyElementText(String elementName) {
    return getAnyElementText(getElement(elementName));
  }

  /**
   * Получение текста элемента, как редактируемого поля, так и статичного элемента по значению
   * элемента
   */
  public String getAnyElementText(SelenideElement element) {
    if (element.getTagName().equals("input") || element.getTagName().equals("textarea")) {
      return element.getValue();
    } else {
      return element.getText();
    }
  }

  /**
   * Получение текстов всех элементов, содержащихся в элементе-списке, состоящего как из
   * редактируемых полей, так и статичных элементов по имени
   */
  public List<String> getAnyElementsListTexts(String listName) {
    List<String> result = new ArrayList<>();
    getElementsList(listName)
        .forEach(
            element -> {
              String value =
                  element.getTagName().equals("input") ? element.getValue() : element.getText();
              result.add(value == null ? null : value.trim());
            });
    return result;
  }

  /** Получение всех элементов страницы, не помеченных аннотацией "Optional" или "Hidden" */
  public List<SelenideElement> getPrimaryElements() {
    if (primaryElements == null) {
      primaryElements = readWithWrappedElements();
    }
    return new ArrayList<>(primaryElements);
  }

  /** Получение всех элементов страницы, помеченных аннотацией "Hidden" */
  public List<SelenideElement> getHiddenElements() {
    if (hiddenElements == null) {
      hiddenElements = readWithHiddenElements();
    }
    return new ArrayList<>(hiddenElements);
  }

  /** Обертка над AkitaPage.isAppeared Ex: AkitaPage.appeared().doSomething(); */
  public final AkitaPage appeared() {
    isAppeared();
    return this;
  }

  /** Обертка над AkitaPage.isDisappeared Ex: AkitaPage.disappeared().doSomething(); */
  public final AkitaPage disappeared() {
    isDisappeared();
    return this;
  }

  /**
   * Проверка того, что элементы, не помеченные аннотацией "Optional", отображаются, а элементы,
   * помеченные аннотацией "Hidden", скрыты.
   */
  public void isAppeared() {
    String timeout =
        PropertyLoader.loadProperty("waitingAppearTimeout", WAITING_APPEAR_TIMEOUT_IN_MILLISECONDS);

    getPrimaryElements()
        .forEach(
            elem ->
                elem.shouldHave(Condition.appear, Duration.ofMillis(Integer.parseInt(timeout))));
    getHiddenElements()
        .forEach(
            elem ->
                elem.shouldHave(Condition.hidden, Duration.ofMillis(Integer.parseInt(timeout))));

    eachForm(AkitaPage::isAppeared);
  }

  private void eachForm(Consumer<AkitaPage> func) {
    Arrays.stream(getClass().getDeclaredFields())
        .filter(
            f ->
                f.getDeclaredAnnotation(
                            ru.gazprombank.automation.akitagpb.modules.ui.cucumber.annotations
                                .Optional.class)
                        == null
                    && f.getDeclaredAnnotation(Hidden.class) == null)
        .forEach(
            f -> {
              if (AkitaPage.class.isAssignableFrom(f.getType())) {
                AkitaPage akitaPage =
                    Pages.getPage((Class<? extends AkitaPage>) f.getType()).initialize();
                func.accept(akitaPage);
              }
            });
  }

  /**
   * Проверка, что все элементы страницы, не помеченные аннотацией "Optional" или "Hidden", исчезли
   */
  public void isDisappeared() {
    String timeout =
        PropertyLoader.loadProperty("waitingAppearTimeout", WAITING_APPEAR_TIMEOUT_IN_MILLISECONDS);
    getPrimaryElements()
        .forEach(
            elem ->
                elem.shouldNotHave(Condition.exist, Duration.ofMillis(Integer.parseInt(timeout))));
  }

  /**
   * Обертка над AkitaPage.isAppearedInIe Ex: AkitaPage.ieAppeared().doSomething(); Используется при
   * работе с IE
   */
  public final AkitaPage ieAppeared() {
    isAppearedInIe();
    return this;
  }

  /**
   * Обертка над AkitaPage.isDisappearedInIe Ex: AkitaPage.ieDisappeared().doSomething();
   * Используется при работе с IE
   */
  public final AkitaPage ieDisappeared() {
    isDisappearedInIe();
    return this;
  }

  /**
   * Проверка того, что элементы, не помеченные аннотацией "Optional", отображаются, а элементы,
   * помеченные аннотацией "Hidden", скрыты. Вместо parallelStream используется stream из-за
   * медленной работы IE
   */
  protected void isAppearedInIe() {
    String timeout =
        PropertyLoader.loadProperty("waitingAppearTimeout", WAITING_APPEAR_TIMEOUT_IN_MILLISECONDS);

    getPrimaryElements().stream()
        .forEach(
            elem ->
                elem.shouldHave(Condition.appear, Duration.ofMillis(Integer.parseInt(timeout))));
    getHiddenElements().stream()
        .forEach(
            elem ->
                elem.shouldHave(Condition.hidden, Duration.ofMillis(Integer.parseInt(timeout))));

    eachForm(AkitaPage::isAppearedInIe);
  }

  /**
   * Проверка, что все элементы страницы, не помеченные аннотацией "Optional" или "Hidden", исчезли
   * Вместо parallelStream используется stream из-за медленной работы IE
   */
  protected void isDisappearedInIe() {
    String timeout =
        PropertyLoader.loadProperty("waitingAppearTimeout", WAITING_APPEAR_TIMEOUT_IN_MILLISECONDS);
    getPrimaryElements()
        .forEach(
            elem ->
                elem.shouldNotHave(Condition.exist, Duration.ofMillis(Integer.parseInt(timeout))));
  }

  /**
   * Обертка над Selenide.waitUntil для произвольного количества элементов
   *
   * @param condition Selenide.Condition
   * @param timeout максимальное время ожидания для перехода элементов в заданное состояние
   * @param elements произвольное количество selenide-элементов
   */
  public void waitElementsUntil(
      WebElementCondition condition, int timeout, SelenideElement... elements) {
    Spectators.waitElementsUntil(condition, timeout, elements);
  }

  /**
   * Обертка над Selenide.waitUntil для работы со списком элементов
   *
   * @param elements список selenide-элементов
   */
  public void waitElementsUntil(
      WebElementCondition condition, int timeout, ElementsCollection elements) {
    Spectators.waitElementsUntil(condition, timeout, elements);
  }

  /**
   * Проверка, что все переданные элементы в течении заданного периода времени перешли в состояние
   * Selenide.Condition
   *
   * @param elementNames произвольное количество строковых переменных с именами элементов
   */
  public void waitElementsUntil(
      WebElementCondition condition, int timeout, String... elementNames) {
    List<SelenideElement> elements =
        Arrays.stream(elementNames)
            .map(name -> namedElements.get(name))
            .flatMap(v -> v instanceof List ? ((List<?>) v).stream() : Stream.of(v))
            .map(AkitaPage::castToSelenideElement)
            .filter(Objects::nonNull)
            .collect(toList());
    Spectators.waitElementsUntil(condition, timeout, elements);
  }

  //  @Override
  //  public void setSelf(SelenideElement self) {
  //    super.setSelf(self);
  //    initialize();
  //  }

  public AkitaPage initialize() {
    namedElements = readNamedElements();
    primaryElements = readWithWrappedElements();
    hiddenElements = readWithHiddenElements();
    return this;
  }

  /** Поиск и инициализации элементов страницы */
  private Map<String, Object> readNamedElements() {
    checkNamedAnnotations();
    return Stream.concat(
            Arrays.stream(getClass().getDeclaredFields()), Arrays.stream(getClass().getFields()))
        .distinct()
        .filter(f -> f.getDeclaredAnnotation(Name.class) != null)
        .peek(this::checkFieldType)
        .collect(
            toMap(
                f -> f.getDeclaredAnnotation(Name.class).value(),
                this::extractFieldValueViaReflection));
  }

  private void checkFieldType(Field f) {
    if (!SelenideElement.class.isAssignableFrom(f.getType())
        && !AkitaPage.class.isAssignableFrom(f.getType())) {
      checkCollectionFieldType(f);
    }
  }

  private void checkCollectionFieldType(Field f) {
    if (ElementsCollection.class.isAssignableFrom(f.getType())) {
      return;
    } else if (List.class.isAssignableFrom(f.getType())) {
      ParameterizedType listType = (ParameterizedType) f.getGenericType();
      Class<?> listClass = (Class<?>) listType.getActualTypeArguments()[0];
      if (SelenideElement.class.isAssignableFrom(listClass)
          || AkitaPage.class.isAssignableFrom(listClass)) {
        return;
      }
    }
    throw new IllegalStateException(
        format(
            "Поле с аннотацией @Name должно иметь тип SelenideElement или List<SelenideElement>.\n"
                + "Если поле описывает блок, оно должно принадлежать классу, унаследованному от AkitaPage.\n"
                + "Найдено поле с типом %s",
            f.getType()));
  }

  /** Поиск по аннотации "Name" */
  private void checkNamedAnnotations() {
    List<String> list =
        Stream.concat(
                Arrays.stream(getClass().getDeclaredFields()),
                Arrays.stream(getClass().getFields()))
            .distinct()
            .filter(f -> f.getDeclaredAnnotation(Name.class) != null)
            .map(f -> f.getDeclaredAnnotation(Name.class).value())
            .collect(toList());

    Set<String> duplicateNameInPage =
        list.stream()
            .filter(name -> Collections.frequency(list, name) > 1)
            .collect(Collectors.toSet());
    if (!duplicateNameInPage.isEmpty()) {
      throw new IllegalStateException(
          String.format(
              "Найдено несколько аннотаций @Name с одинаковым значением в классе %s. Дублирующиеся поля: %s",
              this.getClass().getName(), duplicateNameInPage.toString()));
    }
  }

  /** Поиск и инициализация элементов страницы без аннотации Optional или Hidden */
  private List<SelenideElement> readWithWrappedElements() {
    return Stream.concat(
            Arrays.stream(getClass().getDeclaredFields()), Arrays.stream(getClass().getFields()))
        .distinct()
        .filter(
            f ->
                f.getDeclaredAnnotation(
                            ru.gazprombank.automation.akitagpb.modules.ui.cucumber.annotations
                                .Optional.class)
                        == null
                    && f.getDeclaredAnnotation(Hidden.class) == null)
        .map(this::extractFieldValueViaReflection)
        .flatMap(v -> v instanceof List ? ((List<?>) v).stream() : Stream.of(v))
        .map(AkitaPage::castToSelenideElement)
        .filter(Objects::nonNull)
        .collect(toList());
  }

  /** Поиск и инициализация элементов страницы c аннотацией Hidden */
  private List<SelenideElement> readWithHiddenElements() {
    return Stream.concat(
            Arrays.stream(getClass().getDeclaredFields()), Arrays.stream(getClass().getFields()))
        .distinct()
        .filter(f -> f.getDeclaredAnnotation(Hidden.class) != null)
        .map(this::extractFieldValueViaReflection)
        .flatMap(v -> v instanceof List ? ((List<?>) v).stream() : Stream.of(v))
        .map(AkitaPage::castToSelenideElement)
        .filter(Objects::nonNull)
        .collect(toList());
  }

  private Object extractFieldValueViaReflection(Field field) {
    return Reflection.extractFieldValue(field, this);
  }
}
