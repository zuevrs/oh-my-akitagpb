package ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps;

import static org.assertj.core.api.Assertions.assertThat;

import com.codeborne.selenide.SelenideElement;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;

public interface ICheckboxSteps {

  /** Выполняется нажатие на чекбокс */
  default void clickCheckbox(String elementName) {
    Pages.getCurrentPage().getElement(elementName).click();
  }

  default void clickCheckbox(SelenideElement element) {
    element.click();
  }

  /**
   * Выполняется проверка, что чекбокс активен. Селектор чекбокса должны быть строго на input
   * элемента
   */
  default void checkCheckboxIsActive(String elementName) {
    var element = Pages.getCurrentPage().getElement(elementName);
    assertThat(element.isSelected()).withFailMessage("Чекбокс не активен").isTrue();
  }

  /**
   * Выполняется проверка, что чекбокс не активен. Селектор чекбокса должны быть строго на input
   * элемента
   */
  default void checkCheckboxIsNotActive(String elementName) {
    var element = Pages.getCurrentPage().getElement(elementName);
    assertThat(element.isSelected()).withFailMessage("Чекбокс активен").isFalse();
  }

  /**
   * Выполняется нажатие на Checkbox в определенное состояние (true|false) внезависимости в каком
   * состоянии было первоначально
   */
  default void actionForCheckbox(boolean action, String elementName) {
    actionForCheckbox(action, Pages.getCurrentPage().getElement(elementName));
  }

  default void actionForCheckbox(boolean action, SelenideElement element) {

    boolean selectedRadiobutton = element.isSelected();

    if (action && !selectedRadiobutton) {
      clickCheckbox(element);
    }
    if (!action && selectedRadiobutton) {
      clickCheckbox(element);
    }
  }
}
