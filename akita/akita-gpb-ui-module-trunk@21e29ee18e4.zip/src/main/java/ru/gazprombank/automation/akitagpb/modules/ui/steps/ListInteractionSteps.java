package ru.gazprombank.automation.akitagpb.modules.ui.steps;

import io.cucumber.java.ru.Когда;
import io.cucumber.java.ru.Тогда;
import lombok.extern.slf4j.Slf4j;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;

/**
 * Шаги для взаимодействия с коллекциями элементов, доступные по умолчанию в каждом новом проекте
 */
@Slf4j
public class ListInteractionSteps extends UiBaseMethods {

  /**
   * Выбор из списка со страницы элемента с заданным значением (в приоритете: из property, из
   * переменной сценария, значение аргумента)
   */
  @Когда("^в списке \"(.*)\" выбран элемент с (?:текстом|значением) \"(.*)\"$")
  public void checkIfSelectedListElementMatchesValue(String listName, String expectedValue) {
    Pages.getCurrentPage().checkIfSelectedListElementMatchesValue(listName, expectedValue);
  }

  /**
   * Выбор из списка со страницы элемента, который содержит заданный текст (в приоритете: из
   * property, из переменной сценария, значение аргумента) Не чувствителен к регистру
   */
  @Когда("^в списке \"(.*)\" выбран элемент содержащий текст \"(.*)\"$")
  public void selectElementInListIfFoundByText(String listName, String expectedValue) {
    Pages.getCurrentPage().selectElementInListIfFoundByText(listName, expectedValue);
  }

  /**
   * Выбор из списка со страницы любого случайного элемента и сохранение его значения в переменную
   */
  @Когда("^выбран любой элемент из списка \"(.*)\" и его значение сохранено в переменную \"(.*)\"$")
  public void selectRandomElementFromListAndSaveVar(String listName, String varName) {
    Pages.getCurrentPage().selectRandomElementFromListAndSaveVar(listName, varName);
  }

  /** Выбор n-го элемента из списка со страницы Нумерация элементов начинается с 1 */
  @Когда("^выбран (\\d+)-й элемент в списке \"([^\\W\"]+)\"$")
  public void selectElementNumberFromList(Integer elementNumber, String listName) {
    Pages.getCurrentPage().selectElementNumberFromList(elementNumber, listName);
  }

  /** Выбор из списка со страницы любого случайного элемента */
  @Когда("^выбран любой элемент в списке \"(.*)\"$")
  public void selectRandomElementFromList(String listName) {
    Pages.getCurrentPage().selectRandomElementFromList(listName);
  }

  /**
   * Выбор n-го элемента из списка со страницы и сохранение его значения в переменную Нумерация
   * элементов начинается с 1
   */
  @Тогда(
      "^выбран (\\d+)-й элемент в списке \"(.*)\" и его значение сохранено в переменную \"(.*)\"$")
  public void selectElementNumberFromListAndSaveToVar(
      Integer elementNumber, String listName, String varName) {
    Pages.getCurrentPage()
        .selectElementNumberFromListAndSaveToVar(elementNumber, listName, varName);
  }

  /**
   * Удаление из списка со страницы элемента, который содержит заданный текст (в приоритете: из
   * property, из переменной сценария, значение аргумента) Не чувствителен к регистру
   */
  @Когда("^в списке \"(.*)\" удалён элемент, содержащий текст \"(.*)\"$")
  public void deleteElementFromListIfFoundByText(String listName, String expectedValue) {
    Pages.getCurrentPage().deleteElementFromListIfFoundByText(listName, expectedValue);
  }

  /** Удаление n-го элемента из списка со страницы Нумерация элементов начинается с 1 */
  @Когда("^удалён (\\d+)-й элемент в списке \"(.*)\"$")
  public void deleteElementNumberFromList(Integer elementNumber, String listName) {
    Pages.getCurrentPage().deleteElementNumberFromList(elementNumber, listName);
  }
}
