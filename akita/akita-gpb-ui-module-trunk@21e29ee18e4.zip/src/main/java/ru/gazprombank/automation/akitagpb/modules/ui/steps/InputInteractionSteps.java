package ru.gazprombank.automation.akitagpb.modules.ui.steps;

import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.ru.Когда;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;

/** Шаги для взаимодействия с полями ввода, доступные по умолчанию в каждом новом проекте */
@Slf4j
public class InputInteractionSteps extends UiBaseMethods {

  /**
   * Устанавливается значение (в приоритете: из property, из переменной сценария, значение
   * аргумента) в заданное поле. Перед использованием поле нужно очистить
   */
  @Когда("^в поле \"(.*)\" введено значение \"(.*)\"$")
  public void setFieldValue(String elementName, String value) {
    Pages.getCurrentPage().setFieldValue(elementName, value);
  }

  /**
   * Устанавливается значение (в приоритете: из property, из переменной сценария, значение
   * аргумента) в поле с параметрами xpath параметрами.
   */
  @Когда(
      "^в (?:поле|элемент) \"(.*)\" с параметрами xpath-(?:локатора|селектора) введено значение \"(.*)\"$")
  public void setFieldValueInElementWithXpathArgs(
      String elementName, String value, List<String> args) {
    SelenideElement element =
        Pages.getCurrentPage().getElement(elementName, args.toArray(String[]::new));
    Pages.getCurrentPage().setFieldValue(element, value);
  }

  @Когда("^в поля введены значения$")
  public void setFields(Map<String, String> map) {
    for (String key : map.keySet()) {
      setFieldValue(key, map.get(key));
    }
  }

  /** Очищается заданное поле */
  @Когда("^очищено поле \"(.*)\"$")
  public void cleaningField(String nameOfField) {
    Pages.getCurrentPage().cleaningField(nameOfField);
  }

  /**
   * Добавление строки (в приоритете: из property, из переменной сценария, значение аргумента) в
   * поле к уже заполненой строке
   */
  @Когда("^в элемент \"(.*)\" дописывается значение \"(.*)\"$")
  public void addValue(String elementName, String value) {
    Pages.getCurrentPage().addValue(elementName, value);
  }

  /** Ввод в поле текущей даты в заданном формате При неверном формате, используется dd.MM.yyyy */
  @Когда("^элемент \"(.*)\" заполняется текущей датой в формате \"(.*)\"$")
  public void currentDate(String fieldName, String dateFormat) {
    Pages.getCurrentPage().currentDate(fieldName, dateFormat);
  }

  /**
   * Ввод в поле указанного текста (в приоритете: из property, из переменной сценария, значение
   * аргумента), используя буфер обмена и клавиши SHIFT + INSERT
   */
  @Когда("^вставлено значение \"(.*)\" в элемент \"(.*)\" с помощью горячих клавиш$")
  public void pasteValueToTextField(String value, String fieldName) {
    Pages.getCurrentPage().pasteValueToTextField(value, fieldName);
  }

  /** Ввод в поле случайной последовательности латинских или кириллических букв задаваемой длины */
  @Когда("^в поле \"(.*)\" введено (\\d+) случайных символов на (кириллице|латинице)$")
  public void setRandomCharSequence(String elementName, int seqLength, String lang) {
    Pages.getCurrentPage().setRandomCharSequence(elementName, seqLength, lang);
  }

  /**
   * Ввод в поле случайной последовательности латинских или кириллических букв задаваемой длины и
   * сохранение этого значения в переменную
   */
  @Когда(
      "^в поле \"(.*)\" введено (\\d+) случайных символов на (кириллице|латинице) и сохранено в переменную \"(.*)\"$")
  public void setRandomCharSequenceAndSaveToVar(
      String elementName, int seqLength, String lang, String varName) {
    Pages.getCurrentPage().setRandomCharSequenceAndSaveToVar(elementName, seqLength, lang, varName);
  }

  /** Ввод в поле случайной последовательности цифр задаваемой длины */
  @Когда("^в поле \"(.*)\" введено случайное число из (\\d+) (?:цифр|цифры)$")
  public void inputRandomNumSequence(String elementName, int seqLength) {
    Pages.getCurrentPage().inputRandomNumSequence(elementName, seqLength);
  }

  /**
   * Ввод в поле случайной последовательности цифр задаваемой длины и сохранение этого значения в
   * переменную
   */
  @Когда(
      "^в поле \"(.*)\" введено случайное число из (\\d+) (?:цифр|цифры) и сохранено в переменную \"(.*)\"$")
  public void inputAndSetRandomNumSequence(String elementName, int seqLength, String varName) {
    Pages.getCurrentPage().inputAndSetRandomNumSequence(elementName, seqLength, varName);
  }

  /**
   * Ввод в поле случайного дробного числа в заданном диапазоне и формате с последующим сохранением
   * этого значения в переменную Пример формата ввода: ###.##
   */
  @Когда(
      "^в поле \"(.*)\" введено случайное дробное число от (\\d+) до (\\d+) в формате \"(.*)\" и сохранено в переменную \"(.*)\"$")
  public void setRandomNumSequenceWithIntAndFract(
      String fieldName,
      double valueFrom,
      double valueTo,
      String outputFormat,
      String saveToVariableName) {
    Pages.getCurrentPage()
        .setRandomNumSequenceWithIntAndFract(
            fieldName, valueFrom, valueTo, outputFormat, saveToVariableName);
  }

  /**
   * Ввод в поле случайного дробного числа в заданном диапазоне и формате Пример формата ввода:
   * ###.##
   */
  @Когда("^в поле \"(.*)\" введено случайное дробное число от (\\d+) до (\\d+) в формате \"(.*)\"$")
  public void inputRandomNumSequenceWithIntAndFract(
      String fieldName, double valueFrom, double valueTo, String outputFormat) {
    Pages.getCurrentPage()
        .inputRandomNumSequenceWithIntAndFract(fieldName, valueFrom, valueTo, outputFormat);
  }
}
