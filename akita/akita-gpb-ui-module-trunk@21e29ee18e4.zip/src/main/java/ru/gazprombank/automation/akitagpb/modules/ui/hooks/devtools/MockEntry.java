package ru.gazprombank.automation.akitagpb.modules.ui.hooks.devtools;

import java.util.function.Function;
import org.openqa.selenium.devtools.Command;
import org.openqa.selenium.devtools.v142.fetch.model.RequestPaused;

public class MockEntry {
  private final String url;
  private final String responseBody;
  private final Function<RequestPaused, Command<Void>> command;
  private final Function<RequestPaused, Boolean> condition;

  public MockEntry(
      String url,
      String responseBody,
      Function<RequestPaused, Command<Void>> command,
      Function<RequestPaused, Boolean> condition) {
    this.url = url;
    this.responseBody = responseBody;
    this.command = command;
    this.condition = condition;
  }

  public String getUrl() {
    return url;
  }

  public String getResponseBody() {
    return responseBody;
  }

  public Function<RequestPaused, Command<Void>> getCommand() {
    return command;
  }

  public Function<RequestPaused, Boolean> getCondition() {
    return condition;
  }
}
