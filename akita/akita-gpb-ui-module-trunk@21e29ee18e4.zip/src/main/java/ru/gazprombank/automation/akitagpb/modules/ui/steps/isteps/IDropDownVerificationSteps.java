package ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps;

import static org.assertj.core.api.Assertions.assertThat;

import com.codeborne.selenide.SelenideElement;
import java.util.List;
import java.util.stream.Collectors;
import org.assertj.core.api.Assertions;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import ru.gazprombank.automation.akitagpb.modules.core.steps.isteps.IBaseMethods;
import ru.gazprombank.automation.akitagpb.modules.core.steps.isteps.StepImplementedException;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;

public interface IDropDownVerificationSteps extends IBaseMethods {
  default void dropDownContainsElements(String selectName, List<String> expectedValues) {
    List<String> actualValues = getDropDownActualValues(selectName);

    assertThat(actualValues.size()).isEqualTo(expectedValues.size());
    assertThat(actualValues)
        .withFailMessage(
            String.format(
                "Значения элементов в списке %s: %s не совпадают с ожидаемыми значениями из таблицы %s",
                selectName, actualValues, expectedValues))
        .containsAll(expectedValues);
  }

  /**
   * Метод проверки что в выпадающем списке выбран нужный текст
   *
   * @param dropDownName имя выпадающего списка
   * @param expectedValue ожидаемое значение
   */
  default void dropDownSelectedText(String dropDownName, String expectedValue) {
    SelenideElement dropDownElement = Pages.getCurrentPage().getElement(dropDownName);
    String actualValue =
        Pages.getCurrentPage().getAnyElementText(dropDownElement.getSelectedOption());
    Assertions.assertThat(actualValue)
        .withFailMessage("Значение поля [%s] не равно ожидаемому [%s]", dropDownName, expectedValue)
        .isEqualTo(expectedValue);
  }

  /**
   * Метод проверки что в выпадающем списке выбран нужный текст
   *
   * @param dropDownElement Элемент выпадающего списка
   * @param expectedValue ожидаемое значение
   */
  default void dropDownSelectedText(SelenideElement dropDownElement, String expectedValue) {
    String actualValue =
        Pages.getCurrentPage().getAnyElementText(dropDownElement.getSelectedOption());
    Assertions.assertThat(actualValue).isEqualTo(expectedValue);
  }

  default List<String> getDropDownActualValues(String selectName) {
    Select list = new Select(Pages.getCurrentPage().getElement(selectName));
    return list.getOptions().stream().map(WebElement::getText).collect(Collectors.toList());
  }

  default void dropDownNotContainsElements(String selectName, List<String> unexpectedValues) {
    List<String> actualValues = getDropDownActualValues(selectName);
    assertThat(actualValues)
        .withFailMessage(
            String.format(
                "В списке %s: %s найдены не ожидаемые значения - %s",
                selectName, actualValues, unexpectedValues))
        .doesNotContainAnyElementsOf(unexpectedValues);
  }

  /**
   * Метод для проверки, что в раскрывающемся списке со множественным выбором выбраны заданные
   * элементы
   *
   * @param selectName имя элемента (из аннотации Name) на page-object'е страницы
   * @param expectedValues список ожидаемых выбранных в списке элементов
   */
  default void dropDownContainsSelectedElements(String selectName, List<String> expectedValues) {
    throw new StepImplementedException(StepImplementedException.ERROR_MESSAGE);
  }
}
