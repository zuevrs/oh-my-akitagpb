package ru.gazprombank.automation.akitagpb.modules.ui.steps;

import static com.codeborne.selenide.Condition.disabled;
import static com.codeborne.selenide.Condition.readonly;
import static com.codeborne.selenide.WebDriverRunner.getWebDriver;
import static com.codeborne.selenide.WebDriverRunner.isIE;
import static org.hamcrest.MatcherAssert.assertThat;

import com.codeborne.selenide.SelenideElement;
import java.io.File;
import java.util.*;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.hamcrest.text.IsEqualIgnoringCase;
import org.openqa.selenium.Keys;
import ru.gazprombank.automation.akitagpb.modules.core.cucumber.api.AkitaScenario;
import ru.gazprombank.automation.akitagpb.modules.core.helpers.ConfigLoader;
import ru.gazprombank.automation.akitagpb.modules.core.steps.BaseMethods;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;

/** Общие методы, используемые в различных шагах */
@Slf4j
public class UiBaseMethods extends BaseMethods {

  private static Integer repeatCounter =
      ConfigLoader.getConfigValueOrDefault("cleanField.repeat.counter", 5);

  /**
   * Возвращает файл загруженный из Selenoid
   *
   * @return
   */
  @SneakyThrows
  public static File getFileFromSelenoid(String fileName, String path) {
    // Ожидаем окончания загрузки файла в хроме в selenoid
    Thread.sleep(7_000);
    byte[] data =
        Objects.requireNonNull(
            SelenoidRemoteSteps.downloadFileFromSelenoidContainer(fileName).asByteArray());
    writeFileToDirectory(data, path + fileName);
    // deleteDownloadFileFromSelenoidContainer(fileName);
    return new File(path + fileName);
  }

  public String nextWindowHandle() {
    String currentWindowHandle = getWebDriver().getWindowHandle();
    Set<String> windowHandles = getWebDriver().getWindowHandles();
    windowHandles.remove(currentWindowHandle);
    return windowHandles.iterator().next();
  }

  //    @SneakyThrows
  //    /**
  //     * Проверяет соответствие текущей страницы ее описанию в .spec файле.
  //     * Скриншоты с расходениями в дизайне сохраняются в /build/results-img/ и прикрепояются к
  // cucumber отчету
  //     * Путь /build/results-img/ можно переопределить, задав системную переменную imgDiff
  //     */
  //    public void checkLayoutAccordingToSpec(String spec, List<String> tags) {
  //        LayoutReport report = Galen.checkLayout(getWebDriver(), SPECS_DIR_PATH + spec, tags);
  //        report.getFileStorage().copyAllFilesTo(new File(IMG_DIFF_PATH));
  //        if (report.errors() > 0) {
  //            embedScreenshotAndFail(report);
  //        }
  //    }

  //    private void embedScreenshotAndFail(LayoutReport report) {
  //        Map<String, File> screenshots = report.getFileStorage().getFiles();
  //        screenshots.forEach((key, value) -> {
  //            if (key.contains("map") || key.contains("expected") || key.contains("actual")) {
  //                akitaScenario.log(key);
  //                embedFileToReport(value, "image/png");
  //            }
  //        });
  //        fail(report.getValidationErrorResults().toString());
  //    }

  /** Возвращает локатор для поиска по нормализованному(без учета регистра) тексту */
  public static String getTranslateNormalizeSpaceText(String expectedText) {
    StringBuilder text = new StringBuilder();
    text.append("//*[contains(translate(normalize-space(text()), ");
    text.append("'ABCDEFGHIJKLMNOPQRSTUVWXYZАБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ', ");
    text.append("'abcdefghijklmnopqrstuvwxyzабвгдеёжзийклмнопрстуфхцчшщъыьэюя'), '");
    text.append(expectedText.toLowerCase());
    text.append("')]");
    return text.toString();
  }

  public static void loadPage(String nameOfPage) {
    Pages.setCurrentPage(Pages.getPage(nameOfPage));
    if (isIE()) {
      Pages.getCurrentPage().ieAppeared();
    } else {
      Pages.getCurrentPage().appeared();
    }
  }

  public static void cleanField(String nameOfField) {
    SelenideElement valueInput = Pages.getCurrentPage().getElement(nameOfField);
    cleanField(valueInput);
  }

  public static void cleanField(SelenideElement element) {
    Keys removeKey = isIE() ? Keys.BACK_SPACE : Keys.DELETE;
    for (int i = 0; i < repeatCounter; i++) {
      element.shouldNotBe(readonly, disabled).doubleClick().sendKeys(removeKey);
      if (element.getValue() == null || element.getValue().isBlank()) return;
    }
    if (element.getValue() != null && !element.getValue().isBlank()) {
      AkitaScenario.getInstance()
          .log(
              String.format(
                  "За %s повторений не удалось очистить поле. Его значение: %s",
                  repeatCounter, element.getValue()));
    }
  }

  public void checkPageTitle(String pageTitleName) {
    pageTitleName = getPropertyOrStringVariableOrValue(pageTitleName);
    String currentTitle = getWebDriver().getTitle().trim();
    assertThat(
        String.format(
            "Заголовок страницы не совпадает с ожидаемым значением. Ожидаемый результат: %s, текущий результат: %s",
            pageTitleName, currentTitle),
        pageTitleName,
        IsEqualIgnoringCase.equalToIgnoringCase(currentTitle));
  }
}
