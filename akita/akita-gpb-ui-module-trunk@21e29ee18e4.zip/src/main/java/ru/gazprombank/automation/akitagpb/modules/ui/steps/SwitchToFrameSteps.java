package ru.gazprombank.automation.akitagpb.modules.ui.steps;

import io.cucumber.java.ru.И;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;

/** Шаги для перехода по фреймам */
public class SwitchToFrameSteps extends UiBaseMethods {

  @И("^совершен переход на фрейм \"(.*)\"$")
  public void switchToFrame(String frameName) {
    Pages.getCurrentPage().switchToFrame(frameName);
  }

  @И("^совершен переход на внутренний фрейм")
  public void switchToFrame() {
    Pages.getCurrentPage().switchToFrame();
  }

  @И("^совершен переход на дефолтный фрейм")
  public void switchToDefaultContent() {
    Pages.getCurrentPage().switchToDefaultContent();
  }
}
