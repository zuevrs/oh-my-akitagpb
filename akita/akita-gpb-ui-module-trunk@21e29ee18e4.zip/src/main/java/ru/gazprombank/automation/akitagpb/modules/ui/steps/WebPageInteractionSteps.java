package ru.gazprombank.automation.akitagpb.modules.ui.steps;

import static com.codeborne.selenide.Selenide.open;
import static com.codeborne.selenide.Selenide.refresh;
import static com.codeborne.selenide.Selenide.switchTo;
import static com.codeborne.selenide.WebDriverRunner.getWebDriver;

import io.cucumber.java.ru.И;
import io.cucumber.java.ru.Когда;
import io.cucumber.java.ru.Пусть;
import lombok.extern.slf4j.Slf4j;
import ru.gazprombank.automation.akitagpb.modules.core.cucumber.ScopedVariables;
import ru.gazprombank.automation.akitagpb.modules.core.hooks.statistics.StatisticsHooks;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;

/** Шаги для взаимодействия с вэб-страницей, доступные по умолчанию в каждом новом проекте */
@Slf4j
public class WebPageInteractionSteps extends UiBaseMethods {

  /** Выполняется обновление страницы */
  @И("^выполнено обновление текущей страницы$")
  public void refreshPage() {
    refresh();
  }

  /**
   * Выполняется переход по заданной ссылке, ссылка берется из property / переменной, если такая
   * переменная не найдена, то берется переданное значение при этом все ключи переменных в фигурных
   * скобках меняются на их значения из хранилища akitaScenario
   */
  @Когда("^совершен переход по ссылке \"(.*)\"$")
  public void goToUrl(String address) {
    String url = ScopedVariables.resolveVars(address);
    StatisticsHooks.getInstance().addEndpoint(url);
    open(url);
    akitaScenario.log("Url = " + url);
  }

  /**
   * Выполняется переход по заданной ссылке. Шаг содержит проверку, что после перехода загружена
   * заданная страница. Ссылка может передаваться как строка, так и как ключ из
   * application.properties
   */
  @И("^совершен переход на страницу \"(.*)\" по ссылке \"(.*)\"$")
  public void goToSelectedPageByLink(String pageName, String urlOrName) {
    Pages.getCurrentPage().goToSelectedPageByLink(pageName, urlOrName);
  }

  /** Переход на страницу по клику и проверка, что страница загружена */
  @И("^выполнен переход на страницу \"(.*)\" после нажатия на (?:ссылку|кнопку) \"(.*)\"$")
  public void urlClickAndCheckRedirection(String pageName, String elementName) {
    Pages.getCurrentPage().urlClickAndCheckRedirection(pageName, elementName);
  }

  /**
   * Шаг авторизации. Для того, чтобы шаг работал, на текущей странице должны быть указаны элементы
   * со значениями аннотации @Name: "Логин" - для поля ввода логина, "Пароль" - для поля ввода
   * пароля и "Войти" - для кнопки входа. Также должны быть указаны логин и пароль в файле
   * application.properties. Например для шага: "Пусть пользователь user ввел логин и пароль" логин
   * и пароль должны быть указаны со следующими ключами: user.login - для логина и user.password -
   * для пароля
   */
  @Пусть("^пользователь \"(.*)\" ввел логин и пароль$")
  public void loginByUserData(String userCode) {
    Pages.getCurrentPage().loginByUserData(userCode);
  }

  /** Выполняется переход в конец страницы */
  @И("^совершен переход в конец страницы$")
  public void scrollDown() {
    Pages.getCurrentPage().scrollToEndPage();
  }

  /**
   * Скроллит экран до нужного элемента, имеющегося на странице, но видимого только в нижней/верхней
   * части страницы.
   */
  @Когда("^страница прокручена до элемента \"(.*)\"$")
  public void scrollPageToElement(String elementName) {
    Pages.getCurrentPage().getElement(elementName).scrollTo();
  }

  /**
   * Скроллит страницу вниз до появления элемента каждую секунду. Если достигнут футер страницы и
   * элемент не найден - выбрасывается exception.
   */
  @И("^страница прокручена до появления элемента \"(.*)\"$")
  public void scrollWhileElemNotFoundOnPage(String elementName) {
    Pages.getCurrentPage().scrollWhileElemNotFoundOnPage(elementName);
  }

  /**
   * Скроллит страницу вниз до появления элемента с текстом из property файла, из переменной
   * сценария или указанному в шаге каждую секунду. Если достигнут футер страницы и элемент не
   * найден - выбрасывается exception.
   */
  @И("^страница прокручена до появления элемента с текстом \"(.*)\"$")
  public void scrollWhileElemWithTextNotFoundOnPage(String expectedValue) {
    Pages.getCurrentPage().scrollWhileElemWithTextNotFoundOnPage(expectedValue);
  }

  /** Переключение на вкладку браузера с заголовком */
  @Когда("^выполнено переключение на вкладку с заголовком \"(.*)\"$")
  public void switchToTheTabWithTitle(String title) {
    switchTo().window(getPropertyOrStringVariableOrValue(title));
    checkPageTitle(getPropertyOrStringVariableOrValue(title));
  }

  /** Производится сохранение заголовка страницы в переменную */
  @И("^заголовок страницы сохранен в переменную \"(.*)\"$")
  public void savePageTitleToVariable(String variableName) {
    String titleName = getWebDriver().getTitle().trim();
    akitaScenario.setVar(variableName, titleName);
    akitaScenario.log(
        "Значение заголовка страницы ["
            + titleName
            + "] сохранено в переменную ["
            + variableName
            + "]");
  }
}
