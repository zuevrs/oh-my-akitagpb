package ru.gazprombank.automation.akitagpb.modules.ui.steps;

import static ru.gazprombank.automation.akitagpb.modules.core.cucumber.ScopedVariables.resolveVars;

import io.cucumber.java.ru.И;
import io.cucumber.java.ru.Тогда;
import java.util.List;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;

/**
 * Шаги для взаимодействия с коллекциями элементов, доступные по умолчанию в каждом новом проекте
 */
@Slf4j
public class ListVerificationSteps extends UiBaseMethods {

  /**
   * Проверка появления списка на странице в течение DEFAULT_TIMEOUT. В случае, если свойство
   * "waitingCustomElementsTimeout" в application.properties не задано, таймаут равен 10 секундам
   */
  @Тогда("^список \"(.*)\" отображается на странице$")
  public void listIsPresentedOnPage(String elementName) {
    Pages.getCurrentPage().listIsPresentedOnPage(elementName);
  }

  /**
   * Проверка того, что значение из поля содержится в списке, полученном из хранилища переменных по
   * заданному ключу
   */
  @Тогда("^список из переменной \"(.*)\" содержит значение (?:поля|элемента) \"(.*)\"$")
  public void checkIfListContainsValueFromField(String variableListName, String elementName) {
    Pages.getCurrentPage().checkIfListContainsValueFromField(variableListName, elementName);
  }

  /**
   * Проверка, что список со страницы состоит только из элементов, перечисленных в таблице Для
   * получения текста из элементов списка используется метод getText()
   */
  @Тогда("^список \"(.*)\" состоит из элементов таблицы$")
  public void checkIfListInnerTextConsistsOfTableElements(String listName, List<String> textTable) {
    textTable =
        textTable.stream()
            .map(e -> getPropertyOrStringVariableOrValue(resolveVars(e)))
            .collect(Collectors.toList());
    Pages.getCurrentPage().checkIfListInnerTextConsistsOfTableElements(listName, textTable);
  }

  /**
   * Проверка, что список со страницы совпадает со списком из переменной без учёта порядка элементов
   */
  @Тогда("^список \"(.*)\" со страницы совпадает со списком \"(.*)\"$")
  public void compareListFromUIAndFromVariable(String listName, String listVariable) {
    Pages.getCurrentPage().compareListFromUIAndFromVariable(listName, listVariable);
  }

  /** Проверка, что каждый элемент списка содержит ожидаемый текст Не чувствителен к регистру */
  @Тогда("^элементы списка \"(.*)\" содержат текст \"(.*)\"$")
  public void checkListElementsContainsText(String listName, String expectedValue) {
    Pages.getCurrentPage().checkListElementsContainsText(listName, expectedValue);
  }

  /** Проверка, что каждый элемент списка не содержит ожидаемый текст */
  @Тогда("^элементы списка \"(.*)\" не содержат текст \"(.*)\"$")
  public void checkListElementsNotContainsText(String listName, String expectedValue) {
    Pages.getCurrentPage().checkListElementsNotContainsText(listName, expectedValue);
  }

  /** Проход по списку и проверка текста у элемента на соответствие формату регулярного выражения */
  @И("элементы списка \"(.*)\" соответствуют формату \"(.*)\"$")
  public void checkListTextsByRegExp(String listName, String pattern) {
    Pages.getCurrentPage().checkListTextsByRegExp(listName, pattern);
  }

  /** Производится проверка соответствия числа элементов списка значению, указанному в шаге */
  @Тогда("^в списке \"(.*)\" содержится (\\d+) (?:элемент|элементов|элемента)")
  public void listContainsNumberOfElements(String listName, int quantity) {
    Pages.getCurrentPage().listContainsNumberOfElements(listName, quantity);
  }

  /**
   * Производится проверка соответствия числа элементов списка значению из property файла, из
   * переменной сценария или указанному в шаге
   */
  @Тогда(
      "^в списке \"(.*)\" содержится количество элементов, равное значению из переменной \"(.*)\"")
  public void listContainsNumberFromVariable(String listName, String quantity) {
    Pages.getCurrentPage().listContainsNumberFromVariable(listName, quantity);
  }

  /** Производится сопоставление числа элементов списка и значения, указанного в шаге */
  @Тогда("^в списке \"(.*)\" содержится (более|менее) (\\d+) (?:элементов|элемента)")
  public void listContainsMoreOrLessElements(String listName, String moreOrLess, int quantity) {
    Pages.getCurrentPage().listContainsMoreOrLessElements(listName, moreOrLess, quantity);
  }

  /**
   * Проверка, что список со страницы совпадает со списком из переменной без учёта порядка элементов
   * Для получения текста из элементов списка используется метод innerText()
   */
  @Тогда("^список \"(.*)\" на странице совпадает со списком \"(.*)\"$")
  public void checkListInnerTextCorrespondsToListFromVariable(
      String listName, String listVariable) {
    Pages.getCurrentPage().checkListInnerTextCorrespondsToListFromVariable(listName, listVariable);
  }
}
