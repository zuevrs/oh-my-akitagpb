package ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps;

import ru.gazprombank.automation.akitagpb.modules.core.steps.isteps.IBaseMethods;
import ru.gazprombank.automation.akitagpb.modules.ui.steps.UiBaseMethods;

/**
 * Шаги, содержащие проверки состояний вэб-страницы, доступные по умолчанию в каждом новом проекте
 */
public interface IWebPageVerificationSteps extends IBaseMethods {

  default void loadingPage(String nameOfPage) {
    UiBaseMethods.loadPage(nameOfPage);
  }
}
