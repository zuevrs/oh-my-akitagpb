package ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps;

import static ru.gazprombank.automation.akitagpb.modules.core.cucumber.ScopedVariables.resolveVars;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.ex.ElementNotFound;
import java.util.List;
import ru.gazprombank.automation.akitagpb.modules.core.steps.isteps.IBaseMethods;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;

/**
 * Шаги для взаимодействия с коллекциями элементов, доступные по умолчанию в каждом новом проекте
 */
public interface IListInteractionSteps extends IBaseMethods {

  default void checkIfSelectedListElementMatchesValue(String listName, String expectedValue) {
    final String value = baseMethod.getPropertyOrStringVariableOrValue(resolveVars(expectedValue));
    ElementsCollection listOfElementsFromPage = Pages.getCurrentPage().getElementsList(listName);
    List<String> elementsText = listOfElementsFromPage.texts();
    try {
      listOfElementsFromPage.find(Condition.text(value)).click();
    } catch (ElementNotFound ex) {
      throw new IllegalArgumentException(
          String.format(
              "Элемент [%s] не найден в списке %s: [%s] ", value, listName, elementsText));
    }
  }

  default void selectElementInListIfFoundByText(String listName, String expectedValue) {
    findElementInListByText(listName, expectedValue).click();
  }

  default SelenideElement findElementInListByText(String listName, String expectedValue) {
    final String value = baseMethod.getPropertyOrStringVariableOrValue(resolveVars(expectedValue));
    ElementsCollection listOfElementsFromPage = Pages.getCurrentPage().getElementsList(listName);
    List<String> elementsText = listOfElementsFromPage.texts();
    try {
      return listOfElementsFromPage.find(Condition.partialText(value));
    } catch (ElementNotFound ex) {
      throw new IllegalArgumentException(
          String.format(
              "Элемент [%s] не найден в списке %s: [%s] ", value, listName, elementsText));
    }
  }

  default void deleteElementFromListIfFoundByText(String listName, String expectedValue) {
    findElementInListByText(listName, expectedValue).$x("./div").click();
  }

  default void selectRandomElementFromListAndSaveVar(String listName, String varName) {
    ElementsCollection listOfElementsFromPage = Pages.getCurrentPage().getElementsList(listName);
    SelenideElement element =
        listOfElementsFromPage.get(baseMethod.getRandom(listOfElementsFromPage.size()));
    element.shouldBe(Condition.visible).click();
    akitaScenario.setVar(varName, Pages.getCurrentPage().getAnyElementText(element).trim());
    akitaScenario.log(
        String.format(
            "Переменной [%s] присвоено значение [%s] из списка [%s]",
            varName, akitaScenario.getVar(varName), listName));
  }

  default void selectElementNumberFromList(Integer elementNumber, String listName) {
    SelenideElement elementToSelect = getElementFromListByNumber(elementNumber, listName);
    elementToSelect.shouldBe(Condition.visible).click();
  }

  default SelenideElement getElementFromListByNumber(Integer elementNumber, String listName) {
    ElementsCollection listOfElementsFromPage = Pages.getCurrentPage().getElementsList(listName);
    SelenideElement elementToSelect;
    int selectedElementNumber = elementNumber - 1;
    if (selectedElementNumber < 0 || selectedElementNumber >= listOfElementsFromPage.size()) {
      throw new IndexOutOfBoundsException(
          String.format(
              "В списке %s нет элемента с номером %s. Количество элементов списка = %s",
              listName, elementNumber, listOfElementsFromPage.size()));
    }
    return listOfElementsFromPage.get(selectedElementNumber);
  }

  default void deleteElementNumberFromList(Integer elementNumber, String listName) {
    getElementFromListByNumber(elementNumber, listName).$x("./div").click();
  }

  default void selectRandomElementFromList(String listName) {
    ElementsCollection listOfElementsFromPage = Pages.getCurrentPage().getElementsList(listName);
    listOfElementsFromPage
        .get(baseMethod.getRandom(listOfElementsFromPage.size()))
        .shouldBe(Condition.visible)
        .click();
    akitaScenario.log("Выбран случайный элемент: " + listOfElementsFromPage);
  }

  default void selectElementNumberFromListAndSaveToVar(
      Integer elementNumber, String listName, String varName) {
    SelenideElement elementToSelect = getElementFromListByNumber(elementNumber, listName);
    elementToSelect.shouldBe(Condition.visible).click();
    akitaScenario.setVar(varName, Pages.getCurrentPage().getAnyElementText(elementToSelect).trim());
  }
}
