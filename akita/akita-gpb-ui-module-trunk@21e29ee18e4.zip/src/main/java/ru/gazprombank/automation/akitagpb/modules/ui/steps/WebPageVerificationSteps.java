package ru.gazprombank.automation.akitagpb.modules.ui.steps;

import static com.codeborne.selenide.Selenide.$$;
import static com.codeborne.selenide.WebDriverRunner.isIE;
import static com.codeborne.selenide.WebDriverRunner.url;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsStringIgnoringCase;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;

import com.codeborne.selenide.Condition;
import io.cucumber.java.ru.И;
import io.cucumber.java.ru.Тогда;
import lombok.extern.slf4j.Slf4j;
import org.hamcrest.Matchers;
import ru.gazprombank.automation.akitagpb.modules.core.cucumber.ScopedVariables;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;

/**
 * Шаги, содержащие проверки состояний вэб-страницы, доступные по умолчанию в каждом новом проекте
 */
@Slf4j
public class WebPageVerificationSteps extends UiBaseMethods {

  /**
   * Проверка, что текущий URL совпадает с ожидаемым (берется из property / переменной, если такая
   * переменная не найдена, то берется переданное значение)
   */
  @Тогда("^текущий URL равен \"(.*)\"$")
  public void checkCurrentURL(String url) {
    String currentUrl = url();
    String expectedUrl = ScopedVariables.resolveVars(url);
    assertThat("Текущий URL не совпадает с ожидаемым", currentUrl, is(expectedUrl));
  }

  /**
   * Проверка, что текущий URL не совпадает с ожидаемым (берется из property / переменной, если
   * такая переменная не найдена, то берется переданное значение)
   */
  @Тогда("^текущий URL не равен \"(.*)\"$")
  public void checkCurrentURLIsNotEquals(String url) {
    String currentUrl = url();
    String expectedUrl = ScopedVariables.resolveVars(url);
    assertThat("Текущий URL совпадает с ожидаемым", currentUrl, Matchers.not(expectedUrl));
  }

  /**
   * Проверка того, что все элементы, которые описаны в классе страницы с аннотацией @Name, но без
   * аннотации @Optional появились на странице в течение WAITING_APPEAR_TIMEOUT, которое равно
   * значению свойства "waitingAppearTimeout" из application.properties. Если свойство не найдено,
   * время таймаута равно 8 секундам
   */
  @Тогда("^(?:страница|форма|вкладка) \"(.*)\" (?:загрузилась|загрузился)$")
  public void loadingPage(String nameOfPage) {
    nameOfPage = ScopedVariables.resolveVars(nameOfPage);
    loadPage(nameOfPage);
  }

  /**
   * Проверка того, что все элементы, которые описаны в классе страницы с аннотацией @Name, но без
   * аннотации @Optional, не появились на странице
   */
  @Тогда("^(?:страница|форма|вкладка) \"(.*)\" не (?:загрузилась|загрузился)$")
  public void loadPageFailed(String nameOfPage) {
    Pages.setCurrentPage(Pages.getPage(nameOfPage));
    if (isIE()) {
      Pages.getCurrentPage().ieDisappeared();
    } else {
      Pages.getCurrentPage().disappeared();
    }
  }

  /** Проверка того, что страница исчезла/стала невидимой */
  @Тогда("^(?:страница|форма) \"(.*)\" (?:скрыт|скрыта)")
  public void blockDisappeared(String nameOfPage) {
    if (isIE()) {
      Pages.getPage(nameOfPage).ieDisappeared();
    } else {
      Pages.getPage(nameOfPage).isDisappeared();
    }
  }

  /**
   * Проверка, что на странице не отображаются редактируемые элементы, такие как: -input -textarea
   */
  @Тогда("^открыта read-only форма$")
  public void openReadOnlyForm() {
    int inputsCount = $$("input").filter(Condition.visible).size();
    assertEquals(0, inputsCount, "Форма не read-only. Количество input-полей: " + inputsCount);
    int textareasCount = $$("textarea").filter(Condition.visible).size();
    assertEquals(
        0, textareasCount, "Форма не read-only. Количество элементов textarea: " + textareasCount);
  }

  /**
   * Проверка, что значение в ссылке страницы содержит текст, указанный в шаге (в приоритете: из
   * property, из переменной сценария, значение аргумента)
   */
  @И("^ссылка страницы содержит текст \"(.*)\"$")
  public void linkShouldHaveText(String text) {
    String currentUrl = url();
    assertThat(currentUrl, containsStringIgnoringCase(getPropertyOrStringVariableOrValue(text)));
  }

  /**
   * Производится сравнение заголовка страницы со значением, указанным в шаге (в приоритете: из
   * property, из переменной сценария, значение аргумента)
   */
  @Тогда("^заголовок страницы равен \"(.*)\"$")
  public void checkTitlePage(String pageTitleName) {
    checkPageTitle(getPropertyOrStringVariableOrValue(pageTitleName));
  }
}
