package ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api;

import com.codeborne.selenide.Selenide;
import com.google.common.collect.Maps;
import java.lang.reflect.Constructor;
import java.util.Arrays;
import java.util.Map;
import java.util.function.Consumer;
import lombok.SneakyThrows;
import ru.gazprombank.automation.akitagpb.modules.core.cucumber.api.AnnotationScanner;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.annotations.Name;

/** Предназначен для хранения страниц, используемых при прогоне тестов */
public final class Pages {

  private static final ThreadLocal<Pages> instance = new ThreadLocal<>();

  /** Страницы, на которых будет производится тестирование < Имя, Страница > */
  private final Map<String, AkitaPage> pages;

  /** Страница, на которой в текущий момент производится тестирование */
  private AkitaPage currentPage;

  private Pages() {
    pages = Maps.newHashMap();
  }

  public static Pages getInstance() {
    return instance.get();
  }

  /**
   * Метод ищет классы, аннотированные "AkitaPage.Name", добавляя ссылки на эти классы в поле
   * "pages"
   */
  private void initPages() {
    new AnnotationScanner()
        .getClassesAnnotatedWith(Name.class).stream()
            .map(
                it -> {
                  if (AkitaPage.class.isAssignableFrom(it)) {
                    return (Class<? extends AkitaPage>) it;

                  } else {
                    throw new IllegalStateException(
                        "Класс " + it.getName() + " должен наследоваться от AkitaPage");
                  }
                })
            .forEach(clazz -> put(getClassAnnotationValue(clazz), clazz));
  }

  public static void setPagesInstance() {
    instance.set(new Pages());
    getInstance().initPages();
  }

  /**
   * Вспомогательный метод, получает значение аннотации "AkitaPage.Name" для класса
   *
   * @param c класс, который должен быть аннотирован "AkitaPage.Name"
   * @return значение аннотации "AkitaPage.Name" для класса
   */
  private static String getClassAnnotationValue(Class<?> c) {
    return Arrays.stream(c.getAnnotationsByType(Name.class))
        .findAny()
        .map(Name::value)
        .orElseThrow(
            () ->
                new AssertionError(
                    "Не найдены аннотации AkitaPage.Name в класса " + c.getClass().getName()));
  }

  /** Возвращает текущую страницу, на которой в текущий момент производится тестирование */
  public static AkitaPage getCurrentPage() {
    if (getInstance().currentPage == null) {
      getInstance().currentPage = new AkitaPage();
    }

    return getInstance().currentPage.initialize();
  }

  /** Задает текущую страницу по ее имени */
  public static void setCurrentPage(AkitaPage page) {
    if (page == null) {
      throw new IllegalArgumentException(
          "Происходит переход на несуществующую страницу. "
              + "Проверь аннотации @Name у используемых страниц");
    }
    getInstance().currentPage = page;
  }

  /**
   * Реализация анонимных методов со страницей в качестве аргумента
   *
   * @param clazz класс страницы
   * @param checkIfElementsAppeared проверка всех не помеченных "@Optional" элементов
   */
  public static <T extends AkitaPage> void withPage(
      Class<T> clazz, boolean checkIfElementsAppeared, Consumer<T> consumer) {
    T page = getPage(clazz, checkIfElementsAppeared);
    consumer.accept(page);
  }

  /**
   * Позволяет получить доступ к полям и методам конкретной страницы, которая передается в метод в
   * качестве аргумента. Пример использования: {@code withPage(AkitaPage.class, page -> { some
   * actions with AkitaPage methods});} Проверка отображения всех элементов страницы выполняется
   * всегда
   *
   * @param clazz класс страницы, доступ к полям и методам которой необходимо получить
   */
  public static <T extends AkitaPage> void withPage(Class<T> clazz, Consumer<T> consumer) {
    withPage(clazz, true, consumer);
  }

  /** Получение страницы из "pages" по имени */
  public static AkitaPage getPage(String pageName) {
    return Selenide.page(getPageFromPagesByName(pageName)).initialize();
  }

  /** Получение страницы по классу */
  public static <T extends AkitaPage> T getPage(Class<T> clazz, String name) {
    AkitaPage page = Selenide.page(getPageFromPagesByName(name)).initialize();

    if (!clazz.isInstance(page)) {
      throw new IllegalStateException(
          name + " page is not a instance of " + clazz + ". Named page is a " + page);
    }
    return (T) page;
  }

  public static AkitaPage getPageFromPagesByName(String pageName) {
    AkitaPage page = getInstance().pages.get(pageName);

    if (page == null) {
      throw new IllegalArgumentException(
          pageName + " page is not declared in a list of available pages");
    }

    return page;
  }

  /** Добавление инстанциированной страницы в "pages" с проверкой на NULL */
  public static <T extends AkitaPage> void put(String pageName, T page)
      throws IllegalArgumentException {
    if (page == null) {
      throw new IllegalArgumentException("Была передана пустая страница");
    }
    getInstance().pages.put(pageName, page);
  }

  /** Получение страницы по классу с возможностью выполнить проверку элементов страницы */
  public static <T extends AkitaPage> T getPage(Class<T> clazz, boolean checkIfElementsAppeared) {
    T page = Selenide.page(clazz);

    if (checkIfElementsAppeared) {
      page.initialize().isAppeared();
    }

    return page;
  }

  public static <T extends AkitaPage> T getPage(Class<T> clazz) {
    return getPage(clazz, true);
  }

  public static <T extends AkitaPage> AkitaPage getPageAndInitialize(
      Class<T> clazz, boolean checkIfElementsAppeared) {
    return getPage(clazz, checkIfElementsAppeared).initialize();
  }

  /** Добавление страницы в "pages" по классу */
  @SneakyThrows
  public static void put(String pageName, Class<? extends AkitaPage> page) {
    if (page == null) {
      throw new IllegalArgumentException("Была передана пустая страница");
    }

    Constructor<? extends AkitaPage> constructor = page.getDeclaredConstructor();
    constructor.setAccessible(true);
    AkitaPage p = constructor.newInstance();
    getInstance().pages.put(pageName, p);
  }
}
