package ru.gazprombank.automation.akitagpb.modules.ui.steps;

import io.cucumber.java.ru.Тогда;
import lombok.extern.slf4j.Slf4j;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;

/** Шаги для тестирования отдельных блоков страницы */
@Slf4j
public class PageBlockSteps extends UiBaseMethods {

  @Тогда("^блок \"(.*)\" загрузился$")
  public void loadingBlock(String blockName) {
    Pages.setCurrentPage(Pages.getCurrentPage().getBlock(blockName));
  }

  @Тогда("^на (?:странице|форме|вкладке) \"(.*)\" блок \"(.*)\" загрузился$")
  public void loadingBlock(String pageName, String blockName) {
    Pages.getPage(pageName).loadingPage(pageName);
    loadingBlock(blockName);
  }
}
