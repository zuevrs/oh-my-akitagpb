package ru.gazprombank.automation.akitagpb.modules.ui.helpers;

import org.openqa.selenium.By;
import org.openqa.selenium.support.FindBy;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.AkitaPage;

public class AnnotationHelper {

  /**
   * Метод возвращает стратегию поиска элемента из Page Object по имени элемента
   *
   * @param akitaPage страница AkitaPage
   * @param elementName имя элемента в Page Object
   * @return стратегию поиска By
   */
  public static By getFindByElement(AkitaPage akitaPage, String elementName) {
    FindBy findByAnnotation =
        akitaPage.getClassFieldByElementName(elementName).getAnnotation(FindBy.class);
    FindBy.FindByBuilder findByBuilder = new FindBy.FindByBuilder();
    return findByBuilder.buildIt(findByAnnotation, null);
  }

  /**
   * Метод возвращает аннотацию FindBy из Page Object по имени элемента
   *
   * @param akitaPage страница AkitaPage
   * @param elementName имя элемента в Page Object
   * @return стратегию поиска FindBy
   */
  public static FindBy getFindBy(AkitaPage akitaPage, String elementName) {
    return akitaPage.getClassFieldByElementName(elementName).getAnnotation(FindBy.class);
  }
}
