package ru.gazprombank.automation.akitagpb.modules.ui.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static ru.gazprombank.automation.akitagpb.modules.core.cucumber.ScopedVariables.resolveVars;

import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.ru.И;
import io.cucumber.java.ru.Тогда;
import java.util.List;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;

/** Шаги для взаимодействия с выпадающими списками, доступные по умолчанию в каждом новом проекте */
@Slf4j
public class DropDownListInteractionSteps extends UiBaseMethods {

  /**
   * Выбор из выпадающего списка элемента с заданным текстом (в приоритете: из property, из
   * переменной сценария, значение аргумента)
   */
  @Тогда("^в выпадающем списке \"(.*)\" выбран элемент с текстом \"(.*)\"$")
  public void selectElementFromDropDownListWithText(String listName, String expectedText) {
    expectedText = getPropertyOrStringVariableOrValue(resolveVars(expectedText));
    Pages.getCurrentPage().selectElementFromDropDownListWithText(listName, expectedText);
  }

  /** Выбор из выпадающего списка элемента с параметрами xpath с заданным текстом */
  @И(
      "^в выпадающем списке \"(.*)\" с параметрами xpath-(?:локатора|селектора) выбираем элемент с текстом \"(.*)\"$")
  public void selectElementWithXpathArgsFromDropDownListWithText(
      String dropDownName, String expectedText, List<String> args) {
    expectedText = getPropertyOrStringVariableOrValue(resolveVars(expectedText));
    SelenideElement dropDownElement =
        Pages.getCurrentPage().getElement(dropDownName, args.toArray(String[]::new));
    Pages.getCurrentPage()
        .selectElementWithXpathArgsFromDropDownWithText(dropDownElement, expectedText);
  }

  /** Выбор из выпадающего списка со множественным выбором элементов с заданным текстом */
  @Тогда("^в выпадающем списке \"(.*)\" выбраны элементы с текстом:?$")
  public void selectElementsFromDropDownListWithText(String listName, List<String> textValues) {
    textValues =
        textValues.stream()
            .map(e -> getPropertyOrStringVariableOrValue(resolveVars(e)))
            .collect(Collectors.toList());
    Pages.getCurrentPage().selectElementsFromDropDownListWithText(listName, textValues);
  }

  /**
   * Выбор из выпадающего списка элемента с заданным значением (в приоритете: из property, из
   * переменной сценария, значение аргумента)
   */
  @Тогда("^в выпадающем списке \"(.*)\" выбран элемент со значением \"(.*)\"$")
  public void selectElementFromDropDownListWithValue(String listName, String expectedValue) {
    Pages.getCurrentPage().selectElementFromDropDownListWithValue(listName, expectedValue);
  }

  /**
   * Выбор из выпадающего списка n-го элемента (в приоритете: из property, из переменной сценария,
   * значение аргумента)
   */
  @Тогда("^выбран (\\d+)-й элемент в выпадающем списке \"(.*)\"$")
  public void selectElementNumberFromDropDownList(int elementNumber, String listName) {
    Pages.getCurrentPage().selectElementNumberFromDropDownList(elementNumber, listName);
  }

  /**
   * Выбор из выпадающего списка элемента, содержащего заданный текст (в приоритете: из property, из
   * переменной сценария, значение аргумента)
   */
  @Тогда("^в выпадающем списке \"(.*)\" выбран элемент содержащий текст \"(.*)\"$")
  public void selectElementFromDropDownListContainingText(String listName, String expectedText) {
    Pages.getCurrentPage().selectElementFromDropDownListContainingText(listName, expectedText);
  }

  /**
   * Выбрать случайный элемент из выпадающего списка и сохранить его текстовое значение в переменную
   */
  @Тогда(
      "^в выпадающем списке \"(.*)\" выбран случайный элемент и его значение сохранено в переменную \"(.*)\"$")
  public void selectRandomElementFromDropDownListAndSaveTextValue(String listName, String varName) {
    String textValue =
        Pages.getCurrentPage().selectRandomElementFromDropDownListAndGetTextValue(listName);
    akitaScenario.setVar(varName, textValue);
    akitaScenario.log(String.format("Значение %s: %s", varName, textValue));
  }

  /** Выбрать n случайных элементов из выпадающего списка со множественным выбором */
  @Тогда(
      "^в выпадающем списке со множественным выбором \"(.*)\" выбрано? (\\d+) случайны(?:й|х) элемент(?:а|ов)?$")
  public void selectRandomElementsFromDropDownList(String listName, int elementsNumber) {
    Pages.getCurrentPage().selectRandomElementsFromDropDownList(listName, elementsNumber);
  }

  /**
   * Сохранить текстовые значения выбранных элементов выпадающего списка со множественным выбором в
   * переменные из списка
   */
  @Тогда(
      "^выбранные значения выпадающего списка с множественным выбором \"(.*)\" сохранены в переменные:?$")
  public void saveSelectedElementsFromDropDownList(String listName, List<String> varNames) {
    List<String> textValues =
        Pages.getCurrentPage().getDropDownListSelectedElementsTextValues(listName);
    assertThat(textValues.size())
        .as(
            "Число выбранных элементов в выпадающем списке не равно числу переменных в параметрах шага")
        .isEqualTo(varNames.size());
    for (int i = 0; i < varNames.size(); i++) {
      akitaScenario.setVar(varNames.get(i), textValues.get(i));
      akitaScenario.log(String.format("Значение %s: %s", varNames.get(i), textValues.get(i)));
    }
  }
}
