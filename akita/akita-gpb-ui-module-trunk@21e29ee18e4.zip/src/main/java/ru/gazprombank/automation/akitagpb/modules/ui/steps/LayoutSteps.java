package ru.gazprombank.automation.akitagpb.modules.ui.steps;

/** Шаги для тестирования верстки (Galen Framework) */
public class LayoutSteps extends UiBaseMethods {

  /**
   * Шаг проверяет, что текущая страница соответствует описанным в .spec файле требованиям
   *
   * @param spec - Название galen спецификации .spec, где описан ожидаемый дизайн страницы По
   *     умолчанию ожидается, что .spec файлы находятся по пути /src/test/resources/specs. Этот путь
   *     можно переопределить, задав системную переменную specsDir
   */
  //    @Тогда("^Страница соответствует ожидаемой спецификации \"(.*)\"")
  //    public void compareCurrentPageWithBase(String spec) {
  //        checkLayoutAccordingToSpec(spec, null);
  //    }

  /**
   * Шаг проверяет, что текущая страница соответствует описанным в .spec файле требованиям
   *
   * @param spec - Название galen спецификации .spec, где описан ожидаемый дизайн страницы По
   *     умолчанию ожидается, что .spec файлы находятся по пути /src/test/resources/specs. Этот путь
   *     можно переопределить, задав системную переменную specsDir
   * @param tag - название тэга в galen спецификации (например @on desktop), для которого описан
   *     дизайн конкретных элементов.
   */
  //    @Тогда("^Страница соответствует спецификации \"(.*)\" для экрана \"(\\D+)\"")
  //    public void compareCurrentPageWithBase(String spec, String tag) {
  //        List<String> tags = new ArrayList<>();
  //        tags.add(tag);
  //        checkLayoutAccordingToSpec(spec, tags);
  //    }
}
