package ru.gazprombank.automation.akitagpb.modules.ui.hooks.devtools;

import lombok.Data;
import org.openqa.selenium.devtools.v142.network.model.Request;
import org.openqa.selenium.devtools.v142.network.model.RequestId;
import org.openqa.selenium.devtools.v142.network.model.Response;

@Data
public class RequestNode {
  private RequestId requestId;
  private String url;
  private Long time;
  private Request request;
  private Response response;
  private String responseBody;
  private String requestBody;
  private String method;
  private Integer statusCode;

  public RequestNode(String requestId) {
    this.requestId = toRequestId(requestId);
  }

  public boolean isHasResponseBody() {
    return responseBody != null;
  }

  public boolean isHasRequestBody() {
    return requestBody != null;
  }

  private RequestId toRequestId(String requestId) {
    return new RequestId(requestId);
  }
}
