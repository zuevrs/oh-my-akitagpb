package ru.gazprombank.automation.akitagpb.modules.ui.helpers;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class ListHelper {

  /**
   * Получить рандомный Selenide элемент списка
   *
   * @param list список
   * @return рандомный элемент списка
   */
  public static SelenideElement getRandomListElement(ElementsCollection list) {
    return list.get(getRandomNumber("0", String.valueOf(list.size())).intValue());
  }

  /**
   * Получить N рандомных элементов списка
   *
   * @param list список
   * @param number число рандомных элементов
   * @return список из number рандомных элементов
   */
  public static List<SelenideElement> getRandomListElements(ElementsCollection list, int number) {
    if (number > list.size()) {
      throw new IllegalArgumentException(
          String.format(
              "Переданный список содержит меньше элементов (%d), чем ожидается получить (%d)",
              list.size(), number));
    }
    var listIndexes = IntStream.range(0, list.size()).boxed().collect(Collectors.toList());
    Collections.shuffle(listIndexes);
    return listIndexes.stream().limit(number).map(list::get).collect(Collectors.toList());
  }

  /**
   * Метод для получения рандомного числа типа long в указанных пределах.
   *
   * @param from нижний предел (если null - будет равен 0)
   * @param to верхний предел (если null - будет равен {нижний предел} + 100000)
   * @return возвращает рандомное число в заданных пределах.
   */
  private static Long getRandomNumber(String from, String to) {
    var random = ThreadLocalRandom.current();
    long fromLong = from == null ? 0 : Long.parseLong(from);
    long toLong = to == null ? fromLong + 100000 : Long.parseLong(to);
    return random.nextLong(fromLong, toLong);
  }
}
