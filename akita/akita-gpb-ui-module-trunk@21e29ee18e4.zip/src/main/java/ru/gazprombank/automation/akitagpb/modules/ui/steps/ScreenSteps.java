package ru.gazprombank.automation.akitagpb.modules.ui.steps;

import static com.codeborne.selenide.Selectors.byAttribute;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.WebDriverRunner.getWebDriver;
import static io.qameta.allure.Allure.label;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static ru.gazprombank.automation.akitagpb.modules.core.steps.isteps.IBaseMethods.akitaScenario;
import static ru.yandex.qatools.ashot.util.ImageTool.toByteArray;

import com.epam.reportportal.listeners.ItemStatus;
import com.epam.reportportal.service.Launch;
import com.epam.reportportal.service.step.StepReporter;
import io.cucumber.java.ru.И;
import io.qameta.allure.Allure;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import javax.imageio.ImageIO;
import lombok.SneakyThrows;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.comparison.ImageDiff;
import ru.yandex.qatools.ashot.comparison.ImageDiffer;
import ru.yandex.qatools.ashot.coordinates.WebDriverCoordsProvider;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

/** Шаги для работы со скриншотами */
public class ScreenSteps {
  private static final String PATH_NAME = "src/test/resources/screenshots/";

  @И("^Сделать скриншот всей страницы и сохранить в переменную \"(.*)\"$")
  @SneakyThrows
  public static Screenshot takeScreenShot(String screenName) {
    Screenshot screenshot =
        new AShot()
            .coordsProvider(new WebDriverCoordsProvider())
            .shootingStrategy(ShootingStrategies.viewportPasting(100))
            .takeScreenshot(
                getWebDriver(),
                $(
                    byAttribute(
                        "style", "box-sizing: border-box; position: absolute; width: 100%;")));

    akitaScenario.setVar(screenName, screenshot);
    attachScreenshot("Скриншот", toByteArray(screenshot.getImage()));
    return screenshot;
  }

  @И("^Сделать скриншот элемента \"(.*)\" на странице и сохранить в переменную \"(.*)\"$")
  @SneakyThrows
  public static Screenshot takeElementScreenShot(String elementName, String screenName) {
    Screenshot screenshot =
        new AShot()
            .coordsProvider(new WebDriverCoordsProvider())
            .takeScreenshot(getWebDriver(), Pages.getCurrentPage().getElement(elementName));

    akitaScenario.setVar(screenName, screenshot);
    attachScreenshot("Скриншот", toByteArray(screenshot.getImage()));
    return screenshot;
  }

  @И("^Сохранить скриншот \"(.*)\" в директорию src/test/resources/screenshots/ с именем \"(.*)\"$")
  @SneakyThrows
  public static void saveScreenShot(String screenshotName, String filename) {
    var screenshot = (Screenshot) akitaScenario.getVar(screenshotName);
    ImageIO.write(screenshot.getImage(), "png", new File(PATH_NAME + filename + ".png"));
  }

  @И("^Получить скриншот из проекта по имени \"(.*)\" и сохранить в переменную \"(.*)\"$")
  @SneakyThrows
  public static void loadScreenShot(String filename, String screenName) {
    Screenshot screenshot = new Screenshot(ImageIO.read(new File(PATH_NAME + filename + ".png")));
    attachScreenshot(filename, toByteArray(screenshot.getImage()));
    akitaScenario.setVar(screenName, screenshot);
  }

  @И("^Сравнить скриншот \"(.*)\" с \"(.*)\"$")
  @SneakyThrows
  public static void checkScreens(String actualScreenName, String expectedScreenName) {
    var actual = (Screenshot) akitaScenario.getVar(actualScreenName);
    Screenshot expected;
    try {
      akitaScenario.getVar(expectedScreenName);
    } catch (IllegalArgumentException e) {
      loadScreenShot(expectedScreenName, expectedScreenName);
    } finally {
      expected = (Screenshot) akitaScenario.getVar(expectedScreenName);
    }
    ImageDiff diff = new ImageDiffer().makeDiff(expected, actual);
    boolean hasDiff = diff.hasDiff();
    BufferedImage diffImage = diff.getMarkedImage();

    if (hasDiff) {
      label("testType", "screenshotDiff");
      attachScreenshot("diff", toByteArray(diffImage));
      attachScreenshot("actual", toByteArray(actual.getImage()));
      attachScreenshot("expected", toByteArray(expected.getImage()));
    }

    assertFalse(hasDiff, "Скриншоты отличаются");
  }

  @SneakyThrows
  private static void attachScreenshot(final String name, final byte[] data) {
    Allure.attachment(name, new ByteArrayInputStream(data));

    // Прикладываем скриншоты в Report Portal
    Launch launch = Launch.currentLaunch();
    if (launch != null) {
      StepReporter stepReporter = launch.getStepReporter();
      File attachFile = Files.write(Paths.get("build", name), data).toFile();
      stepReporter.sendStep(ItemStatus.PASSED, name, attachFile);
    }
  }
}
