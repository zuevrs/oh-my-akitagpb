package ru.gazprombank.automation.akitagpb.modules.ui.steps;

import io.cucumber.java.ru.И;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;

/** Шаги для взаимодействиями с радиобаттонами */
public class RadiobuttonSteps extends UiBaseMethods {

  @И("^выполнено нажатие на радиобаттон \"(.*)\"$")
  public void clickRadiobutton(String elementName) {
    Pages.getCurrentPage().clickRadiobutton(elementName);
  }

  @И("^радиобаттон \"(.*)\" выбран$")
  public void checkRadiobuttonIsActive(String elementName) {
    Pages.getCurrentPage().checkRadiobuttonIsActive(elementName);
  }

  @И("^радиобаттон \"(.*)\" не выбран$")
  public void checkRadiobuttonIsNotActive(String elementName) {
    Pages.getCurrentPage().checkRadiobuttonIsNotActive(elementName);
  }

  /**
   * Шаг переключает радиокнопку в определенное состояние (включение|выключение) внезависимости в
   * каком состоянии было первоначально
   */
  @И("^выполнено (включение|выключение) радиобаттон \"(.*)\"$")
  public void actionForRadiobutton(String action, String elementName) {
    Pages.getCurrentPage().actionForRadiobutton(action.equals("включение"), elementName);
  }
}
