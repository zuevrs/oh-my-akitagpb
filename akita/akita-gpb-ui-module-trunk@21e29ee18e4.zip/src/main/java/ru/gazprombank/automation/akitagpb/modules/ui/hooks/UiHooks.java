package ru.gazprombank.automation.akitagpb.modules.ui.hooks;

import static com.codeborne.selenide.WebDriverRunner.*;

import com.codeborne.selenide.WebDriverRunner;
import com.google.common.base.Strings;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.TakesScreenshot;
import ru.gazprombank.automation.akitagpb.modules.ui.cucumber.api.Pages;
import ru.gazprombank.automation.akitagpb.modules.ui.drivers.CustomDriverProvider;
import ru.gazprombank.automation.akitagpb.modules.ui.steps.UiBaseMethods;

@Slf4j
public class UiHooks extends UiBaseMethods {

  /** Уведомление о месте запуска тестов */
  @Before(order = 20)
  public static void setEnvironmentToTest() {
    if (!Strings.isNullOrEmpty(System.getProperty(CustomDriverProvider.REMOTE_URL))) {
      log.info(
          "Тесты запущены на удаленной машине: "
              + System.getProperty(CustomDriverProvider.REMOTE_URL));

    } else {
      log.info("Тесты будут запущены локально");
    }
  }

  /**
   * Установить новый инстанс класса Pages (в котором хранится текущая страница) для текущего теста
   */
  @Before(order = 10)
  public void setPagesInstance() {
    Pages.setPagesInstance();
    log.info("Новый инстанс класса Pages установлен для текущего теста");
  }

  /** Создает настойки прокси для запуска драйвера */
  @Before(order = 1)
  public void setDriverProxy() {
    if (!Strings.isNullOrEmpty(System.getProperty("proxy"))) {
      Proxy proxy = new Proxy().setHttpProxy(System.getProperty("proxy"));
      setProxy(proxy);
      log.info("Проставлена прокси: " + proxy);
    }
  }

  /**
   * Если сценарий завершился со статусом "fail" будет создан скриншот и сохранен в директорию
   * {@code <project>/build/reports/tests}
   *
   * @param scenario текущий сценарий
   */
  @After(order = 20)
  public void takeScreenshot(Scenario scenario) {
    if (scenario.isFailed() && hasWebDriverStarted()) {
      final byte[] screenshot =
          ((TakesScreenshot) getWebDriver()).getScreenshotAs(OutputType.BYTES);
      scenario.attach(screenshot, "image/png", "");
    }
  }

  /** По завершению теста удаляет все куки и закрывает веб-браузер */
  @After(order = 10)
  public void closeWebDriver() {
    if (hasWebDriverStarted()) {
      getWebDriver().manage().deleteAllCookies();
      WebDriverRunner.closeWebDriver();
    }
  }
}
