package ru.gazprombank.automation.akitagpb.modules.ui.steps.isteps;

import ru.gazprombank.automation.akitagpb.modules.core.steps.isteps.IBaseMethods;

/** Шаги для тестирования верстки (Galen Framework) */
public interface ILayoutSteps extends IBaseMethods {}
