package ru.gazprombank.automation.akitagpb.modules.ccl.kibana.api.rest.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class RawResponse {
  private Long took;

  @JsonProperty("timed_out")
  private Boolean timedOut;

  @JsonProperty("_shards")
  private Object shards;

  private Hits hits;
  private Object aggregations;
}
