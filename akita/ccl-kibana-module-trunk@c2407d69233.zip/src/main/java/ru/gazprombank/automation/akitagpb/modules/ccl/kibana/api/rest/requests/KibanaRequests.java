package ru.gazprombank.automation.akitagpb.modules.ccl.kibana.api.rest.requests;

import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.assertThat;

import io.restassured.http.ContentType;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import net.arnx.wmf2svg.util.Base64;
import org.awaitility.Awaitility;
import org.awaitility.core.ConditionTimeoutException;
import org.json.JSONArray;
import org.json.JSONObject;
import ru.gazprombank.automation.akitagpb.modules.ccl.helpers.FileHelper;
import ru.gazprombank.automation.akitagpb.modules.ccl.helpers.date.DateCalculator;
import ru.gazprombank.automation.akitagpb.modules.ccl.helpers.date.DateHelper;
import ru.gazprombank.automation.akitagpb.modules.ccl.kibana.api.rest.models.KibanaGetLogsResponse;
import ru.gazprombank.automation.akitagpb.modules.core.cucumber.api.AkitaScenario;
import ru.gazprombank.automation.akitagpb.modules.core.helpers.ConfigLoader;

public class KibanaRequests {

  private static final String KIBANA_URL = ConfigLoader.getConfigValue("kibana.base.url");
  private static final Integer KIBANA_REQUESTS_ONE_ATTEMPT_TIMEOUT =
      ConfigLoader.getConfigValueOrDefault("kibana.requests.oneAttemptTimeout", 10);
  private static final Integer KIBANA_REQUESTS_POLL_INTERVAL =
      ConfigLoader.getConfigValueOrDefault("kibana.requests.pollInterval", 1);
  private static final Map<String, String> KIBANA_HEADERS =
      ConfigLoader.getConfigValueOrDefault("kibana.headers", new HashMap<>());
  private static final String username = ConfigLoader.getConfigValue("kibana.username");
  private static final String password = ConfigLoader.getConfigValue("kibana.password");

  public static RequestSpecification getKibanaSpecification() {
    RequestSpecification specification = given().baseUri(KIBANA_URL).headers(KIBANA_HEADERS);

    if (username != null && password != null) {
      specification.header(
          "Authorization",
          "Basic " + Base64.encode(String.format("%s:%s", username, password).getBytes()));
    }

    return specification;
  }

  /**
   * Отправить запрос получения логов из Кибаны - POST {kibana.base.url}/internal/bsearch
   *
   * @param body тело запроса
   * @return ответ сервера
   */
  public static ValidatableResponse getKibanaLogs(Object body) {
    return getKibanaSpecification()
        .body(body)
        .contentType(ContentType.JSON)
        .post("/internal/bsearch")
        .then()
        .statusCode(200);
  }

  /**
   * Метод формирует тело запроса по переданным параметрам и посылает запрос на получение логов из
   * Кибаны - POST {kibana.base.url}/internal/bsearch - если нужно, несколько раз, пока не будет
   * получен ответ.
   *
   * @param index паттерн индекса для поиска логов в Кибане (например, ebg-*)
   * @param timeRange временной интервал поиска логов (10s, 2m)
   * @param fields поля фильтрации логов
   * @param values значения полей фильтрации логов
   * @return ответ сервера
   */
  public static String getKibanaLogs(
      String index, String timeRange, List<String> fields, List<String> values) {
    var body = getKibanaLogsRequestBody(index, timeRange, fields, values);
    var response = getNotPartialResponse(new JSONObject(body.toString()));
    return response.extract().body().asPrettyString();
  }

  /**
   * Метод для ожидания получения переданного количества логов. Аналогичен методу {@link
   * #getKibanaLogs(String, String, List, List)}, но посылает запрос циклично, пока количесвто логов
   * в ответе не будет равно ожидаемому количеству.
   *
   * @param index паттерн индекса для поиска логов в Кибане (например, ebg-*)
   * @param timeRange временной интервал поиска логов (10s, 2m)
   * @param fields поля фильтрации логов
   * @param values значения полей фильтрации логов
   * @param expectedLogsNumber ожидаемое количество логов
   * @param timeout максимальное время ожидания
   * @return ответ сервера
   */
  public static String getKibanaLogsWithTimeout(
      String index,
      String timeRange,
      List<String> fields,
      List<String> values,
      Integer expectedLogsNumber,
      Integer timeout) {
    var body = getKibanaLogsRequestBody(index, timeRange, fields, values);
    if (timeout < KIBANA_REQUESTS_ONE_ATTEMPT_TIMEOUT) {
      timeout = KIBANA_REQUESTS_ONE_ATTEMPT_TIMEOUT;
      AkitaScenario.getInstance()
          .log(
              String.format(
                  """
                                          Заданное ограничение времени получения логов переопределено, т.к. оно было меньше временного лимита
                                          одной попытки запроса, указанного в опции 'kibana.requests.oneAttemptTimeout':
                                          timeout = %s
                                          """,
                  KIBANA_REQUESTS_ONE_ATTEMPT_TIMEOUT));
    }
    AtomicReference<ValidatableResponse> result = new AtomicReference<>();
    try {
      Awaitility.await()
          .pollInSameThread()
          .timeout(timeout, TimeUnit.SECONDS)
          .pollInterval(KIBANA_REQUESTS_POLL_INTERVAL, TimeUnit.SECONDS)
          .until(
              () -> {
                result.set(getNotPartialResponse(new JSONObject(body.toString())));
                var actualLogsNumber =
                    result
                        .get()
                        .extract()
                        .body()
                        .as(KibanaGetLogsResponse.class)
                        .getResult()
                        .getRawResponse()
                        .getHits()
                        .getTotal();
                if (actualLogsNumber > expectedLogsNumber) {
                  throw new RuntimeException(
                      String.format(
                          "Количество логов, полученных по данному запросу (%s), больше ожидаемого количества (%s). Необходимо"
                              + " скорректировать запрос к Кибане, чтобы он возвращал только нужные логи.",
                          actualLogsNumber, expectedLogsNumber));
                }
                return actualLogsNumber.equals(expectedLogsNumber);
              });
    } catch (ConditionTimeoutException e) {
      throw new RuntimeException("Общее время получения логов из Кибаны вышло.", e);
    }
    return result.get().extract().body().asPrettyString();
  }

  /**
   * Получить логи Кибаны, пока ответ не будет содержать параметр result.isPartial = false
   *
   * @param body тело запроса
   * @return ответ сервера
   */
  private static ValidatableResponse getNotPartialResponse(JSONObject body) {
    AtomicReference<ValidatableResponse> result = new AtomicReference<>();
    AtomicReference<KibanaGetLogsResponse> response = new AtomicReference<>();
    AtomicReference<String> requestId = new AtomicReference<>();
    AtomicBoolean isFirstAttempt = new AtomicBoolean(true);

    try {
      Awaitility.await()
          .pollInSameThread()
          .timeout(KIBANA_REQUESTS_ONE_ATTEMPT_TIMEOUT, TimeUnit.SECONDS)
          .pollInterval(KIBANA_REQUESTS_POLL_INTERVAL, TimeUnit.SECONDS)
          .until(
              () -> {
                if (!isFirstAttempt.get()
                    && response.get().getResult().getId() != null
                    && !response.get().getResult().getId().equals(requestId.get())) {
                  requestId.set(response.get().getResult().getId());
                  body.getJSONArray("batch")
                      .getJSONObject(0)
                      .getJSONObject("request")
                      .put("id", requestId);
                }
                result.set(getKibanaLogs(body.toString(10)));
                response.set(result.get().extract().body().as(KibanaGetLogsResponse.class));
                isFirstAttempt.set(false);
                if (response.get().getError() != null) {
                  throw new RuntimeException(
                      "Не удалось получить логи Кибаны по данному запросу\n"
                          + response.get().getError().toString());
                }
                return !response.get().getResult().getIsPartial();
              });
    } catch (ConditionTimeoutException e) {
      throw new RuntimeException(
          String.format(
              "Время одной попытки получения логов из Кибаны, заданное в опции 'kibana.requests.oneAttemptTimeout' = [%s], вышло.",
              KIBANA_REQUESTS_ONE_ATTEMPT_TIMEOUT),
          e);
    }
    validateResponse(response.get());
    return result.get();
  }

  /**
   * Валидация ответа на запрос логов Кибаны (проверяется, что поля result.isPartial и
   * result.isRunning равны false; result.total == result.loaded; result.rawResponse.hits.total
   * равно размеру массива result.rawResponse.hits.hits)
   *
   * @param response проверяемый ответ
   */
  private static void validateResponse(KibanaGetLogsResponse response) {
    assertThat(response.getResult().getIsPartial())
        .as("В ответе от Кибаны значение result.isPartial равно true")
        .isFalse();
    assertThat(response.getResult().getIsRunning())
        .as("В ответе от Кибаны значение result.isRunning равно true")
        .isFalse();
    assertThat(response.getResult().getTotal())
        .as("В ответе от Кибаны значение result.total не равно значению result.loaded")
        .isEqualTo(response.getResult().getLoaded());
    assertThat(response.getResult().getRawResponse().getHits().getHits().size())
        .as(
            "В ответе от Кибаны значение result.rawResponse.hits.total не равно размеру массива result.rawResponse.hits.hits")
        .isEqualTo(response.getResult().getRawResponse().getHits().getTotal());
  }

  /**
   * Метод формирует тело для запроса POST {kibana.base.url}/internal/bsearch по шаблону
   * kibana/kibanaLogsRequestBodyTemplate.json и переданным параметрм.
   *
   * @param index паттерн индекса для поиска логов в Кибане (например, ebg-*)
   * @param timeRange временной интервал поиска логов (10s, 2m)
   * @param fields поля фильтрации логов
   * @param values значения полей фильтрации логов
   * @return тело запроса
   */
  private static JSONObject getKibanaLogsRequestBody(
      String index, String timeRange, List<String> fields, List<String> values) {
    JSONObject body =
        new JSONObject(
            FileHelper.getFileContent(
                KibanaRequests.class.getResourceAsStream(
                    "/kibana/kibanaLogsRequestBodyTemplate.json")));
    JSONObject params =
        body.getJSONArray("batch")
            .getJSONObject(0)
            .getJSONObject("request")
            .getJSONObject("params");
    params.put("index", index);

    JSONArray filter =
        params
            .getJSONObject("body")
            .getJSONObject("query")
            .getJSONObject("bool")
            .getJSONArray("filter");
    for (int i = 0; i < fields.size(); i++) {
      var newFilterJson =
          String.format(
              """
                                                      {
                                                          "bool": {
                                                              "should": [
                                                                  {
                                                                      "match_phrase": {
                                                                          "%s": "%s"
                                                                      }
                                                                  }
                                                              ],
                                                              "minimum_should_match": 1
                                                          }
                                                      }
                                                      """,
              fields.get(i), values.get(i));
      JSONObject newFilter = new JSONObject(newFilterJson);
      filter.getJSONObject(0).getJSONObject("bool").getJSONArray("filter").put(i, newFilter);
    }

    var timeTo = ZonedDateTime.now();
    var timeFrom =
        DateCalculator.calculateDate(timeTo, "минус", DateCalculator.getChronoUnitsMap(timeRange));
    JSONObject timestamp =
        filter.getJSONObject(1).getJSONObject("range").getJSONObject("@timestamp");
    timestamp.put("gte", DateHelper.getKibanaDateTime(timeFrom));
    timestamp.put("lte", DateHelper.getKibanaDateTime(timeTo));
    return body;
  }
}
