package ru.gazprombank.automation.akitagpb.modules.ccl.kibana.api.rest.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Fields {

  @JsonProperty("camunda.external_task_id.keyword")
  private List<String> camundaExternalTaskIdKeyword;

  @JsonProperty("camunda.is_retry_attempt.keyword")
  private List<String> camundaIsRetryAttemptKeyword;

  @JsonProperty("app_version")
  private List<String> appVersion;

  @JsonProperty("tags.keyword")
  private List<String> tagsKeyword;

  @JsonProperty("camunda.definition_key")
  private List<String> camundaDefinitionKey;

  @JsonProperty("camunda.is_retry_attempt")
  private List<String> camundaIsRetryAttempt;

  @JsonProperty("camunda.business_key")
  private List<String> camundaBusinessKey;

  @JsonProperty("camunda.activity_id.value")
  private List<String> camundaActivityIdValue;

  @JsonProperty("host")
  private List<String> host;

  @JsonProperty("@version")
  private List<String> version;

  @JsonProperty("camunda.activity_id.value.keyword")
  private List<String> camundaActivityIdValueKeyword;

  @JsonProperty("camunda.business_key.keyword")
  private List<String> camundaBusinessKeyKeyword;

  @JsonProperty("logger_name")
  private List<String> loggerName;

  @JsonProperty("host.keyword")
  private List<String> hostKeyword;

  @JsonProperty("logger_name.keyword")
  private List<String> loggerNameKeyword;

  @JsonProperty("thread_name.keyword")
  private List<String> threadNameKeyword;

  @JsonProperty("camunda.definition_key.keyword")
  private List<String> camundaDefinitionKeyKeyword;

  @JsonProperty("trace_id")
  private List<String> traceId;

  @JsonProperty("app_version.keyword")
  private List<String> appVersionKeyword;

  @JsonProperty("level")
  private List<String> level;

  @JsonProperty("@version.keyword")
  private List<String> versionKeyword;

  @JsonProperty("message")
  private List<String> message;

  @JsonProperty("trace_id.keyword")
  private List<String> traceIdKeyword;

  @JsonProperty("tags")
  private List<String> tags;

  @JsonProperty("app_name")
  private List<String> appName;

  @JsonProperty("@timestamp")
  private List<String> timestamp;

  @JsonProperty("level.keyword")
  private List<String> levelKeyword;

  @JsonProperty("camunda.process_instance_id.keyword")
  private List<String> camundaProcessInstanceIdKeyword;

  @JsonProperty("port")
  private List<Integer> port;

  @JsonProperty("level_value")
  private List<Integer> levelValue;

  @JsonProperty("application.method.name")
  private List<String> applicationMethodName;

  @JsonProperty("thread_name")
  private List<String> threadName;

  @JsonProperty("application.method.name.keyword")
  private List<String> applicationMethodNameKeyword;

  @JsonProperty("camunda.external_task_id")
  private List<String> camundaExternalTaskId;

  @JsonProperty("app_name.keyword ")
  private List<String> appNameKeyword;

  @JsonProperty("camunda.process_instance_id")
  private List<String> camundaProcessInstanceId;

  @JsonProperty("application.method.result")
  private List<String> applicationMethodResult;

  @JsonProperty("application.method.result.keyword")
  private List<String> applicationMethodResultKeyword;

  @JsonProperty("topic_name")
  private List<String> topicName;

  @JsonProperty("topic_name.keyword")
  private List<String> topicNameKeyword;

  @JsonProperty("transport")
  private List<String> transport;

  @JsonProperty("transport.keyword")
  private List<String> transportKeyword;
}
