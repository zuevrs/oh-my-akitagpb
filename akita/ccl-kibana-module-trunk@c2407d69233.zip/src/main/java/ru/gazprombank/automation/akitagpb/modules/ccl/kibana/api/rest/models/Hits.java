package ru.gazprombank.automation.akitagpb.modules.ccl.kibana.api.rest.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Hits {
  private Integer total;

  @JsonProperty("max_score")
  private Object maxScore;

  private List<Hit> hits;
}
