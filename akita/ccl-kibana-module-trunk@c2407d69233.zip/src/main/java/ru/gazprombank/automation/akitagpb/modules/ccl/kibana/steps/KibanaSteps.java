package ru.gazprombank.automation.akitagpb.modules.ccl.kibana.steps;

import static ru.gazprombank.automation.akitagpb.modules.ccl.helpers.StringHelper.processValue;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.ru.И;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.assertj.core.api.SoftAssertions;
import ru.gazprombank.automation.akitagpb.modules.ccl.helpers.StringHelper;
import ru.gazprombank.automation.akitagpb.modules.ccl.helpers.assertions.MainAssert;
import ru.gazprombank.automation.akitagpb.modules.ccl.helpers.assertions.StringAsserts;
import ru.gazprombank.automation.akitagpb.modules.ccl.helpers.dataTableModels.KibanaLogFieldAssertableConditionParam;
import ru.gazprombank.automation.akitagpb.modules.ccl.kibana.api.rest.models.Hit;
import ru.gazprombank.automation.akitagpb.modules.ccl.kibana.api.rest.models.KibanaGetLogsResponse;
import ru.gazprombank.automation.akitagpb.modules.ccl.kibana.api.rest.models.securitylogs.CefMessageModel;
import ru.gazprombank.automation.akitagpb.modules.ccl.kibana.api.rest.requests.KibanaRequests;
import ru.gazprombank.automation.akitagpb.modules.core.steps.BaseMethods;

public class KibanaSteps extends BaseMethods {

  /**
   * Шаг получения логов из Кибаны по параметрам из таблицы. Отправляет запрос POST
   * {kibana.base.url}/internal/bsearch, пока не получит ответ. Тело ответа (json) сохраняется в
   * указанную переменную сценария. В таблице параметров можно передавать любые поля из Кибаны
   * (app_name, message, camunda.definition_key и т.д.) любое количество раз. Параметр "index" -
   * паттерн индекса в Кибане, если не задавать - по дефолту "ebg-*". Параметр "За время" - 1s,
   * 2s... 123s, 1m, 2m... - за какое последнее время с момента выполнения шага искать логи в
   * Кибане. Пример: И получаем логи из Kibana по параметрам из таблицы, сохранив тело ответа в
   * переменную "var" | index | ebg-* | | За время | 10s | | message | CEF | | app_name |
   * event-fixer-service | | level | INFO | | app_version | 1.0.0.352-fb84eb3 | | message | Создание
   * объекта |
   *
   * @param varName переменная сценария для сохранения ответа
   * @param table параметры поиска логов
   */
  @SuppressWarnings("unchecked")
  @И(
      "^получаем логи из Kibana по параметрам из таблицы, сохранив тело ответа в переменную \"(.*)\"$")
  public void getKibanaLogs(String varName, DataTable table) {
    var params = getRequestParams(table);
    var result =
        KibanaRequests.getKibanaLogs(
            (String) params.get(0),
            (String) params.get(1),
            (List<String>) params.get(2),
            (List<String>) params.get(3));
    akitaScenario.setVar(varName, result);
    akitaScenario.log(String.format("Значение %s: %s", varName, result));
  }

  /**
   * Шаг с ожиданием получения указанного количества логов из Кибаны по параметрам из таблицы.
   * Максимальное время ожидания передаётся в шаге. Описание работы шага и параметры таблицы
   * аналогичны шагу {@link #getKibanaLogs(String, DataTable)}
   *
   * @param expectedLogsNumber ожидаемое количество логов
   * @param timeout максимальное время ожидания
   * @param varName переменная сценария для сохранения ответа
   * @param table параметры поиска логов
   */
  @SuppressWarnings("unchecked")
  @И(
      "^получаем (\\d+) лог(?:а|ов)? из Kibana по параметрам из таблицы в течение (\\d+) секунд, сохранив тело ответа в переменную \"(.*)\"$")
  public void getKibanaLogsWithTimeout(
      Integer expectedLogsNumber, Integer timeout, String varName, DataTable table) {
    var params = getRequestParams(table);
    var result =
        KibanaRequests.getKibanaLogsWithTimeout(
            (String) params.get(0),
            (String) params.get(1),
            (List<String>) params.get(2),
            (List<String>) params.get(3),
            expectedLogsNumber,
            timeout);
    akitaScenario.setVar(varName, result);
    akitaScenario.log(String.format("Значение %s: %s", varName, result));
  }

  private List<Object> getRequestParams(DataTable table) {
    List<String> fields =
        table.column(0).stream().map(StringHelper::processValue).collect(Collectors.toList());
    List<String> values =
        table.column(1).stream().map(StringHelper::processValue).collect(Collectors.toList());

    int timeIndex = fields.indexOf("За время");
    String timeRange = "10s"; // дефолтное значение "За время" - 10 секунд
    if (timeIndex >= 0) {
      fields.remove(timeIndex);
      timeRange = values.remove(timeIndex);
    }
    int indexIndex = fields.indexOf("index");
    String index = "ebg-*"; // дефолтный индекс - "ebg-*"
    if (indexIndex >= 0) {
      fields.remove(indexIndex);
      index = values.remove(indexIndex);
    }

    return List.of(index, timeRange, fields, values);
  }

  /**
   * Из json-строки полученных в шаге {@link #getKibanaLogs(String, DataTable)} логов Кибаны сделать
   * список java-объектов класса KibanaGetLogsResponse (для удобства работы с этими логами) и
   * сохранить в переменную.
   *
   * @param json json-строка полученных заранее логов Кибаны
   * @param varName переменная для сохранения списка логов
   */
  @И("^из json-строки \"(.*)\" сохраняем список логов Кибаны в переменную \"(.*)\"$")
  public void saveKibanaLogsListFromJson(String json, String varName) {
    json = processValue(json);
    try {
      var response = new ObjectMapper().readValue(json, KibanaGetLogsResponse.class);
      var logsList = response.getResult().getRawResponse().getHits().getHits();
      akitaScenario.setVar(varName, logsList);
      akitaScenario.log(String.format("Количество логов в списке: %s", logsList.size()));
      akitaScenario.log(String.format("Значение %s: %s", varName, logsList));
    } catch (JsonProcessingException e) {
      throw new RuntimeException("Ошибка при парсинге ответа на получение логов из Кибаны", e);
    }
  }

  /**
   * Из списка логов, полученных в шаге {@link #saveKibanaLogsListFromJson(String, String)},
   * сохранить в переменную первый, последний лог, или лог по порядковому номеру в списке.
   *
   * @param listVar список логов Кибаны
   * @param firstOrLastItem "перввый лог" -> индекс = 0; "последний лог" -> индекс = null
   * @param index порядковый номер лога в списке (начиная с 1) -> индекс элемента = порядковыйй
   *     номер - 1
   * @param varName переменная для сохранения лога Кибаны
   */
  @SuppressWarnings("unchecked")
  @И(
      "^из списка логов Кибаны \"(.*)\" сохраняем (?:(первый|последний) лог|лог с порядковым номером (\\d+)) в переменную \"(.*)\"$")
  public void getLogFromKibanaLogsList(
      String listVar, String firstOrLastItem, Integer index, String varName) {
    List<Hit> cefLogs =
        (List<Hit>) akitaScenario.getVar(listVar.replace("${", "").replace("}", ""));
    index = getListIndex(firstOrLastItem, index);
    var log = index != null ? cefLogs.get(index) : cefLogs.get(cefLogs.size() - 1);
    akitaScenario.setVar(varName, log);
    akitaScenario.log(String.format("Значение %s: %s", varName, log));
  }

  /**
   * Лог Кибаны представляте собой json, в json-массиве которого по пути
   * result.rawResponse.hits.hits.fields содержатся значения полей, представленных в Кибане (на
   * фронте в том числе). Данный шаг по имени поля сохранит в переменную его значение из переданного
   * лога.
   *
   * @param logVar лог Кибаны, полученный в шаге {@link #getLogFromKibanaLogsList(String, String,
   *     Integer, String)}
   * @param fieldName имя поля, значение которого нужно получить, как на фронте в Кибане (app_name,
   *     camunda.definition_key, message)
   * @param varName переменная для сохранения значения
   */
  @И("^из лога Кибаны \"(.*)\" значение поля \"(.*)\" сохранено в переменную \"(.*)\"$")
  public void getFieldValueFromKibanaLog(String logVar, String fieldName, String varName) {
    Hit log = (Hit) akitaScenario.getVar(logVar.replace("${", "").replace("}", ""));
    fieldName = processValue(fieldName);
    var value = log.getFieldValueByFieldName(fieldName);
    akitaScenario.setVar(varName, value);
    akitaScenario.log(String.format("Значение %s: %s", varName, value));
  }

  /**
   * Лог Кибаны представляте собой json, в json-массиве которого по пути
   * result.rawResponse.hits.hits.fields содержатся значения полей, представленных в Кибане (на
   * фронте в том числе). Данные шаг проверяет значения этих полей по условиям из таблицы. Сравнение
   * происходит как при работе со строками, соответсвтенно в колонке "Условие" можно передавать
   * любые условия сравнения из @{@link StringAsserts} Пример: И поля лога Кибаны "${log}"
   * соответствуют условиям: | Поле | Условие | Значение | | camunda.business_key | равно |
   * ${businessKey} | | camunda.activity_id.value | равно | Activity_1pc1233 | | message | содержит
   * | Создание объекта | | message | содержит | msg=Попытка создать объект KorproEvent{ |
   *
   * @param logVar лог Кибаны, полученный в шаге {@link #getLogFromKibanaLogsList(String, String,
   *     Integer, String)}
   * @param conditions условия проверки полей лога Кибаны
   */
  @И("^поля лога Кибаны \"(.*)\" соответствуют условиям:?$")
  public void assertFieldsFromKibanaLog(
      String logVar, List<KibanaLogFieldAssertableConditionParam> conditions) {
    Hit log = (Hit) akitaScenario.getVar(logVar.replace("${", "").replace("}", ""));
    MainAssert mainAssert = new MainAssert();
    conditions.forEach(
        e ->
            mainAssert
                .getAssertion(e.getType())
                .accept(e, log.getFieldValueByFieldName(e.getField())));
    mainAssert.assertAll();
  }

  /**
   * Данный шаг предназначен только для логов Кибаны, поле message которых представляет собой
   * CEF-сообщение - имеет формат CEF:Version|Device Vendor|Device Product|Device Version|Device
   * EventClass ID|Name|Severity|[Extension]. Из лога Кибаны берётся значение данного поля message и
   * преобразуется в java-объект класса {@link CefMessageModel} для удобства работы. Полученный
   * объект сохраняется в переменную.
   *
   * @param logVar лог Кибаны, полученный в шаге {@link #getLogFromKibanaLogsList(String, String,
   *     Integer, String)}
   * @param varName переменная для сохранения значения
   */
  @И("^сохраняем CEF-сообщение лога Кибаны \"(.*)\" в переменную \"(.*)\"$")
  public void saveCefMessageFromKibanaLog(String logVar, String varName) {
    Hit log = (Hit) akitaScenario.getVar(logVar.replace("${", "").replace("}", ""));
    var cefMessage = new CefMessageModel(log.getFields().getMessage().get(0));
    akitaScenario.setVar(varName, cefMessage);
    akitaScenario.log(String.format("Значение %s: %s", varName, cefMessage));
  }

  /**
   * Данный шаг предназначен только для логов Кибаны, поле message которых представляет собой
   * CEF-сообщение - имеет формат CEF:Version|Device Vendor|Device Product|Device Version|Device
   * EventClass ID|Name|Severity|[Extension]. CEF-сообщение, передаваемое в данный шаг, должно быть
   * предварительно получено шагом {@link #saveCefMessageFromKibanaLog(String, String)} Шаг
   * проверяет параметры CEF-сообщения - Version, Device Vendor, Device Product и т.д., кроме
   * Extension - для него отдельные шаги. Пример: И CEF-сообщение "${cefMessage}" соответствует
   * параметрам из таблицы: | Version | CEF:0 | | Device Vendor | АС КОР-ПРО | | Device Product |
   * mainJournal | | Device Version | 1.0.0.352-fb84eb3 | | Device EventClass ID | E001 | | Name |
   * Создание объекта | | Severity | 0 |
   *
   * @param cefMessageVar CEF-сообщение из лога Кибаны, полученное в шаге {@link
   *     #saveCefMessageFromKibanaLog(String, String)}
   * @param params ожидаемые параметры CEF-сообщения
   */
  @И("^CEF-сообщение \"(.*)\" соответствует параметрам из таблицы:?$")
  public void assertCefMessageValues(String cefMessageVar, Map<String, String> params) {
    CefMessageModel cefMessage =
        (CefMessageModel) akitaScenario.getVar(cefMessageVar.replace("${", "").replace("}", ""));
    SoftAssertions softAssertions = new SoftAssertions();
    params.forEach(
        (key, value) -> {
          key = processValue(key);
          value = processValue(value);
          softAssertions
              .assertThat(cefMessage.getFieldValueByFieldName(key))
              .as("Значение CEF-сообщения " + key + " не равно ожидаемому значению")
              .isEqualTo(value);
        });
    softAssertions.assertAll();
  }

  /**
   * Данный шаг предназначен только для логов Кибаны, поле message которых представляет собой
   * CEF-сообщение - имеет формат CEF:Version|Device Vendor|Device Product|Device Version|Device
   * EventClass ID|Name|Severity|[Extension]. Шаг проверяет параметр Extension из CEF-сообщения,
   * полученного шагом {@link #saveCefMessageFromKibanaLog(String, String)}. Сравнение парамемтров
   * происходит как при работе со строками, соответсвтенно в колонке "Условие" можно передавать
   * любые условия сравнения из @{@link StringAsserts} Пример: И значение Extension CEF-сообщения
   * "${cefMessage}" соответствует параметрам из таблицы: | Параметр | Условие | Значение | |
   * externalId | пустая | | | suser | пустая | | | msg | начинается с | Попытка создать объект | |
   * msg | содержит | Заявка на транш. Ожидание ответа САДКО | | outcome | равно | success |
   *
   * @param cefMessageVar CEF-сообщение из лога Кибаны, полученное в шаге {@link
   *     #saveCefMessageFromKibanaLog(String, String)}
   * @param conditions условия проверки параметров значения Extension из CEF-сообщения лога Кибаны
   */
  @И("^значение Extension CEF-сообщения \"(.*)\" соответствует параметрам из таблицы:?$")
  public void assertCefMessageExtensionValues(
      String cefMessageVar, List<KibanaLogFieldAssertableConditionParam> conditions) {
    CefMessageModel cefMessage =
        (CefMessageModel) akitaScenario.getVar(cefMessageVar.replace("${", "").replace("}", ""));
    MainAssert mainAssert = new MainAssert();
    conditions.forEach(
        e ->
            mainAssert
                .getAssertion(e.getType())
                .accept(e, cefMessage.getExtension().getParameters().get(e.getField())));
    mainAssert.assertAll();
  }

  /**
   * Шаг для сохранения указанного параметра из значения Extension CEF-сообщения, полученного из
   * лога Кибаны шагом {@link #saveCefMessageFromKibanaLog(String, String)}.
   *
   * @param cefMessageExtensionParameter параметра из значения Extension CEF-сообщения (msg,
   *     externalId, suser и т.д.)
   * @param cefMessageVar CEF-сообщение из лога Кибаны, полученное в шаге {@link
   *     #saveCefMessageFromKibanaLog(String, String)}
   * @param varName переменная для сохранения значения
   */
  @И("^сохраняем параметр \"(.*)\" из Extension CEF-сообщения \"(.*)\" в переменную \"(.*)\"$")
  public void saveExtensionParameterFromCefMessage(
      String cefMessageExtensionParameter, String cefMessageVar, String varName) {
    CefMessageModel cefMessage =
        (CefMessageModel) akitaScenario.getVar(cefMessageVar.replace("${", "").replace("}", ""));
    cefMessageExtensionParameter = processValue(cefMessageExtensionParameter);
    var parameterValue =
        cefMessage.getExtension().getParameters().get(cefMessageExtensionParameter);
    akitaScenario.setVar(varName, parameterValue);
    akitaScenario.log(String.format("Значение %s: %s", varName, parameterValue));
  }

  private Integer getListIndex(String firstOrLastItem, Integer index) {
    return firstOrLastItem != null
        ? firstOrLastItem.startsWith("последн") ? null : 0
        : (Integer) (index - 1);
  }
}
