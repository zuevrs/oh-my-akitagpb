package ru.gazprombank.automation.akitagpb.modules.ccl.kibana.api.rest.models.securitylogs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import lombok.Data;

@Data
public class CefMessageModel {

  // CEF:Version|Device Vendor|Device Product|Device Version|Device EventClass
  // ID|Name|Severity|[Extension]
  private String version;
  private String deviceVendor;
  private String deviceProduct;
  private String deviceVersion;
  private String deviceEventClassId;
  private String name;
  private String severity;
  private CefExtensionModel extension;

  public CefMessageModel(String rawString) {
    List<String> parts = new ArrayList<>(List.of(rawString.split("\\|")));
    version = parts.get(0);
    deviceVendor = parts.get(1);
    deviceProduct = parts.get(2);
    deviceVersion = parts.get(3);
    deviceEventClassId = parts.get(4);
    name = parts.get(5);
    severity = parts.get(6);
    extension = new CefExtensionModel(parts.get(7));
  }

  /**
   * Получить значение поля по его имени (имя поля можно передавать в любом регистре, с пробелами и
   * символами -_:)
   *
   * @param fieldName имя поля сообщения (Version, Device Vendor, Name)
   * @return значение поля с указанным именем
   */
  public String getFieldValueByFieldName(String fieldName) {
    var name = fieldName.replaceAll("[\\s-_:]+", "");
    var field =
        Arrays.stream(this.getClass().getDeclaredFields())
            .filter(e -> e.getName().equalsIgnoreCase(name))
            .findFirst()
            .orElseThrow(
                () ->
                    new RuntimeException(
                        "В классе CefMessageModel не найдено поля с именем " + fieldName));
    field.setAccessible(true);
    try {
      return field.get(this).toString();
    } catch (IllegalAccessException e) {
      throw new RuntimeException("Не удалось получить значение поля с именем " + fieldName);
    }
  }
}
