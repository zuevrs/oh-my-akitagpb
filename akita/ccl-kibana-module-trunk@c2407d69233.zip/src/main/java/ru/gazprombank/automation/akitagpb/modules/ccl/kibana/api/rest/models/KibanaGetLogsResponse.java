package ru.gazprombank.automation.akitagpb.modules.ccl.kibana.api.rest.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class KibanaGetLogsResponse {
  private Long id;
  private Result result;
  private Object error;
}
