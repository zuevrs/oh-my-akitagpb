package ru.gazprombank.automation.akitagpb.modules.ccl.kibana.api.rest.models.securitylogs;

import java.util.HashMap;
import java.util.Map;
import lombok.Data;

@Data
public class CefExtensionModel {
  // externalId= suser= sntdom= src= smac= shost= duser= dntdom= dst= dmac= dhost= spt= dpt= app=
  // start=1689320962860 end= rt=
  // msg=Попытка изменить объект. Старое значение объекта EbgLinkedFile{"id":
  // "24f55762-e13d-4aa7-9850-ae5d638b697c", "apiType": null, ...}
  // deviceProcessName=vbc-integration outcome=success

  private Map<String, String> parameters = new HashMap<>();

  public CefExtensionModel(String parameters) {
    String[] paramArray = parameters.split("=");
    String key = paramArray[0];
    for (int i = 1; i < paramArray.length - 1; i++) {
      String value = paramArray[i].substring(0, paramArray[i].lastIndexOf(" "));
      this.parameters.put(key, value);
      key = paramArray[i].substring(paramArray[i].lastIndexOf(" ") + 1);
    }
    this.parameters.put(key, paramArray[paramArray.length - 1]);
  }
}
