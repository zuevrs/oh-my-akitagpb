package ru.gazprombank.automation.akitagpb.modules.ccl.kibana.api.rest.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Result {
  private String id;
  private RawResponse rawResponse;
  private Boolean isPartial;
  private Boolean isRunning;
  private Integer total;
  private Integer loaded;
}
