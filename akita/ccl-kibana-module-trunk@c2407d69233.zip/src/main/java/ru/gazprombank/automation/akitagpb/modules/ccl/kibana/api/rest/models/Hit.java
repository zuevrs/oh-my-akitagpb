package ru.gazprombank.automation.akitagpb.modules.ccl.kibana.api.rest.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Arrays;
import java.util.List;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Hit {
  @JsonProperty("_index")
  private String index;

  @JsonProperty("_type")
  private String type;

  @JsonProperty("_id")
  private String id;

  @JsonProperty("_version")
  private Long version;

  @JsonProperty("_score")
  private Object score;

  private Fields fields;
  private List<Long> sort;

  /**
   * Получить значение поля объкта класса Fields по его имени в json'е (т.е. по значению
   * аннотации @JsonProperty)
   *
   * @param fieldName имя поля сообщения (camunda.definition_key, @version и т.д.)
   * @return значение поля с указанным именем
   */
  @SuppressWarnings("unchecked")
  public String getFieldValueByFieldName(String fieldName) {
    var field =
        Arrays.stream(Fields.class.getDeclaredFields())
            .filter(e -> e.getAnnotation(JsonProperty.class).value().equals(fieldName))
            .findFirst()
            .orElseThrow(() -> new RuntimeException("Не найдено поля с именем " + fieldName));
    field.setAccessible(true);
    try {
      var list = (List<Object>) field.get(this.fields);
      return list.get(0).toString();
    } catch (IllegalAccessException e) {
      throw new RuntimeException("Не удалось получить значение поля с именем " + fieldName);
    }
  }
}
