# Akita GPB module akita-gpb-hooks-module

## Назначение сервиса
Сервис akita-gpb-hooks-module содержит хуки для фреймворка Akita-BDD, включая Allure (интеграция с Selenium, RestAssured и цензура паролей) и Docker (запуск и остановка Docker Compose). Он предназначен для расширения функциональности тестов и относится к домену автоматизации тестирования.

## Описание процесса
В сервисе реализован следующий бизнес-процесс: Управление хуками:
1. Выполнение хуков Allure для работы с Selenium, RestAssured и маскировки паролей.
2. Управление Docker Compose (запуск и остановка контейнеров).
3. Интеграция с модулями akita-gpb-core-module, akita-gpb-api-module, akita-gpb-ui-module и akita-gpb-kafka-mq-module для поддержки тестовых сценариев.

## Контактная информация
За сервис отвечает команда "Инструменты тестирования" ([BS ИНТ](https://backstage.int.gazprombank.ru/catalog/default/group/qa-tools-team), [BS ВКР](https://backstage.dev.gazprombank.ru/catalog/default/group/qa-tools-team))

Вопросы по работе сервиса, а также обратную связь можно направить на электронную почту:

Мишечкин Павел Владимирович - `pavel.mishechkin@gazprombank.ru`<br>
Кайдаш Илья Васильевич - `ilya.kaydash@gazprombank.ru`<br>
Кислый Роман Александрович - `roman.kisly@gazprombank.ru`<br>

