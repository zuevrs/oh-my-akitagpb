# Akita GPB module akita-gpb-helpers-module

## Назначение сервиса
Сервис akita-gpb-helpers-module содержит абстрактные вспомогательные классы, не связанные с базовыми модулями, такие как DockerHelper, SshConnectionHelper и SshSteps. Он предназначен для поддержки дополнительных функций в фреймворке Akita-BDD и относится к домену вспомогательных инструментов автоматизации.

## Описание процесса
В сервисе реализован следующий бизнес-процесс: Обеспечение вспомогательных функций:
1. Предоставление вспомогательных классов для работы с Docker (DockerHelper).
2. Обеспечение SSH-подключений и шагов через SshConnectionHelper и SshSteps.
3. Интеграция с модулем akita-gpb-core-module для передачи данных и управления процессами.

## Контактная информация
За сервис отвечает команда "Инструменты тестирования" ([BS ИНТ](https://backstage.int.gazprombank.ru/catalog/default/group/qa-tools-team), [BS ВКР](https://backstage.dev.gazprombank.ru/catalog/default/group/qa-tools-team))

Вопросы по работе сервиса, а также обратную связь можно направить на электронную почту:

Мишечкин Павел Владимирович - `pavel.mishechkin@gazprombank.ru`<br>
Кайдаш Илья Васильевич - `ilya.kaydash@gazprombank.ru`<br>
Кислый Роман Александрович - `roman.kisly@gazprombank.ru`<br>

